################################################################################
# S3 BUCKETS
#
# All general-purpose S3 bucket module calls live here.
# Add a new bucket by adding an entry to var.s3_buckets in your tfvars file.
# The bucket name becomes: <env>-<project>-<bucket_suffix>
#
# NOTE: The Lambda artifacts bucket and Glue scripts bucket are defined in
# their own files (functions.tf, glue-job.tf) alongside the resources that
# use them.
################################################################################

module "s3_buckets" {
  for_each = var.s3_buckets
  source   = "./modules/s3"

  bucket_name        = "${local.name_prefix}-${each.value.bucket_suffix}"
  versioning_enabled = each.value.versioning_enabled
  enable_kms         = each.value.enable_kms
  force_destroy      = each.value.force_destroy

  enable_lifecycle_rules = each.value.enable_lifecycle_rules
  lifecycle_rules        = each.value.enable_lifecycle_rules ? var.s3_lifecycle_rules : []

  bucket_policy = each.value.enable_bucket_policy ? (
    each.value.policy_template_path != null
    ? data.aws_iam_policy_document.s3_bucket_merged[each.key].json
    : data.aws_iam_policy_document.s3_bucket_base[each.key].json
  ) : null

  tags = merge(local.common_tags, each.value.extra_tags, {
    Name = "${local.name_prefix}-${each.value.bucket_suffix}"
  })
}

################################################################################
# S3 Bucket Policies
#
# Base policy: enforces TLS-only access (denies HTTP requests).
# Applied to all buckets that have enable_bucket_policy = true.
#
# Custom policy (optional): rendered from a template file specified in
# policy_template_path. Template variables available: bucket_name, bucket_arn,
# environment, project_name, account_id, region.
#
# When both are present, the base and custom policies are merged so every
# bucket always enforces TLS regardless of custom rules.
#
# Because the policy references bucket ARN / name dynamically, it works
# unchanged across dev / uat / prod.
################################################################################

# ── Base policy: enforce TLS ─────────────────────────────────────────────────

data "aws_iam_policy_document" "s3_bucket_base" {
  for_each = {
    for k, v in var.s3_buckets : k => v if v.enable_bucket_policy
  }

  statement {
    sid    = "DenyNonSSLRequests"
    effect = "Deny"

    principals {
      type        = "*"
      identifiers = ["*"]
    }

    actions = ["s3:*"]

    resources = [
      "arn:aws:s3:::${local.name_prefix}-${each.value.bucket_suffix}",
      "arn:aws:s3:::${local.name_prefix}-${each.value.bucket_suffix}/*",
    ]

    condition {
      test     = "Bool"
      variable = "aws:SecureTransport"
      values   = ["false"]
    }
  }
}

# ── Custom policy from template (optional) ───────────────────────────────────

data "aws_iam_policy_document" "s3_bucket_custom" {
  for_each = {
    for k, v in var.s3_buckets : k => v if v.enable_bucket_policy && v.policy_template_path != null
  }

  override_policy_documents = [
    templatefile(each.value.policy_template_path, {
      bucket_name   = "${local.name_prefix}-${each.value.bucket_suffix}"
      bucket_arn    = "arn:aws:s3:::${local.name_prefix}-${each.value.bucket_suffix}"
      environment   = var.environment
      project_name  = var.project_name
      account_id    = data.aws_caller_identity.current.account_id
      region        = var.aws_region
      principal_arn = each.value.principal_arn
    })
  ]
}

# ── Merged policy: base + custom ─────────────────────────────────────────────

data "aws_iam_policy_document" "s3_bucket_merged" {
  for_each = {
    for k, v in var.s3_buckets : k => v if v.enable_bucket_policy && v.policy_template_path != null
  }

  source_policy_documents = [
    data.aws_iam_policy_document.s3_bucket_base[each.key].json,
  ]
  override_policy_documents = [
    data.aws_iam_policy_document.s3_bucket_custom[each.key].json,
  ]
}
