
variable "role_name" {
  description = "Name of the IAM role. Must be unique within the AWS account."
  type        = string
}

variable "description" {
  description = "Human-readable description of the role's intended purpose."
  type        = string
  default     = ""
}

variable "path" {
  description = <<-EOT
    IAM path for the role. Useful for organising roles by team / service.
    Must begin and end with '/' (e.g. "/sales-automation/").
  EOT
  type        = string
  default     = "/"

  validation {
    condition     = startswith(var.path, "/") && endswith(var.path, "/")
    error_message = "'path' must begin and end with a forward slash, e.g. \"/\" or \"/team/service/\"."
  }
}

################################################################################
# Trust relationship (who can assume this role)
################################################################################

variable "assume_role_policy" {
  description = <<-EOT
    JSON-encoded IAM trust policy document that controls which principals
    (AWS services, accounts, or federated users) may assume this role.
    Use aws_iam_policy_document data source in the caller for type safety.
  EOT
  type        = string
}

################################################################################
# Session settings
################################################################################

variable "max_session_duration" {
  description = <<-EOT
    Maximum session duration (in seconds) for the role.
    Valid range: 3600 (1 hour) – 43200 (12 hours).
    AWS default is 3600. Prefer shorter durations for interactive sessions.
  EOT
  type        = number
  default     = 3600

  validation {
    condition     = var.max_session_duration >= 3600 && var.max_session_duration <= 43200
    error_message = "'max_session_duration' must be between 3600 and 43200 seconds."
  }
}

################################################################################
# Permission boundary (AWS best practice for delegated administration)
################################################################################

variable "permission_boundary_arn" {
  description = <<-EOT
    ARN of an IAM managed policy to use as the permission boundary for this role.
    A permission boundary caps the maximum permissions the role can have, even
    if its attached policies grant more. Leave empty to skip.
  EOT
  type        = string
  default     = null
}

################################################################################
# Customer-managed policies – CREATE & ATTACH
#
# Use this block when the policy document lives alongside the role and should
# be provisioned by this module call.
################################################################################

variable "customer_managed_policies" {
  description = <<-EOT
    Map of customer-managed IAM policies to create and attach to the role.
    Each key is an arbitrary unique label used as the Terraform resource key.

    Example:
      customer_managed_policies = {
        s3_read = {
          name        = "sales-automation-s3-read"
          description = "Read access to raw S3 bucket"
          path        = "/sales-automation/"
          policy      = data.aws_iam_policy_document.s3_read.json
        }
      }
  EOT
  type = map(object({
    name        = string
    description = optional(string, "")
    path        = optional(string, "/")
    policy      = string # JSON policy document
    tags        = optional(map(string), {})
  }))
  default = {}
}

################################################################################
# Customer-managed policies – ATTACH ONLY (pre-existing)
#
# Use this when the policy already exists in AWS (created elsewhere) and you
# only need to attach its ARN to this role.
################################################################################

variable "customer_managed_policy_arns" {
  description = <<-EOT
    List of existing customer-managed IAM policy ARNs to attach to the role.
    The policies must already exist; this module will not create them.

    Example:
      customer_managed_policy_arns = [
        "arn:aws:iam::123456789012:policy/shared-kms-policy"
      ]
  EOT
  type        = list(string)
  default     = []
}

################################################################################
# AWS-managed policies – ATTACH ONLY
#
# Use AWS-managed policies only when no customer-managed alternative exists,
# or for AWS service-linked permissions (e.g. AmazonS3ReadOnlyAccess).
# Prefer scoped customer-managed policies for least-privilege. (AWS best practice)
################################################################################

variable "aws_managed_policy_arns" {
  description = <<-EOT
    List of AWS-managed IAM policy ARNs to attach to the role.
    Use the full ARN (e.g. "arn:aws:iam::aws:policy/AmazonS3ReadOnlyAccess").

    AWS best practice: prefer narrow customer-managed policies over broad
    AWS-managed policies wherever possible.
  EOT
  type        = list(string)
  default     = []
}

################################################################################
# Inline policies
#
# Inline policies are embedded directly in the role and cannot be reused.
# Use sparingly — prefer managed policies for auditability.
# Appropriate for role-specific permissions that must never be reused.
################################################################################

variable "inline_policies" {
  description = <<-EOT
    Map of inline policy documents to embed directly in the role.
    Each key becomes the policy name; each value is the JSON policy document.

    Use sparingly — managed policies are easier to audit and reuse.

    Example:
      inline_policies = {
        deny_delete_s3 = data.aws_iam_policy_document.deny_delete.json
      }
  EOT
  type        = map(string)
  default     = {}
}

#################################################################################
# Lifecycle controls
#################################################################################

variable "force_detach_policies" {
  description = <<-EOT
    When true, all policies attached to the role are forcibly detached before
    the role is destroyed. Set to true in ephemeral / sandbox environments.
    Keep false in production to prevent accidental policy loss.
  EOT
  type        = bool
  default     = false
}


variable "tags" {
  description = <<-EOT
    Map of tags to apply to the IAM role and any customer-managed policies
    created by this module. Merge with your common_tags in the caller:

      tags = merge(local.common_tags, { Component = "data-pipeline" })
  EOT
  type        = map(string)
  default     = {}
}
