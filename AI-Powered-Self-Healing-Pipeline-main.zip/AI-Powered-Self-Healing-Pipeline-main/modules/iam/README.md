# IAM Module

A flexible, reusable Terraform module for creating an IAM role and attaching policies to it. Designed to be called by higher-level modules (such as the Lambda module) as well as directly from root configurations.

Supports four distinct attachment modes — all combinable in a single module call:

| Mode | When to use |
|---|---|
| **Create & attach** (`customer_managed_policies`) | Policy document lives here — let the module own the full lifecycle |
| **Attach-only by ARN** (`customer_managed_policy_arns`) | Policy already exists; attach without touching it |
| **AWS-managed attach** (`aws_managed_policy_arns`) | AWS-owned policies such as `AmazonS3ReadOnlyAccess` |
| **Inline embed** (`inline_policies`) | Permission must be deleted with the role (e.g. an explicit Deny) |

---

## Quick-start

```hcl
data "aws_iam_policy_document" "lambda_trust" {
  statement {
    effect  = "Allow"
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["lambda.amazonaws.com"]
    }
  }
}

data "aws_iam_policy_document" "s3_read" {
  statement {
    effect    = "Allow"
    actions   = ["s3:GetObject", "s3:ListBucket"]
    resources = ["arn:aws:s3:::my-bucket", "arn:aws:s3:::my-bucket/*"]
  }
}

module "my_role" {
  source = "./modules/iam"

  role_name          = "my-service-role"
  description        = "Execution role for my Lambda function"
  assume_role_policy = data.aws_iam_policy_document.lambda_trust.json

  customer_managed_policies = {
    s3_read = {
      name        = "my-service-s3-read"
      description = "Read access to my-bucket"
      policy      = data.aws_iam_policy_document.s3_read.json
    }
  }

  tags = local.common_tags
}
```

---

## Examples

### Attach a pre-existing shared policy by ARN

```hcl
module "my_role" {
  source = "./modules/iam"

  role_name          = "my-service-role"
  assume_role_policy = data.aws_iam_policy_document.lambda_trust.json

  customer_managed_policy_arns = [
    "arn:aws:iam::123456789012:policy/shared-kms-decrypt"
  ]
}
```

### Attach an AWS-managed policy

```hcl
module "my_role" {
  source = "./modules/iam"

  role_name          = "my-service-role"
  assume_role_policy = data.aws_iam_policy_document.lambda_trust.json

  aws_managed_policy_arns = [
    "arn:aws:iam::aws:policy/AmazonDynamoDBReadOnlyAccess"
  ]
}
```

### Embed an inline policy (use sparingly)

```hcl
module "my_role" {
  source = "./modules/iam"

  role_name          = "my-service-role"
  assume_role_policy = data.aws_iam_policy_document.lambda_trust.json

  inline_policies = {
    deny_s3_delete = data.aws_iam_policy_document.deny_delete.json
  }
}
```

### With permission boundary (recommended for production)

```hcl
module "my_role" {
  source = "./modules/iam"

  role_name               = "my-service-role"
  assume_role_policy      = data.aws_iam_policy_document.lambda_trust.json
  permission_boundary_arn = "arn:aws:iam::123456789012:policy/org-boundary"
}
```

### Organisation path for role grouping

```hcl
module "my_role" {
  source = "./modules/iam"

  role_name          = "my-service-role"
  path               = "/sales-automation/lambda/"
  assume_role_policy = data.aws_iam_policy_document.lambda_trust.json
}
```

---

## Input variables

### Role

| Variable | Type | Required | Default | Accepted Values | Description |
|---|---|---|---|---|---|
| `role_name` | `string` | ✅ Yes | — | Any unique IAM role name (max 64 chars) | Unique name for the IAM role within the account. |
| `description` | `string` | No | `""` | Any string | Human-readable description of the role's intended purpose. |
| `path` | `string` | No | `"/"` | Must start and end with `/`, e.g. `"/"`, `"/sales-automation/lambda/"` | IAM namespace path for organising roles by team or service. |
| `assume_role_policy` | `string` | ✅ Yes | — | Valid JSON trust-policy document | Controls which principals (services, accounts, users) may assume this role. Use `aws_iam_policy_document`. |
| `max_session_duration` | `number` | No | `3600` | `3600` – `43200` (seconds) | Maximum session duration. Shorter durations are preferred for interactive sessions. |
| `permission_boundary_arn` | `string` | No | `null` | Valid IAM managed policy ARN, or `null` | Caps the maximum effective permissions of the role regardless of attached policies. |
| `force_detach_policies` | `bool` | No | `false` | `true`, `false` | When `true`, forcibly detaches all policies before the role is destroyed. Use `true` in dev/sandbox. |

### Policy attachment

| Variable | Type | Required | Default | Accepted Values | Description |
|---|---|---|---|---|---|
| `customer_managed_policies` | `map(object)` | No | `{}` | Map where each value has `name` (string), `description` (opt string), `path` (opt string, default `"/"`), `policy` (JSON string) | Policies to **create** and attach. The module owns the full lifecycle of these policies. |
| `customer_managed_policy_arns` | `list(string)` | No | `[]` | List of valid IAM policy ARNs | **Pre-existing** customer-managed policy ARNs to attach. The module does not create or manage them. |
| `aws_managed_policy_arns` | `list(string)` | No | `[]` | AWS-managed policy ARNs e.g. `"arn:aws:iam::aws:policy/AmazonS3ReadOnlyAccess"` | AWS-owned managed policy ARNs to attach. Use sparingly — prefer narrow customer-managed policies. |
| `inline_policies` | `map(string)` | No | `{}` | Map of `policy_name = json_document` | Inline policies embedded directly in the role. Use only for permissions that must be deleted with the role. |

### Tags

| Variable | Type | Required | Default | Accepted Values | Description |
|---|---|---|---|---|---|
| `tags` | `map(string)` | No | `{}` | Any `{ key = "value" }` map | Tags applied to the IAM role and all customer-managed policies created by this module. |

---

## Outputs

| Output | Description |
|---|---|
| `role_arn` | ARN of the created IAM role |
| `role_name` | Name of the created IAM role |
| `role_id` | Unique role ID (begins with `AROA…`) |
| `role_unique_id` | Stable unique ID — use this in resource-based policies, not the name |
| `customer_managed_policy_arns` | Map of ARNs for policies created by this module. Key matches `customer_managed_policies` map key |
| `customer_managed_policy_ids` | Map of IDs for policies created by this module |
| `customer_managed_policy_names` | Map of names for policies created by this module |
| `existing_customer_managed_policy_arns` | Echo of `customer_managed_policy_arns` input |

---

## Best practices

- **Least privilege** — write narrow `customer_managed_policies` scoped to exact resources and actions rather than attaching broad AWS-managed policies.
- **Permission boundaries** — always set `permission_boundary_arn` in accounts with delegated administration to cap maximum permissions.
- **Avoid inline policies** — prefer managed policies for auditability and reuse. Use `inline_policies` only for explicit Denys that must be deleted with the role.
- **Paths for organisation** — use `path` (e.g. `"/sales-automation/lambda/"`) to group roles in the IAM console and in SCPs.
- **`force_detach_policies`** — set to `true` in dev/sandbox environments so `terraform destroy` does not fail; keep `false` in production.
- **Trust policies** — always use the `aws_iam_policy_document` data source rather than raw JSON strings to catch syntax errors at plan time.
