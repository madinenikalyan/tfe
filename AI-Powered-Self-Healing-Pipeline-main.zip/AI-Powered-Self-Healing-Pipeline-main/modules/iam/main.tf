################################################################################
# 1. IAM Role
################################################################################

resource "aws_iam_role" "iam_role" {
  name                  = var.role_name
  description           = var.description
  path                  = var.path
  assume_role_policy    = var.assume_role_policy
  max_session_duration  = var.max_session_duration
  permissions_boundary  = var.permission_boundary_arn
  force_detach_policies = var.force_detach_policies

  tags = var.tags


}

################################################################################
# 2. Customer-Managed Policies – CREATE
#
# These policies are fully owned by this module call.  Use them for
# role-specific permission documents that need version history and reuse.
################################################################################

resource "aws_iam_policy" "customer_managed_policies" {

  for_each = var.customer_managed_policies

  name        = each.value.name
  description = each.value.description
  path        = each.value.path
  policy      = each.value.policy
  tags        = var.tags


}

resource "aws_iam_role_policy_attachment" "customer_managed_policy_attachments" {
  for_each = aws_iam_policy.customer_managed_policies

  role       = aws_iam_role.iam_role.name
  policy_arn = each.value.arn

  depends_on = [aws_iam_role.iam_role, aws_iam_policy.customer_managed_policies]
}

################################################################################
# 4. Attach PRE-EXISTING Customer-Managed Policies → Role
#
# For policies created outside this module (shared policies, cross-module
# references).  Pass their ARNs via var.customer_managed_policy_arns.
################################################################################

resource "aws_iam_role_policy_attachment" "customer_managed_existing_attachments" {
  for_each = toset(var.customer_managed_policy_arns)

  role       = aws_iam_role.iam_role.name
  policy_arn = each.value

  depends_on = [aws_iam_role.iam_role]
}

################################################################################
# 5. Attach AWS-Managed Policies → Role
#
# AWS-managed policies (arn:aws:iam::aws:policy/…) are owned by AWS and
# updated automatically.  Use sparingly – prefer narrow customer-managed
# policies for least-privilege compliance.
################################################################################

resource "aws_iam_role_policy_attachment" "aws_managed_policy_attachments" {
  for_each = toset(var.aws_managed_policy_arns)

  role       = aws_iam_role.iam_role.name
  policy_arn = each.value

  depends_on = [aws_iam_role.iam_role]
}

#################################################################################
# 6. Inline Policies
#
# Inline policies are tightly coupled to the role and cannot be reused.
# Use only for permission grants that MUST be deleted with the role, e.g.
# an explicit Deny that must never exist on any other role.
#################################################################################

resource "aws_iam_role_policy" "inline" {
  for_each = var.inline_policies

  name   = each.key
  role   = aws_iam_role.iam_role.name
  policy = each.value

  depends_on = [aws_iam_role.iam_role]
}
