

################################################################################
# IAM Role outputs
################################################################################

output "role_arn" {
  description = "ARN of the IAM role, e.g. arn:aws:iam::123456789012:role/my-role"
  value       = aws_iam_role.iam_role.arn
}

output "role_name" {
  description = "Name of the IAM role."
  value       = aws_iam_role.iam_role.name
}

output "role_id" {
  description = "Unique IAM role ID (begins with AROA...)."
  value       = aws_iam_role.iam_role.id
}

output "role_unique_id" {
  description = <<-EOT
    Stable unique identifier for the IAM role.
    Use this (not the name) when building resource-based policies — it
    remains constant even if the role is renamed.
  EOT
  value       = aws_iam_role.iam_role.unique_id
}

################################################################################
# Customer-managed policies CREATED by this module
# These policies are fully owned and provisioned by this module call.
################################################################################

output "customer_managed_policy_arns" {
  description = <<-EOT
    Map of ARNs for customer-managed policies created by this module.
    The key matches the key used in var.customer_managed_policies.

    Example:
      policy_arn = module.my_role.customer_managed_policy_arns["s3_read"]
  EOT
  value = {
    for k, p in aws_iam_policy.customer_managed_policies : k => p.arn
  }
}

output "customer_managed_policy_ids" {
  description = <<-EOT
    Map of resource IDs for customer-managed policies created by this module.
    The key matches the key used in var.customer_managed_policies.
  EOT
  value = {
    for k, p in aws_iam_policy.customer_managed_policies : k => p.id
  }
}

output "customer_managed_policy_names" {
  description = "Map of policy names for customer-managed policies created by this module."
  value = {
    for k, p in aws_iam_policy.customer_managed_policies : k => p.name
  }
}

################################################################################
# Pre-existing customer-managed policy ARNs
# Policies that were created OUTSIDE this module and attached via
# var.customer_managed_policy_arns.
################################################################################

output "existing_customer_managed_policy_arns" {
  description = <<-EOT
    List of pre-existing customer-managed policy ARNs attached to the role
    via var.customer_managed_policy_arns.
    These policies were NOT created by this module.
  EOT
  value       = var.customer_managed_policy_arns
}

################################################################################
# AWS-managed policy ARNs
# Policies owned by AWS (arn:aws:iam::aws:policy/...) attached via
# var.aws_managed_policy_arns.
################################################################################

output "aws_managed_policy_arns" {
  description = <<-EOT
    List of AWS-managed policy ARNs attached to the role
    via var.aws_managed_policy_arns (e.g. arn:aws:iam::aws:policy/...).
    These policies are owned and maintained by AWS, not this module.
  EOT
  value       = var.aws_managed_policy_arns
}

################################################################################
# All attached policy ARNs — combined across all three attachment types
# Useful for auditing the full effective policy set of the role.
################################################################################

output "all_attached_policy_arns" {
  description = <<-EOT
    Flat list of every policy ARN attached to the role, regardless of type.
    Includes:
      - Customer-managed policies created by this module
      - Pre-existing customer-managed policies (var.customer_managed_policy_arns)
      - AWS-managed policies (var.aws_managed_policy_arns)

    Useful for auditing or passing the complete policy set to downstream modules.
  EOT
  value = concat(

    [for p in aws_iam_policy.customer_managed_policies : p.arn], # Customer-managed policies created by this module

    var.customer_managed_policy_arns, # Pre-existing customer-managed policy ARNs passed by the caller

    var.aws_managed_policy_arns, # AWS-managed policy ARNs passed by the caller
  )
}
