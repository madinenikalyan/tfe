# S3 Module

A reusable Terraform module for creating a production-ready S3 bucket with:

- **Server-side encryption** — AES-256 (default) or AWS KMS with automatic key creation and rotation
- **Versioning** — optional, with optional MFA-Delete for data protection
- **Public access block** — all four settings blocked by default (security best practice)
- **Lifecycle rules** — configurable transitions and expirations for any number of prefixes
- **Bucket policy** — optional arbitrary JSON bucket policy
- **Object Lock** — optional WORM (Write Once Read Many) protection

---

## Quick-start (secure defaults)

```hcl
module "my_bucket" {
  source = "./modules/s3"

  bucket_name = "my-project-raw-data-uat"

  tags = local.common_tags
}
```

This creates a private bucket with AES-256 encryption, all public-access settings blocked, and no versioning.

---

## Examples

### With KMS encryption

```hcl
module "my_bucket" {
  source = "./modules/s3"

  bucket_name = "my-project-raw-data-uat"
  enable_kms  = true

  tags = local.common_tags
}
```

A dedicated KMS key is created and managed by the module. Key rotation is enabled by default.

### With versioning enabled

```hcl
module "my_bucket" {
  source = "./modules/s3"

  bucket_name        = "my-project-artifacts-uat"
  versioning_enabled = true

  tags = local.common_tags
}
```

### With lifecycle rules (transition to IA after 30 days, delete after 365)

```hcl
module "my_bucket" {
  source = "./modules/s3"

  bucket_name        = "my-project-logs-uat"
  versioning_enabled = true

  enable_lifecycle_rules = true
  lifecycle_rules = [
    {
      id      = "archive-and-expire"
      enabled = true

      transitions = [
        { days = 30,  storage_class = "STANDARD_IA" },
        { days = 90,  storage_class = "GLACIER" },
      ]

      expiration = {
        days = 365
      }

      noncurrent_version_expiration = {
        noncurrent_days = 90
      }
    }
  ]

  tags = local.common_tags
}
```

### With a custom bucket policy

```hcl
data "aws_iam_policy_document" "bucket_policy" {
  statement {
    effect    = "Allow"
    actions   = ["s3:GetObject"]
    resources = ["arn:aws:s3:::my-project-public-assets-uat/*"]
    principals {
      type        = "AWS"
      identifiers = ["arn:aws:iam::123456789012:role/cdn-read-role"]
    }
  }
}

module "my_bucket" {
  source = "./modules/s3"

  bucket_name   = "my-project-public-assets-uat"
  bucket_policy = data.aws_iam_policy_document.bucket_policy.json

  tags = local.common_tags
}
```

### With Object Lock (WORM — compliance use cases)

```hcl
module "my_bucket" {
  source = "./modules/s3"

  bucket_name         = "my-project-compliance-uat"
  object_lock_enabled = true

  tags = local.common_tags
}
```

---

## Input variables

### Bucket

| Variable | Type | Required | Default | Accepted Values | Description |
|---|---|---|---|---|---|
| `bucket_name` | `string` | ✅ Yes | — | Globally unique, 3–63 chars, lowercase alphanumeric and hyphens | Name of the S3 bucket. Must be globally unique across all AWS accounts. |
| `force_destroy` | `bool` | No | `false` | `true`, `false` | Allow `terraform destroy` to delete a non-empty bucket. **Never use `true` in production.** |
| `object_lock_enabled` | `bool` | No | `false` | `true`, `false` | Enable S3 Object Lock (WORM). **Cannot be disabled after bucket creation.** |
| `expected_bucket_owner` | `string` | No | `null` | 12-digit AWS account ID, or `null` | Validates bucket ownership. Prevents accidental operations on cross-account buckets. |

### Versioning

| Variable | Type | Required | Default | Accepted Values | Description |
|---|---|---|---|---|---|
| `versioning_enabled` | `bool` | No | `false` | `true`, `false` | Enable versioning on the bucket. Recommended for artefact, backup, and data-lake buckets. |
| `mfa_delete` | `string` | No | `"Disabled"` | `"Enabled"`, `"Disabled"` | Require MFA for permanent object deletion. Only used when `versioning_enabled = true`. |
| `mfa` | `string` | Conditional | `null` | `"<serial-arn> <totp-token>"` format, or `null` | MFA serial number and TOTP token. Required only when `mfa_delete = "Enabled"`. |

### Encryption

| Variable | Type | Required | Default | Accepted Values | Description |
|---|---|---|---|---|---|
| `enable_server_side_encryption` | `bool` | No | `true` | `true`, `false` | Enable server-side encryption configuration on the bucket. |
| `sse_algorithm` | `string` | No | `"AES256"` | `"AES256"`, `"aws:kms"` | SSE algorithm. Only evaluated when `enable_kms = false`. |
| `enable_kms` | `bool` | No | `false` | `true`, `false` | Create and attach a dedicated KMS key for bucket encryption. Overrides `sse_algorithm`. |
| `kms_deletion_window_in_days` | `number` | No | `30` | `7` – `30` (days) | Waiting period before KMS key material is permanently deleted after scheduled removal. |
| `kms_enable_key_rotation` | `bool` | No | `true` | `true`, `false` | Enable automatic annual KMS key rotation. Strongly recommended. |

### Public access block

All four settings default to `true` to enforce private-by-default. Only set to `false` when the bucket intentionally serves public content.

| Variable | Type | Required | Default | Accepted Values | Description |
|---|---|---|---|---|---|
| `block_public_acls` | `bool` | No | `true` | `true`, `false` | Block new public ACLs and strip existing public ACL grants on `PUT` operations. |
| `block_public_policy` | `bool` | No | `true` | `true`, `false` | Reject new bucket policies that grant public access. |
| `ignore_public_acls` | `bool` | No | `true` | `true`, `false` | Ignore all public ACLs at read time — effective even if they exist on objects. |
| `restrict_public_buckets` | `bool` | No | `true` | `true`, `false` | Restrict cross-account and anonymous access granted by bucket policies. |

### Bucket policy

| Variable | Type | Required | Default | Accepted Values | Description |
|---|---|---|---|---|---|
| `bucket_policy` | `string` | No | `null` | Valid JSON IAM policy document, or `null` | Resource-based bucket policy. Use `aws_iam_policy_document` data source. Leave `null` to skip. |

### Lifecycle rules

| Variable | Type | Required | Default | Accepted Values | Description |
|---|---|---|---|---|---|
| `enable_lifecycle_rules` | `bool` | No | `false` | `true`, `false` | Enable lifecycle configuration. Must be `true` for `lifecycle_rules` to take effect. |
| `lifecycle_rules` | `list(object)` | No | `[]` | List of rule objects. Each requires `id` (string), `enabled` (bool). Optional: `prefix`, `transitions`, `noncurrent_version_transitions`, `expiration`, `noncurrent_version_expiration`, `abort_incomplete_multipart_upload_days`. | Lifecycle rules for transitioning or expiring objects and non-current versions. |

### Tags

| Variable | Type | Required | Default | Accepted Values | Description |
|---|---|---|---|---|---|
| `tags` | `map(string)` | No | `{}` | Any `{ key = "value" }` map | Tags applied to all resources created by this module (bucket, KMS key). |

---

## Outputs

| Output | Description |
|---|---|
| `bucket_id` | Name / ID of the S3 bucket |
| `bucket_arn` | ARN of the S3 bucket |
| `bucket_domain_name` | Global domain name (`<name>.s3.amazonaws.com`) |
| `bucket_regional_domain_name` | Region-specific domain name |
| `bucket_region` | AWS region the bucket resides in |
| `kms_key_arn` | ARN of the KMS key (`null` when `enable_kms = false`) |
| `kms_key_id` | ID of the KMS key (`null` when `enable_kms = false`) |

---

## Best practices

- **Never set `force_destroy = true` in production** — it allows `terraform destroy` to silently delete all objects.
- **Enable versioning** for any bucket that holds important or immutable data (deployment artefacts, backups, data lake).
- **Use KMS** (`enable_kms = true`) for buckets containing sensitive or regulated data. Key rotation is on by default.
- **Keep all four public-access-block settings enabled** (the defaults) unless the bucket intentionally serves public content.
- **Scope bucket policies narrowly** — restrict both `Principal` and `Resource` to the minimum required.
- **Pair lifecycle rules with versioning** — use `noncurrent_version_expiration` to avoid unbounded storage growth from old versions.
