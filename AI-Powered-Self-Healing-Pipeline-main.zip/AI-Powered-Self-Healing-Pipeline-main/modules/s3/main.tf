################################################################################
# S3 Bucket
################################################################################

resource "aws_s3_bucket" "s3_bucket" {
  bucket              = var.bucket_name
  force_destroy       = var.force_destroy
  object_lock_enabled = var.object_lock_enabled

  tags = var.tags
}

################################################################################
# Bucket Versioning
################################################################################

resource "aws_s3_bucket_versioning" "s3_bucket_versioning" {
  count = var.versioning_enabled ? 1 : 0

  bucket                = aws_s3_bucket.s3_bucket.id
  expected_bucket_owner = var.expected_bucket_owner
  mfa                   = var.mfa
  versioning_configuration {
    status     = "Enabled"
    mfa_delete = var.mfa_delete
  }

  depends_on = [aws_s3_bucket.s3_bucket]
}

################################################################################
# Server-Side Encryption
################################################################################

resource "aws_s3_bucket_server_side_encryption_configuration" "s3_bucket_sse" {
  count = var.enable_server_side_encryption ? 1 : 0

  bucket                = aws_s3_bucket.s3_bucket.id
  expected_bucket_owner = var.expected_bucket_owner

  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm     = var.enable_kms ? "aws:kms" : var.sse_algorithm
      kms_master_key_id = var.enable_kms ? aws_kms_key.s3_kms_key[0].arn : null
    }
    bucket_key_enabled = var.enable_kms
  }

  depends_on = [aws_s3_bucket.s3_bucket, aws_kms_key.s3_kms_key]
}

################################################################################
# KMS Key for S3 Encryption
################################################################################

resource "aws_kms_key" "s3_kms_key" {
  count = var.enable_kms ? 1 : 0

  description             = "KMS key for S3 bucket ${var.bucket_name} server-side encryption"
  deletion_window_in_days = var.kms_deletion_window_in_days
  enable_key_rotation     = var.kms_enable_key_rotation

  tags = var.tags
}

################################################################################
# Public Access Block
################################################################################

resource "aws_s3_bucket_public_access_block" "s3_bucket_public_access_block" {
  bucket = aws_s3_bucket.s3_bucket.id

  block_public_acls       = var.block_public_acls
  block_public_policy     = var.block_public_policy
  ignore_public_acls      = var.ignore_public_acls
  restrict_public_buckets = var.restrict_public_buckets

  depends_on = [aws_s3_bucket.s3_bucket]
}

################################################################################
# Bucket Policy
################################################################################

resource "aws_s3_bucket_policy" "s3_bucket_policy" {
  count = var.bucket_policy != null ? 1 : 0

  bucket = aws_s3_bucket.s3_bucket.id
  policy = var.bucket_policy

  depends_on = [aws_s3_bucket.s3_bucket, aws_s3_bucket_public_access_block.s3_bucket_public_access_block]
}

################################################################################
# Lifecycle Configuration
################################################################################

resource "aws_s3_bucket_lifecycle_configuration" "s3_bucket_lifecycle" {
  count = var.enable_lifecycle_rules ? 1 : 0

  bucket                = aws_s3_bucket.s3_bucket.id
  expected_bucket_owner = var.expected_bucket_owner

  dynamic "rule" {
    for_each = var.lifecycle_rules

    content {
      id     = rule.value.id
      status = rule.value.enabled ? "Enabled" : "Disabled"

      dynamic "filter" {
        for_each = try(rule.value.prefix, null) != null ? [1] : []
        content {
          prefix = rule.value.prefix
        }
      }

      dynamic "filter" {
        for_each = try(rule.value.prefix, null) == null ? [1] : []
        content {}
      }

      dynamic "transition" {
        for_each = try(rule.value.transitions, [])
        content {
          days          = try(transition.value.days, null)
          storage_class = transition.value.storage_class
        }
      }

      dynamic "noncurrent_version_transition" {
        for_each = try(rule.value.noncurrent_version_transitions, [])
        content {
          noncurrent_days = noncurrent_version_transition.value.noncurrent_days
          storage_class   = noncurrent_version_transition.value.storage_class
        }
      }

      dynamic "expiration" {
        for_each = try(rule.value.expiration, null) != null ? [rule.value.expiration] : []
        content {
          days                         = try(expiration.value.days, null)
          expired_object_delete_marker = try(expiration.value.expired_object_delete_marker, null)
        }
      }

      dynamic "noncurrent_version_expiration" {
        for_each = try(rule.value.noncurrent_version_expiration, null) != null ? [rule.value.noncurrent_version_expiration] : []
        content {
          noncurrent_days = noncurrent_version_expiration.value.noncurrent_days
        }
      }

      dynamic "abort_incomplete_multipart_upload" {
        for_each = try(rule.value.abort_incomplete_multipart_upload_days, null) != null ? [1] : []
        content {
          days_after_initiation = rule.value.abort_incomplete_multipart_upload_days
        }
      }
    }
  }

  depends_on = [aws_s3_bucket.s3_bucket, aws_s3_bucket_versioning.s3_bucket_versioning]
}

################################################################################
# Event Notification Configuration
#
# Supports Lambda, SQS, and SNS targets.
# For each target type the module also creates the required resource-based
# permission so S3 is allowed to invoke / publish / send without the caller
# having to wire it manually.
################################################################################

resource "aws_s3_bucket_notification" "s3_bucket_notification" {
  count = length(var.lambda_notifications) > 0 || length(var.sqs_notifications) > 0 || length(var.sns_notifications) > 0 ? 1 : 0

  bucket = aws_s3_bucket.s3_bucket.id

  # ── Lambda targets ─────────────────────────────────────────────────────────
  dynamic "lambda_function" {
    for_each = var.lambda_notifications

    content {
      id                  = lambda_function.value.id
      lambda_function_arn = lambda_function.value.lambda_function_arn
      events              = lambda_function.value.events
      filter_prefix       = try(lambda_function.value.filter_prefix, null)
      filter_suffix       = try(lambda_function.value.filter_suffix, null)
    }
  }

  # ── SQS targets ────────────────────────────────────────────────────────────
  dynamic "queue" {
    for_each = var.sqs_notifications

    content {
      id            = queue.value.id
      queue_arn     = queue.value.queue_arn
      events        = queue.value.events
      filter_prefix = try(queue.value.filter_prefix, null)
      filter_suffix = try(queue.value.filter_suffix, null)
    }
  }

  # ── SNS targets ────────────────────────────────────────────────────────────
  dynamic "topic" {
    for_each = var.sns_notifications

    content {
      id            = topic.value.id
      topic_arn     = topic.value.topic_arn
      events        = topic.value.events
      filter_prefix = try(topic.value.filter_prefix, null)
      filter_suffix = try(topic.value.filter_suffix, null)
    }
  }

  depends_on = [
    aws_lambda_permission.s3_invoke_lambda,
    aws_sqs_queue_policy.s3_send_to_sqs,
    aws_sns_topic_policy.s3_publish_to_sns,
  ]
}

################################################################################
# Lambda Permission — allows S3 to invoke each target Lambda function
################################################################################

resource "aws_lambda_permission" "s3_invoke_lambda" {
  for_each = { for n in var.lambda_notifications : n.id => n }

  statement_id  = "AllowS3Invoke-${each.key}"
  action        = "lambda:InvokeFunction"
  function_name = each.value.lambda_function_arn
  principal     = "s3.amazonaws.com"
  source_arn    = aws_s3_bucket.s3_bucket.arn
}

################################################################################
# SQS Queue Policy — allows S3 to send messages to each target queue
################################################################################

data "aws_iam_policy_document" "s3_sqs_policy" {
  for_each = { for n in var.sqs_notifications : n.id => n }

  statement {
    sid    = "AllowS3SendMessage"
    effect = "Allow"

    principals {
      type        = "Service"
      identifiers = ["s3.amazonaws.com"]
    }

    actions   = ["sqs:SendMessage"]
    resources = [each.value.queue_arn]

    condition {
      test     = "ArnEquals"
      variable = "aws:SourceArn"
      values   = [aws_s3_bucket.s3_bucket.arn]
    }
  }
}

resource "aws_sqs_queue_policy" "s3_send_to_sqs" {
  for_each = { for n in var.sqs_notifications : n.id => n }

  queue_url = each.value.queue_url
  policy    = data.aws_iam_policy_document.s3_sqs_policy[each.key].json
}

################################################################################
# SNS Topic Policy — allows S3 to publish to each target topic
################################################################################

data "aws_iam_policy_document" "s3_sns_policy" {
  for_each = { for n in var.sns_notifications : n.id => n }

  statement {
    sid    = "AllowS3Publish"
    effect = "Allow"

    principals {
      type        = "Service"
      identifiers = ["s3.amazonaws.com"]
    }

    actions   = ["sns:Publish"]
    resources = [each.value.topic_arn]

    condition {
      test     = "ArnEquals"
      variable = "aws:SourceArn"
      values   = [aws_s3_bucket.s3_bucket.arn]
    }
  }
}

resource "aws_sns_topic_policy" "s3_publish_to_sns" {
  for_each = { for n in var.sns_notifications : n.id => n }

  arn    = each.value.topic_arn
  policy = data.aws_iam_policy_document.s3_sns_policy[each.key].json
}
