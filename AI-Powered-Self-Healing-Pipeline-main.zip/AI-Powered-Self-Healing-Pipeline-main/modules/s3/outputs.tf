################################################################################
# S3 Bucket Outputs
################################################################################

output "bucket_id" {
  description = "The name of the S3 bucket"
  value       = aws_s3_bucket.s3_bucket.id
}

output "bucket_arn" {
  description = "The ARN of the S3 bucket"
  value       = aws_s3_bucket.s3_bucket.arn
}

output "bucket_domain_name" {
  description = "The bucket domain name (bucket_name.s3.amazonaws.com)"
  value       = aws_s3_bucket.s3_bucket.bucket_domain_name
}

output "bucket_regional_domain_name" {
  description = "The bucket region-specific domain name"
  value       = aws_s3_bucket.s3_bucket.bucket_regional_domain_name
}

output "bucket_region" {
  description = "The AWS region the bucket resides in"
  value       = aws_s3_bucket.s3_bucket.region
}

################################################################################
# KMS Key Outputs
################################################################################

output "kms_key_arn" {
  description = "The ARN of the KMS key used for bucket encryption"
  value       = var.enable_kms ? aws_kms_key.s3_kms_key[0].arn : null
}

output "kms_key_id" {
  description = "The ID of the KMS key used for bucket encryption"
  value       = var.enable_kms ? aws_kms_key.s3_kms_key[0].key_id : null
}

################################################################################
# Event Notification Outputs
################################################################################

output "notification_id" {
  description = "The ID of the S3 bucket notification configuration"
  value = (
    length(var.lambda_notifications) > 0 ||
    length(var.sqs_notifications) > 0 ||
    length(var.sns_notifications) > 0
  ) ? aws_s3_bucket_notification.s3_bucket_notification[0].id : null
}

output "lambda_permission_ids" {
  description = "Map of Lambda permission statement IDs created for S3 event triggers"
  value       = { for k, v in aws_lambda_permission.s3_invoke_lambda : k => v.id }
}