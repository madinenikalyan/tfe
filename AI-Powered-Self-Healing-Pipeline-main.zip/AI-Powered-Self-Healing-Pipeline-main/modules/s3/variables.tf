################################################################################
# S3 Bucket Variables
################################################################################

variable "bucket_name" {
  description = "Name of the S3 bucket"
  type        = string
}

variable "force_destroy" {
  description = "Allow destruction of non-empty bucket"
  type        = bool
  default     = false
}

variable "object_lock_enabled" {
  description = "Enable S3 Object Lock"
  type        = bool
  default     = false
}

variable "expected_bucket_owner" {
  description = "Account ID of the expected bucket owner"
  type        = string
  default     = null
}

variable "tags" {
  description = "Tags to apply to all resources"
  type        = map(string)
  default     = {}
}

################################################################################
# Versioning Variables
################################################################################

variable "versioning_enabled" {
  description = "Enable versioning for the bucket"
  type        = bool
  default     = false
}

variable "mfa_delete" {
  description = "Enable MFA delete for versioned bucket"
  type        = string
  default     = "Disabled"
}

variable "mfa" {
  description = "MFA device serial number and TOTP token (e.g., 'SERIAL 123456'). Required only when mfa_delete is Enabled."
  type        = string
  default     = null
}

################################################################################
# Encryption Variables
################################################################################

variable "enable_server_side_encryption" {
  description = "Enable server-side encryption configuration"
  type        = bool
  default     = true
}

variable "sse_algorithm" {
  description = "SSE algorithm (AES256 or aws:kms)"
  type        = string
  default     = "AES256"
}

variable "enable_kms" {
  description = "Use KMS key for encryption instead of AES256"
  type        = bool
  default     = false
}

variable "kms_deletion_window_in_days" {
  description = "Days before KMS key is deleted after destruction"
  type        = number
  default     = 30
}

variable "kms_enable_key_rotation" {
  description = "Enable automatic KMS key rotation"
  type        = bool
  default     = true
}

################################################################################
# Public Access Block Variables
################################################################################

variable "block_public_acls" {
  description = "Block public ACLs"
  type        = bool
  default     = true
}

variable "block_public_policy" {
  description = "Block public bucket policies"
  type        = bool
  default     = true
}

variable "ignore_public_acls" {
  description = "Ignore public ACLs"
  type        = bool
  default     = true
}

variable "restrict_public_buckets" {
  description = "Restrict public bucket policies"
  type        = bool
  default     = true
}

################################################################################
# Bucket Policy Variables
################################################################################

variable "bucket_policy" {
  description = "JSON bucket policy document. Set to null to skip."
  type        = string
  default     = null
}

################################################################################
# Lifecycle Configuration Variables
################################################################################

variable "enable_lifecycle_rules" {
  description = "Enable lifecycle configuration"
  type        = bool
  default     = false
}

variable "lifecycle_rules" {
  description = "List of lifecycle rules"
  type = list(object({
    id      = string
    enabled = bool
    prefix  = optional(string, null)

    transitions = optional(list(object({
      days          = number
      storage_class = string
    })), [])

    noncurrent_version_transitions = optional(list(object({
      noncurrent_days = number
      storage_class   = string
    })), [])

    expiration = optional(object({
      days                         = optional(number, null)
      expired_object_delete_marker = optional(bool, null)
    }), null)

    noncurrent_version_expiration = optional(object({
      noncurrent_days = number
    }), null)

    abort_incomplete_multipart_upload_days = optional(number, null)
  }))
  default = []
}

################################################################################
# Event Notification Variables
################################################################################

variable "lambda_notifications" {
  description = "List of S3→Lambda event notification configurations. The module auto-creates aws_lambda_permission for each entry."
  type = list(object({
    id                  = string
    lambda_function_arn = string
    events              = list(string)
    filter_prefix       = optional(string, null)
    filter_suffix       = optional(string, null)
  }))
  default = []
}

variable "sqs_notifications" {
  description = "List of S3→SQS event notification configurations. The module auto-creates aws_sqs_queue_policy for each entry."
  type = list(object({
    id            = string
    queue_arn     = string
    queue_url     = string
    events        = list(string)
    filter_prefix = optional(string, null)
    filter_suffix = optional(string, null)
  }))
  default = []
}

variable "sns_notifications" {
  description = "List of S3→SNS event notification configurations. The module auto-creates aws_sns_topic_policy for each entry."
  type = list(object({
    id            = string
    topic_arn     = string
    events        = list(string)
    filter_prefix = optional(string, null)
    filter_suffix = optional(string, null)
  }))
  default = []
}