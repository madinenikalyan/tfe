
################################################################################
# Aurora Serverless v2 Module
#
# Creates a production-ready Aurora Serverless v2 cluster with:
#   - Dedicated KMS CMK for storage encryption and the RDS-managed
#     master-password secret (annual key rotation always enabled)
#   - Master credentials managed entirely by AWS Secrets Manager via
#     manage_master_user_password = true — no plaintext password in Terraform state
#   - Connection-config secret (endpoint, port, DB, username, password_secret_arn)
#     stored in Secrets Manager for single-path application lookup
#   - Optional Enhanced Monitoring via a module-managed IAM role (../iam),
#     disabled by default (set enable_enhanced_monitoring = true to enable)
#   - Performance Insights always enabled per instance; uses the AWS-managed
#     aws/rds key by default (override with performance_insights_kms_key_id)
#   - CloudWatch execution logs exported unconditionally:
#       PostgreSQL → iam-db-auth-error + instance + postgresql
#       MySQL     → audit + error + general + slowquery
#   - IAM database authentication enabled
#   - Cluster-level audit logging parameters for PostgreSQL (log_connections,
#     log_disconnections, log_min_duration_statement, log_statement=ddl)
#   - Serverless v2 ACU auto-scaling with configurable min/max capacity
#   - Multi-instance support via var.instances map
#   - Deletion protection enabled by default (set false only for non-prod)
#   - Automatic minor version upgrades on each instance
#
# DESIGN NOTE — manage_master_user_password:
#   When true, RDS generates a strong password and stores/rotates it in
#   Secrets Manager automatically. No master_password argument is accepted.
#   The master_user_secret_kms_key_id encrypts that secret with our CMK.
#   Application code should read credentials from the connection-config secret
#   (module output: connection_secret_arn) which contains the endpoint details
#   and a pointer to the RDS-managed password secret ARN.
#
# DESIGN NOTE — KMS key scope:
#   A single CMK is used for:
#     1. Aurora storage encryption (kms_key_id)
#     2. RDS-managed master-password secret (master_user_secret_kms_key_id)
#     3. Connection-config secret (passed to ../secrets-manager module)
#   Performance Insights uses the AWS-managed aws/rds key by default,
#   but can be overridden with var.performance_insights_kms_key_id.
#
# DESIGN NOTE — Enhanced Monitoring IAM role:
#   Delegated to the ../iam module following the same pattern as lambda and
#   api-gateway modules. The monitoring.rds.amazonaws.com service principal
#   assumes the role, which carries AmazonRDSEnhancedMonitoringRole.
#   Only created when enable_enhanced_monitoring = true.
################################################################################

################################################################################
# LOCALS
################################################################################

locals {
  # Use caller-supplied KMS key ARN when provided; otherwise the module-managed CMK.
  kms_key_arn = var.create_kms_key ? aws_kms_key.aurora_encryption[0].arn : var.kms_key_id
  kms_key_id  = var.create_kms_key ? aws_kms_key.aurora_encryption[0].key_id : var.kms_key_id

  # CloudWatch log exports — selected types for the engine.
  cloudwatch_logs_exports = var.engine == "aurora-mysql" ? [
    "audit", "error", "general", "slowquery"
  ] : ["iam-db-auth-error", "instance", "postgresql"]

  # Default audit/observability parameters for Aurora PostgreSQL clusters.
  # These are merged with any caller-supplied cluster_parameters.
  default_pg_cluster_parameters = var.engine == "aurora-mysql" ? [] : [
    { name = "log_connections", value = "1", apply_method = "immediate" },
    { name = "log_disconnections", value = "1", apply_method = "immediate" },
    { name = "log_min_duration_statement", value = "1000", apply_method = "immediate" },
    { name = "log_statement", value = "ddl", apply_method = "immediate" },
  ]
}

################################################################################
# KMS KEY — one CMK for storage, Performance Insights, and secrets
#
# Key policy grants the minimum required access to:
#   - Root account   : full administration (AWS requirement)
#   - rds.amazonaws.com : storage encryption + CreateGrant for Performance Insights
#   - secretsmanager : envelope encryption of the RDS-managed master-password secret
################################################################################

data "aws_iam_policy_document" "aurora_kms_policy" {
  count = var.create_kms_key ? 1 : 0

  # Root account retains full KMS administration.
  statement {
    sid    = "EnableRootAccountAdmin"
    effect = "Allow"
    principals {
      type        = "AWS"
      identifiers = ["arn:${var.aws_partition}:iam::${var.account_id}:root"]
    }
    actions   = ["kms:*"]
    resources = ["*"]
  }

  # RDS uses this key for storage encryption, Performance Insights encryption,
  # and to create grants for the RDS-managed master-password secret.
  statement {
    sid    = "AllowRDSServiceEncryption"
    effect = "Allow"
    principals {
      type        = "Service"
      identifiers = ["rds.amazonaws.com"]
    }
    actions = [
      "kms:Encrypt",
      "kms:Decrypt",
      "kms:ReEncrypt*",
      "kms:GenerateDataKey*",
      "kms:DescribeKey",
      "kms:CreateGrant",
      "kms:ListGrants",
      "kms:RetireGrant",
    ]
    resources = ["*"]
    condition {
      test     = "StringEquals"
      variable = "kms:CallerAccount"
      values   = [var.account_id]
    }
  }

  # Secrets Manager encrypts the RDS-managed master-password secret with this key.
  statement {
    sid    = "AllowSecretsManagerForMasterPassword"
    effect = "Allow"
    principals {
      type        = "Service"
      identifiers = ["secretsmanager.amazonaws.com"]
    }
    actions = [
      "kms:GenerateDataKey*",
      "kms:Decrypt",
      "kms:CreateGrant",
    ]
    resources = ["*"]
    condition {
      test     = "StringEquals"
      variable = "kms:CallerAccount"
      values   = [var.account_id]
    }
    condition {
      test     = "StringLike"
      variable = "kms:ViaService"
      values   = ["secretsmanager.${var.aws_region}.amazonaws.com"]
    }
  }
}

resource "aws_kms_key" "aurora_encryption" {
  count = var.create_kms_key ? 1 : 0

  description              = "KMS CMK for Aurora Serverless v2 cluster: ${var.cluster_identifier}"
  key_usage                = "ENCRYPT_DECRYPT"
  customer_master_key_spec = "SYMMETRIC_DEFAULT"
  deletion_window_in_days  = var.kms_key_deletion_window_in_days

  # Annual key rotation always enabled — required by CIS AWS Foundations Benchmark.
  enable_key_rotation = true
  multi_region        = false
  policy              = data.aws_iam_policy_document.aurora_kms_policy[0].json

  tags = merge({ Name = "${var.cluster_identifier}-aurora-cmk" }, var.tags)
}

resource "aws_kms_alias" "aurora_encryption" {
  count = var.create_kms_key ? 1 : 0

  name          = "alias/${var.cluster_identifier}-aurora"
  target_key_id = aws_kms_key.aurora_encryption[0].key_id
}

################################################################################
# ENHANCED MONITORING IAM ROLE (optional)
#
# Created only when var.enable_enhanced_monitoring = true.
# The monitoring.rds.amazonaws.com service assumes this role to push
# OS-level metrics to CloudWatch Logs.
# Delegates to ../iam following the same pattern as lambda / api-gateway modules.
################################################################################

data "aws_iam_policy_document" "aurora_monitoring_assume_role" {
  count = var.enable_enhanced_monitoring ? 1 : 0

  statement {
    sid     = "RDSEnhancedMonitoringAssumeRole"
    effect  = "Allow"
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["monitoring.rds.amazonaws.com"]
    }
  }
}

module "aurora_monitoring_role" {
  source = "../iam"
  count  = var.enable_enhanced_monitoring ? 1 : 0

  role_name          = "${var.cluster_identifier}-rds-monitoring-role"
  description        = "Allows Amazon RDS Enhanced Monitoring to publish OS metrics to CloudWatch Logs for cluster ${var.cluster_identifier}"
  path               = "/"
  assume_role_policy = data.aws_iam_policy_document.aurora_monitoring_assume_role[0].json

  aws_managed_policy_arns = [
    "arn:aws:iam::aws:policy/service-role/AmazonRDSEnhancedMonitoringRole",
  ]

  tags = var.tags
}

################################################################################
# SECURITY GROUP
################################################################################

resource "aws_security_group" "aurora_sg" {
  name        = coalesce(var.security_group_name, "${var.cluster_identifier}-sg")
  description = var.security_group_description
  vpc_id      = var.vpc_id

  dynamic "ingress" {
    for_each = var.ingress_rules
    content {
      description      = ingress.value.description
      from_port        = ingress.value.from_port
      to_port          = ingress.value.to_port
      protocol         = ingress.value.protocol
      cidr_blocks      = ingress.value.cidr_blocks
      ipv6_cidr_blocks = ingress.value.ipv6_cidr_blocks
      security_groups  = ingress.value.security_groups
      self             = ingress.value.self
    }
  }

  dynamic "egress" {
    for_each = var.egress_rules
    content {
      description      = egress.value.description
      from_port        = egress.value.from_port
      to_port          = egress.value.to_port
      protocol         = egress.value.protocol
      cidr_blocks      = egress.value.cidr_blocks
      ipv6_cidr_blocks = egress.value.ipv6_cidr_blocks
      security_groups  = egress.value.security_groups
      self             = egress.value.self
    }
  }

  tags = merge({ Name = coalesce(var.security_group_name, "${var.cluster_identifier}-sg") }, var.tags)
}

################################################################################
# DB SUBNET GROUP
################################################################################

resource "aws_db_subnet_group" "aurora_subnet_group" {
  name        = "${var.cluster_identifier}-subnet-group"
  description = "Subnet group for Aurora Serverless v2 cluster: ${var.cluster_identifier}"
  subnet_ids  = var.subnet_ids

  tags = merge({ Name = "${var.cluster_identifier}-subnet-group" }, var.tags)


}

################################################################################
# CLUSTER PARAMETER GROUP
#
# Cluster-level parameters apply to all instances in the cluster.
# For PostgreSQL: audit logging parameters are enabled by default (see locals).
# For MySQL:      audit logging is driven by the audit CloudWatch log export.
# Additional parameters can be passed via var.cluster_parameters.
################################################################################

resource "aws_rds_cluster_parameter_group" "aurora_cluster_pg" {
  name        = "${var.cluster_identifier}-cluster-pg"
  family      = var.parameter_group_family
  description = "Cluster parameter group for ${var.cluster_identifier}"

  # Default observability/audit parameters (PostgreSQL only).
  dynamic "parameter" {
    for_each = local.default_pg_cluster_parameters
    content {
      name         = parameter.value.name
      value        = parameter.value.value
      apply_method = parameter.value.apply_method
    }
  }

  # Caller-supplied cluster-level overrides.
  dynamic "parameter" {
    for_each = var.cluster_parameters
    content {
      name         = parameter.value.name
      value        = parameter.value.value
      apply_method = coalesce(parameter.value.apply_method, "pending-reboot")
    }
  }

  tags = merge({ Name = "${var.cluster_identifier}-cluster-pg" }, var.tags)

}

################################################################################
# INSTANCE PARAMETER GROUP
#
# Instance-level parameters override cluster defaults per instance.
# Empty by default — all tunable parameters (shared_preload_libraries etc.)
# live at the cluster level. Add entries via var.instance_parameters.
################################################################################

resource "aws_db_parameter_group" "aurora_instance_pg" {
  name        = "${var.cluster_identifier}-instance-pg"
  family      = var.parameter_group_family
  description = "Instance parameter group for ${var.cluster_identifier}"

  dynamic "parameter" {
    for_each = var.instance_parameters
    content {
      name         = parameter.value.name
      value        = parameter.value.value
      apply_method = coalesce(parameter.value.apply_method, "pending-reboot")
    }
  }

  tags = merge({ Name = "${var.cluster_identifier}-instance-pg" }, var.tags)

}

################################################################################
# AURORA SERVERLESS v2 CLUSTER
#
# engine_mode = "provisioned" is required for Serverless v2.
# The serverlessv2_scaling_configuration block activates Serverless v2 scaling
# on instances whose instance_class = "db.serverless".
################################################################################

resource "aws_rds_cluster" "aurora_cluster" {
  cluster_identifier = var.cluster_identifier

  # ── Engine ──────────────────────────────────────────────────────────────────
  engine      = var.engine
  engine_mode = "provisioned" # required for Serverless v2

  # engine_version is mutable — RDS applies minor-version upgrades automatically.
  # ignore_changes below prevents spurious plan diffs after auto-upgrade.
  engine_version = var.engine_version

  # ── Database ─────────────────────────────────────────────────────────────────
  database_name   = var.database_name
  master_username = var.master_username

  # ── Credentials — fully managed by AWS Secrets Manager ───────────────────────
  # RDS generates a strong password and stores/rotates it in Secrets Manager.
  # No master_password argument is used — no plaintext password in state.
  manage_master_user_password   = true
  master_user_secret_kms_key_id = local.kms_key_id

  # ── Encryption — always on with dedicated CMK ────────────────────────────────
  storage_encrypted = true
  kms_key_id        = local.kms_key_arn

  # ── Network ───────────────────────────────────────────────────────────────────
  db_subnet_group_name   = aws_db_subnet_group.aurora_subnet_group.name
  vpc_security_group_ids = [aws_security_group.aurora_sg.id]
  port                   = var.port

  # ── Parameter groups ─────────────────────────────────────────────────────────
  db_cluster_parameter_group_name = aws_rds_cluster_parameter_group.aurora_cluster_pg.name

  # ── Serverless v2 ACU scaling ─────────────────────────────────────────────────
  serverlessv2_scaling_configuration {
    min_capacity = var.min_capacity
    max_capacity = var.max_capacity
  }

  # ── Backups ───────────────────────────────────────────────────────────────────
  backup_retention_period   = var.backup_retention_period
  preferred_backup_window   = var.preferred_backup_window
  copy_tags_to_snapshot     = true
  skip_final_snapshot       = var.skip_final_snapshot
  final_snapshot_identifier = var.skip_final_snapshot ? null : "${var.cluster_identifier}-${var.final_snapshot_identifier_suffix}"

  # ── Maintenance ───────────────────────────────────────────────────────────────
  preferred_maintenance_window = var.preferred_maintenance_window
  # apply_immediately            = var.apply_immediately

  # ── Security ──────────────────────────────────────────────────────────────────
  deletion_protection                 = var.deletion_protection
  iam_database_authentication_enabled = var.enable_iam_auth

  # ── Logging — all available CloudWatch log types always exported ──────────────
  # PostgreSQL: ["postgresql", "upgrade"]
  # MySQL:      ["audit", "error", "general", "slowquery"]
  enabled_cloudwatch_logs_exports = local.cloudwatch_logs_exports

  # ── Performance Insights ──────────────────────────────────────────────────────
  performance_insights_enabled          = true
  performance_insights_kms_key_id       = var.performance_insights_kms_key_id
  performance_insights_retention_period = var.performance_insights_retention_period

  tags = merge({ Name = var.cluster_identifier }, var.tags)


  depends_on = [
    aws_kms_key.aurora_encryption,
  ]
}

################################################################################
# AURORA CLUSTER INSTANCES
#
# All instances default to instance_class = "db.serverless" (Serverless v2).
# The default var.instances creates a single writer instance.
# Add reader instances by passing additional entries with promotion_tier > 0.
#
# Enhanced Monitoring (60s) and Performance Insights (with CMK) are always on.
# Auto minor version upgrade is always enabled per instance.
################################################################################

resource "aws_rds_cluster_instance" "aurora_instance" {
  for_each = var.instances

  identifier         = coalesce(each.value.identifier, "${var.cluster_identifier}-${each.key}")
  cluster_identifier = aws_rds_cluster.aurora_cluster.id

  instance_class = coalesce(each.value.instance_class, var.instance_class)
  engine         = aws_rds_cluster.aurora_cluster.engine
  engine_version = aws_rds_cluster.aurora_cluster.engine_version

  db_subnet_group_name    = aws_db_subnet_group.aurora_subnet_group.name
  db_parameter_group_name = aws_db_parameter_group.aurora_instance_pg.name
  publicly_accessible     = false

  # Auto minor version upgrades keep the instance on the latest secure patch.
  auto_minor_version_upgrade = each.value.auto_minor_version_upgrade

  availability_zone  = each.value.availability_zone
  promotion_tier     = each.value.promotion_tier # 0 = writer priority
  ca_cert_identifier = each.value.ca_cert_identifier

  # Enhanced Monitoring — configurable via var.enable_enhanced_monitoring.
  monitoring_interval = var.enable_enhanced_monitoring ? var.monitoring_interval : 0
  monitoring_role_arn = var.enable_enhanced_monitoring ? module.aurora_monitoring_role[0].role_arn : null

  # Performance Insights — always on; uses aws/rds managed key by default.
  performance_insights_enabled          = true
  performance_insights_kms_key_id       = var.performance_insights_kms_key_id
  performance_insights_retention_period = var.performance_insights_retention_period

  tags = merge(
    { Name = coalesce(each.value.identifier, "${var.cluster_identifier}-${each.key}") },
    var.tags,
  )

  depends_on = [aws_rds_cluster.aurora_cluster]


}

################################################################################
# CONNECTION-CONFIG SECRET
#
# Stores all connection parameters in one Secrets Manager secret so that
# application code has a single consistent lookup path.
#
# Contents (JSON):
#   engine              — "aurora-postgresql" or "aurora-mysql"
#   host                — cluster writer endpoint (DNS) — alias for writer_host
#   writer_host         — cluster writer endpoint (DNS)
#   reader_host         — cluster reader endpoint (DNS)
#   port                — TCP port (string, for uniform JSON type)
#   database            — database name
#   username            — master username
#   password_secret_arn — ARN of the RDS-managed password secret
#                         (fetch from Secrets Manager at runtime using this ARN)
#
# Encrypted with the same CMK as the cluster. Rotations of the password
# are handled by RDS automatically in the password_secret_arn secret —
# this connection-config secret does not change on rotation.
################################################################################

data "aws_secretsmanager_secret_version" "master_password" {
  secret_id = aws_rds_cluster.aurora_cluster.master_user_secret[0].secret_arn

  depends_on = [aws_rds_cluster.aurora_cluster]
}

module "aurora_connection_secret" {
  source = "../secrets-manager"

  account_id = var.account_id
  aws_region = var.aws_region

  name        = "${var.cluster_identifier}-admin-credentials"
  description = "Connection parameters for Aurora Serverless v2 cluster: ${var.cluster_identifier}"

  # Reuse the cluster's CMK — avoids creating a separate key for this secret.
  kms_key_id     = local.kms_key_arn
  create_kms_key = false

  secret_string = jsonencode({
    engine              = aws_rds_cluster.aurora_cluster.engine
    host                = aws_rds_cluster.aurora_cluster.endpoint
    writer_host         = aws_rds_cluster.aurora_cluster.endpoint
    reader_host         = aws_rds_cluster.aurora_cluster.reader_endpoint
    port                = tostring(aws_rds_cluster.aurora_cluster.port)
    database            = aws_rds_cluster.aurora_cluster.database_name
    username            = aws_rds_cluster.aurora_cluster.master_username
    password            = jsondecode(data.aws_secretsmanager_secret_version.master_password.secret_string)["password"]
    password_secret_arn = aws_rds_cluster.aurora_cluster.master_user_secret[0].secret_arn

  })

  recovery_window_in_days = var.secret_recovery_window_in_days
  tags                    = var.tags
}
