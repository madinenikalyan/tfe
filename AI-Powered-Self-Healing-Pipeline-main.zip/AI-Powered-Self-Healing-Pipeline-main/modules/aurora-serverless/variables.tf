################################################################################
# AWS ACCOUNT & REGION — passed from root module
################################################################################

variable "account_id" {
  description = <<-EOT
    AWS account ID. Passed from the root module's data.aws_caller_identity.current.account_id.
    Used in KMS key policies and IAM ARN construction.
  EOT
  type        = string

  validation {
    condition     = can(regex("^[0-9]{12}$", var.account_id))
    error_message = "'account_id' must be a 12-digit AWS account ID."
  }
}

variable "aws_region" {
  description = <<-EOT
    AWS region name (e.g. "us-east-1"). Passed from the root module's data.aws_region.current.name.
    Used in KMS ViaService conditions for Secrets Manager.
  EOT
  type        = string

  validation {
    condition     = can(regex("^[a-z]{2}-[a-z]+-[0-9]{1}$", var.aws_region))
    error_message = "'aws_region' must be a valid AWS region name (e.g. 'us-east-1')."
  }
}

variable "aws_partition" {
  description = "AWS partition for ARN construction (e.g. 'aws', 'aws-cn', 'aws-us-gov')."
  type        = string
  default     = "aws"
}

################################################################################
# CLUSTER IDENTITY
################################################################################

variable "cluster_identifier" {
  description = <<-EOT
    Unique identifier for the Aurora cluster. Used as a prefix for all related
    resource names (subnet group, parameter groups, IAM role, KMS key alias, secrets).
    Must be 1–63 characters; only lowercase letters, numbers, and hyphens.
  EOT
  type        = string

  validation {
    condition     = can(regex("^[a-z0-9-]{1,63}$", var.cluster_identifier))
    error_message = "'cluster_identifier' must be 1–63 characters: lowercase letters, digits, and hyphens only."
  }
}

variable "database_name" {
  description = "Name of the initial database created inside the cluster."
  type        = string

  validation {
    condition     = length(trimspace(var.database_name)) > 0
    error_message = "'database_name' must not be empty."
  }
}

variable "master_username" {
  description = <<-EOT
    Master username for the database. Immutable after cluster creation.
    Avoid reserved names (e.g. "admin", "root", "master" for PostgreSQL).
    For Aurora PostgreSQL the default superuser is typically "postgres".
  EOT
  type        = string

  validation {
    condition     = length(trimspace(var.master_username)) > 0
    error_message = "'master_username' must not be empty."
  }
}

################################################################################
# ENGINE
################################################################################

variable "engine" {
  description = <<-EOT
    Aurora engine type.
      "aurora-postgresql" — Amazon Aurora PostgreSQL-compatible (default)
      "aurora-mysql"      — Amazon Aurora MySQL-compatible

    The engine determines:
      - CloudWatch log exports (postgresql+upgrade vs audit+error+general+slowquery)
      - Default cluster parameter group family
      - Default port (5432 vs 3306)
  EOT
  type        = string
  default     = "aurora-postgresql"

  validation {
    condition     = contains(["aurora-postgresql", "aurora-mysql"], var.engine)
    error_message = "'engine' must be either \"aurora-postgresql\" or \"aurora-mysql\"."
  }
}

variable "engine_version" {
  description = <<-EOT
    Aurora engine version. Must be compatible with the selected engine.
    Aurora PostgreSQL examples: "16.4", "15.8", "14.13"
    Aurora MySQL examples:      "8.0.mysql_aurora.3.06.0", "3.05.2"
    Check aws rds describe-db-engine-versions for available versions.
  EOT
  type        = string
  default     = "17.4"
}

variable "parameter_group_family" {
  description = <<-EOT
    Parameter group family used for both the cluster and instance parameter groups.
    Must match the engine and major version.
    Aurora PostgreSQL examples: "aurora-postgresql17", "aurora-postgresql16", "aurora-postgresql15"
    Aurora MySQL examples:      "aurora-mysql8.0", "aurora-mysql5.7"
  EOT
  type        = string
  default     = "aurora-postgresql17"

  validation {
    condition     = startswith(var.parameter_group_family, "aurora-")
    error_message = "'parameter_group_family' must start with 'aurora-' (e.g. 'aurora-postgresql16', 'aurora-mysql8.0')."
  }
}

variable "port" {
  description = <<-EOT
    TCP port the cluster listens on.
    Default 5432 for PostgreSQL; change to 3306 for MySQL.
  EOT
  type        = number
  default     = 5432

  validation {
    condition     = var.port > 0 && var.port < 65536
    error_message = "'port' must be between 1 and 65535."
  }
}

################################################################################
# SERVERLESS v2 SCALING
################################################################################

variable "min_capacity" {
  description = <<-EOT
    Minimum Aurora Capacity Units (ACUs) for Serverless v2 auto-scaling.
    Valid values: 0 to 256, in increments of 0.5 (e.g. 0, 0.5, 1, 2).
    Use 0 to allow scaling to zero (pause when idle, only available for Aurora PostgreSQL).
    Default: 0.5 ACU — keeps the cluster warm and avoids cold-start latency.
  EOT
  type        = number
  default     = 0.5

  validation {
    condition     = var.min_capacity >= 0 && var.min_capacity <= 256
    error_message = "'min_capacity' must be between 0 and 256."
  }
}

variable "max_capacity" {
  description = <<-EOT
    Maximum Aurora Capacity Units (ACUs) for Serverless v2 auto-scaling.
    Valid values: 1 to 256, in increments of 0.5 (e.g. 1, 2, 4, 8, 16, 32).
    Aurora scales up to this limit under peak load. Set conservatively to control cost.
    Default: 16 ACU.
  EOT
  type        = number
  default     = 16

  validation {
    condition     = var.max_capacity >= 1 && var.max_capacity <= 256
    error_message = "'max_capacity' must be between 1 and 256."
  }
}

################################################################################
# NETWORKING
################################################################################

variable "subnet_ids" {
  description = <<-EOT
    List of private subnet IDs for the DB subnet group.
    Must span at least two Availability Zones for Multi-AZ support.
    Use private subnets only — RDS instances are never publicly accessible.
  EOT
  type        = list(string)

  validation {
    condition     = length(var.subnet_ids) >= 2
    error_message = "'subnet_ids' must contain at least two subnet IDs (one per AZ) for Multi-AZ."
  }
}

variable "vpc_id" {
  description = <<-EOT
    ID of the VPC where the Aurora cluster security group will be created.
    Must be the same VPC as the subnets in var.subnet_ids.
  EOT
  type        = string
}

################################################################################
# SECURITY GROUP
################################################################################

variable "security_group_name" {
  description = "Name of the security group. Defaults to '{cluster_identifier}-sg' when null."
  type        = string
  default     = null
}

variable "security_group_description" {
  description = "Description for the module-created security group."
  type        = string
  default     = "Managed by Aurora Serverless v2 Terraform module"
}

variable "ingress_rules" {
  description = <<-EOT
    List of ingress rules applied to the Aurora security group.
    Typically allows inbound on var.port from application subnets or security groups.

    Fields:
      description      – human-readable description for the rule
      from_port        – start of the port range
      to_port          – end of the port range
      protocol         – "tcp", "udp", "icmp", or "-1" (all)
      cidr_blocks      – list of IPv4 CIDR blocks
      ipv6_cidr_blocks – list of IPv6 CIDR blocks
      security_groups  – list of source security group IDs
      self             – whether the SG itself is a source

    Example:
      ingress_rules = [
        {
          description = "PostgreSQL from Lambda subnets"
          from_port   = 5432
          to_port     = 5432
          protocol    = "tcp"
          cidr_blocks = ["10.0.1.0/24", "10.0.2.0/24"]
        }
      ]
  EOT
  type = list(object({
    description      = optional(string, "")
    from_port        = number
    to_port          = number
    protocol         = string
    cidr_blocks      = optional(list(string), [])
    ipv6_cidr_blocks = optional(list(string), [])
    security_groups  = optional(list(string), [])
    self             = optional(bool, false)
  }))
  default = []
}

variable "egress_rules" {
  description = <<-EOT
    List of egress rules applied to the Aurora security group.
    Defaults to allow-all outbound.

    Fields mirror var.ingress_rules.
  EOT
  type = list(object({
    description      = optional(string, "")
    from_port        = number
    to_port          = number
    protocol         = string
    cidr_blocks      = optional(list(string), [])
    ipv6_cidr_blocks = optional(list(string), [])
    security_groups  = optional(list(string), [])
    self             = optional(bool, false)
  }))
  default = [
    {
      description = "Allow all outbound traffic"
      from_port   = 0
      to_port     = 0
      protocol    = "-1"
      cidr_blocks = ["0.0.0.0/0"]
    }
  ]
}

################################################################################
# INSTANCES
################################################################################

variable "instance_class" {
  description = <<-EOT
    Default DB instance class for all instances in the cluster.
    Use "db.serverless" for Serverless v2 auto-scaling, or a provisioned class
    such as "db.r6g.large", "db.r6g.xlarge", "db.r7g.large", etc.
    Individual instances can override this via the instance_class attribute
    in the instances map.
  EOT
  type        = string
  default     = "db.serverless"
}

variable "instances" {
  description = <<-EOT
    Map of Aurora instances to create in the cluster. Each key is a unique
    instance label used to build the identifier and as a Terraform resource key.

    instance_class:             Override the module-level var.instance_class for
                                this specific instance. Leave null to inherit
                                the module default.
    identifier:                 Override the auto-generated instance identifier.
                                Defaults to "{cluster_identifier}-{key}".
    availability_zone:          Pin the instance to a specific AZ. Leave null for
                                AWS-managed AZ placement.
    auto_minor_version_upgrade: Automatically apply minor engine-version patches.
                                Default: true (recommended for security patching).
    promotion_tier:             Failover priority. 0 = highest (writer); 1–15 = readers.
    ca_cert_identifier:         Certificate authority for TLS. Leave null to use
                                the cluster default.

    Default: one writer instance with all defaults — suitable for development and
    low-traffic production workloads. Add reader instances for read scaling or HA.

    Example (writer + two readers across AZs):
      instances = {
        "writer"    = { promotion_tier = 0 }
        "reader-1"  = { promotion_tier = 1, availability_zone = "us-east-1b" }
        "reader-2"  = { promotion_tier = 1, availability_zone = "us-east-1c" }
      }
  EOT
  type = map(object({
    identifier                 = optional(string)
    instance_class             = optional(string)
    availability_zone          = optional(string)
    auto_minor_version_upgrade = optional(bool, true)
    promotion_tier             = optional(number, 0)
    ca_cert_identifier         = optional(string)
  }))
  default = {
    "1" = {} # single writer with all defaults
  }
}

################################################################################
# BACKUPS & MAINTENANCE
################################################################################

variable "backup_retention_period" {
  description = <<-EOT
    Number of days to retain automated cluster backups. Valid range: 1–35.
    Default: 7 days. Use 14–35 for production workloads with strict RPO requirements.
  EOT
  type        = number
  default     = 7

  validation {
    condition     = var.backup_retention_period >= 1 && var.backup_retention_period <= 35
    error_message = "'backup_retention_period' must be between 1 and 35."
  }
}

variable "preferred_backup_window" {
  description = <<-EOT
    Daily time range (UTC) when automated backups are created.
    Format: "hh:mm-hh:mm". Must not overlap with preferred_maintenance_window.
    Default: "03:00-04:00" (low-traffic window in UTC).
  EOT
  type        = string
  default     = "03:00-04:00"
}

variable "preferred_maintenance_window" {
  description = <<-EOT
    Weekly time range (UTC) for cluster maintenance (minor upgrades, patches).
    Format: "ddd:hh:mm-ddd:hh:mm". Must not overlap with preferred_backup_window.
    Default: "sun:04:00-sun:05:00".
  EOT
  type        = string
  default     = "sun:04:00-sun:05:00"
}

# variable "apply_immediately" {
#   description = <<-EOT
#     Whether to apply cluster modifications immediately or during the next maintenance window.
#     Default: false (recommended for production to avoid unexpected restarts).
#     Set to true in non-production environments to speed up iteration.
#   EOT
#   type        = bool
#   default     = false
# }

variable "skip_final_snapshot" {
  description = <<-EOT
    Skip the final snapshot when the cluster is destroyed. Default: false.
    Set to true only for non-production / ephemeral clusters.
    When false, a final snapshot is created with identifier:
      "{cluster_identifier}-{final_snapshot_identifier_suffix}"
  EOT
  type        = bool
  default     = false
}

variable "final_snapshot_identifier_suffix" {
  description = "Suffix appended to the cluster identifier to form the final snapshot name."
  type        = string
  default     = "final"
}

variable "deletion_protection" {
  description = <<-EOT
    Prevent accidental cluster deletion. Default: true.
    Must be set to false before the cluster can be destroyed with Terraform.
    Always leave true for production clusters.
  EOT
  type        = bool
  default     = true
}

variable "enable_iam_auth" {
  description = "Enable IAM database authentication for the Aurora cluster."
  type        = bool
  default     = false
}

################################################################################
# KMS ENCRYPTION
################################################################################

variable "kms_key_id" {
  description = <<-EOT
    ARN or ID of an existing KMS CMK to use for ALL encryption in this module:
      - Aurora storage encryption
      - RDS-managed master-password secret
      - Connection-config secret
    Leave null (default) to create a dedicated module-managed CMK automatically.
    When supplying an external key, also set create_kms_key = false.
    The module always encrypts — the AWS-managed default key is never used.
  EOT
  type        = string
  default     = null
}

variable "create_kms_key" {
  description = <<-EOT
    Whether the module should create a dedicated KMS CMK.
    Set to false when passing an existing key via var.kms_key_id.
    This avoids count issues with computed kms_key_id values.
  EOT
  type        = bool
  default     = true
}

variable "kms_key_deletion_window_in_days" {
  description = <<-EOT
    Days to wait before permanently deleting the module-managed KMS key on destroy.
    Valid range: 7–30. Default: 30.
    Ignored when var.kms_key_id is supplied (caller-managed key).
  EOT
  type        = number
  default     = 30

  validation {
    condition     = var.kms_key_deletion_window_in_days >= 7 && var.kms_key_deletion_window_in_days <= 30
    error_message = "'kms_key_deletion_window_in_days' must be between 7 and 30."
  }
}

################################################################################
# PERFORMANCE INSIGHTS
################################################################################

variable "performance_insights_retention_period" {
  description = <<-EOT
    Retention period in days for Performance Insights data.
    Valid values: 7 (free tier) or 731 (2 years, paid tier).
    Default: 7 days (free tier).
  EOT
  type        = number
  default     = 7

  validation {
    condition     = contains([7, 731], var.performance_insights_retention_period)
    error_message = "'performance_insights_retention_period' must be 7 (free) or 731 (2-year paid tier)."
  }
}

variable "performance_insights_kms_key_id" {
  description = <<-EOT
    KMS key ARN for Performance Insights encryption.
    When null (default), the AWS-managed aws/rds key is used.
    Pass a CMK ARN to use a customer-managed key.
  EOT
  type        = string
  default     = null
}

################################################################################
# ENHANCED MONITORING
################################################################################

variable "enable_enhanced_monitoring" {
  description = <<-EOT
    Enable Enhanced Monitoring for cluster instances.
    When true, an IAM role is created and OS-level metrics are published to CloudWatch.
    When false (default), Enhanced Monitoring is disabled.
  EOT
  type        = bool
  default     = false
}

variable "monitoring_interval" {
  description = <<-EOT
    Interval (in seconds) between Enhanced Monitoring data points.
    Valid values: 0, 1, 5, 10, 15, 30, 60.
    0 disables Enhanced Monitoring. Only used when enable_enhanced_monitoring = true.
  EOT
  type        = number
  default     = 60

  validation {
    condition     = contains([0, 1, 5, 10, 15, 30, 60], var.monitoring_interval)
    error_message = "'monitoring_interval' must be one of: 0, 1, 5, 10, 15, 30, 60."
  }
}

################################################################################
# PARAMETER GROUPS — custom parameters
################################################################################

variable "cluster_parameters" {
  description = <<-EOT
    Additional cluster-level parameters. These are merged with the module's
    built-in audit/logging defaults (PostgreSQL only).
    Caller-supplied parameters with the same name override the module defaults.

    apply_method: "immediate" or "pending-reboot" (default: "pending-reboot").

    Example:
      cluster_parameters = [
        { name = "max_locks_per_transaction", value = "500", apply_method = "pending-reboot" }
        { name = "shared_preload_libraries",  value = "pg_stat_statements", apply_method = "pending-reboot" }
      ]
  EOT
  type = list(object({
    name         = string
    value        = string
    apply_method = optional(string)
  }))
  default = []
}

variable "instance_parameters" {
  description = <<-EOT
    Instance-level parameter overrides applied to all instances via the shared
    instance parameter group. Most Aurora tuning lives at the cluster level;
    use this only for instance-specific settings.

    apply_method: "immediate" or "pending-reboot" (default: "pending-reboot").

    Example:
      instance_parameters = [
        { name = "effective_cache_size", value = "524288", apply_method = "pending-reboot" }
      ]
  EOT
  type = list(object({
    name         = string
    value        = string
    apply_method = optional(string)
  }))
  default = []
}

################################################################################
# SECRETS MANAGER
################################################################################

variable "secret_recovery_window_in_days" {
  description = <<-EOT
    Number of days Secrets Manager waits before permanently deleting the
    connection-config secret (0 or 7–30). Default: 30.
  EOT
  type        = number
  default     = 30

  validation {
    condition     = var.secret_recovery_window_in_days == 0 || (var.secret_recovery_window_in_days >= 7 && var.secret_recovery_window_in_days <= 30)
    error_message = "'secret_recovery_window_in_days' must be 0 or between 7 and 30."
  }
}

################################################################################
# TAGS
################################################################################

variable "tags" {
  description = "Map of tags applied to all taggable resources in this module."
  type        = map(string)
  default     = {}
}
