################################################################################
# CLUSTER
################################################################################

output "cluster_id" {
  description = "ID of the Aurora cluster."
  value       = aws_rds_cluster.aurora_cluster.id
}

output "cluster_arn" {
  description = "ARN of the Aurora cluster."
  value       = aws_rds_cluster.aurora_cluster.arn
}

output "cluster_identifier" {
  description = "Cluster identifier as deployed."
  value       = aws_rds_cluster.aurora_cluster.cluster_identifier
}

output "cluster_resource_id" {
  description = "RDS cluster resource ID (region-unique, begins with 'cluster-'). Required for IAM database authentication policies."
  value       = aws_rds_cluster.aurora_cluster.cluster_resource_id
}

################################################################################
# ENDPOINTS
################################################################################

output "cluster_endpoint" {
  description = <<-EOT
    DNS hostname of the writer endpoint.
    All write operations (INSERT, UPDATE, DELETE, DDL) should target this endpoint.
    Format: {cluster-id}.cluster-{id}.{region}.rds.amazonaws.com
  EOT
  value       = aws_rds_cluster.aurora_cluster.endpoint
}

output "cluster_reader_endpoint" {
  description = <<-EOT
    DNS hostname of the reader endpoint. Routes connections to available reader instances.
    All read-only operations should target this endpoint for load distribution.
    Falls back to the writer endpoint if there are no dedicated reader instances.
  EOT
  value       = aws_rds_cluster.aurora_cluster.reader_endpoint
}

output "cluster_port" {
  description = "TCP port the cluster accepts connections on."
  value       = aws_rds_cluster.aurora_cluster.port
}

################################################################################
# DATABASE
################################################################################

output "database_name" {
  description = "Name of the initial database created inside the cluster."
  value       = aws_rds_cluster.aurora_cluster.database_name
}

output "master_username" {
  description = "Master username for the cluster. The password is managed by Secrets Manager."
  value       = aws_rds_cluster.aurora_cluster.master_username
}

################################################################################
# CREDENTIALS & SECRETS
################################################################################

output "master_user_secret_arn" {
  description = <<-EOT
    ARN of the AWS-managed master-password secret in Secrets Manager.
    Managed and rotated automatically by Amazon RDS.
    Application code should fetch the password from this secret at runtime.
    Format of the secret value:
      { "username": "...", "password": "...", "engine": "...",
        "host": "...", "port": ..., "dbClusterIdentifier": "..." }
  EOT
  value       = aws_rds_cluster.aurora_cluster.master_user_secret[0].secret_arn
}

output "connection_secret_arn" {
  description = <<-EOT
    ARN of the module-managed connection-config secret in Secrets Manager.
    Contains all parameters needed to connect:
      engine, host, writer_host, reader_host, port, database, username, password_secret_arn.
    Application code should read this secret first, then fetch the password from
    the nested password_secret_arn.
  EOT
  value       = module.aurora_connection_secret.secret_arn
}

output "connection_secret_name" {
  description = "Name of the connection-config secret in Secrets Manager."
  value       = module.aurora_connection_secret.secret_name
}

################################################################################
# ENCRYPTION
################################################################################

output "kms_key_arn" {
  description = <<-EOT
    ARN of the KMS CMK used for storage encryption, Performance Insights, and secrets.
    Either the module-managed CMK or the caller-supplied key (var.kms_key_id).
  EOT
  value       = local.kms_key_arn
}

output "kms_key_id" {
  description = "ID of the module-managed KMS CMK. Null when var.kms_key_id is supplied."
  value       = length(aws_kms_key.aurora_encryption) > 0 ? aws_kms_key.aurora_encryption[0].key_id : null
}

output "kms_alias_name" {
  description = "KMS alias name for the module-managed CMK. Null when var.kms_key_id is supplied."
  value       = length(aws_kms_alias.aurora_encryption) > 0 ? aws_kms_alias.aurora_encryption[0].name : null
}

################################################################################
# IAM — ENHANCED MONITORING ROLE
################################################################################

output "monitoring_role_arn" {
  description = <<-EOT
    ARN of the IAM role used by Amazon RDS Enhanced Monitoring.
    Null when enable_enhanced_monitoring = false.
  EOT
  value       = var.enable_enhanced_monitoring ? module.aurora_monitoring_role[0].role_arn : null
}

output "monitoring_role_name" {
  description = "Name of the Enhanced Monitoring IAM role. Null when enable_enhanced_monitoring = false."
  value       = var.enable_enhanced_monitoring ? module.aurora_monitoring_role[0].role_name : null
}

################################################################################
# INSTANCES
################################################################################

output "instance_ids" {
  description = "Map of instance label → instance identifier for all cluster instances."
  value       = { for k, i in aws_rds_cluster_instance.aurora_instance : k => i.identifier }
}

output "instance_endpoints" {
  description = "Map of instance label → instance-specific endpoint (useful for pinning specific connections)."
  value       = { for k, i in aws_rds_cluster_instance.aurora_instance : k => i.endpoint }
}

output "instance_arns" {
  description = "Map of instance label → instance ARN."
  value       = { for k, i in aws_rds_cluster_instance.aurora_instance : k => i.arn }
}

################################################################################
# SECURITY GROUP
################################################################################

output "security_group_id" {
  description = "ID of the security group created for the Aurora cluster."
  value       = aws_security_group.aurora_sg.id
}

output "security_group_arn" {
  description = "ARN of the security group created for the Aurora cluster."
  value       = aws_security_group.aurora_sg.arn
}

output "security_group_name" {
  description = "Name of the security group created for the Aurora cluster."
  value       = aws_security_group.aurora_sg.name
}

################################################################################
# NETWORKING
################################################################################

output "subnet_group_name" {
  description = "Name of the DB subnet group created for this cluster."
  value       = aws_db_subnet_group.aurora_subnet_group.name
}

output "subnet_group_arn" {
  description = "ARN of the DB subnet group."
  value       = aws_db_subnet_group.aurora_subnet_group.arn
}

################################################################################
# PARAMETER GROUPS
################################################################################

output "cluster_parameter_group_name" {
  description = "Name of the cluster parameter group."
  value       = aws_rds_cluster_parameter_group.aurora_cluster_pg.name
}

output "instance_parameter_group_name" {
  description = "Name of the instance parameter group shared by all instances."
  value       = aws_db_parameter_group.aurora_instance_pg.name
}

################################################################################
# ENGINE
################################################################################

output "engine" {
  description = "Aurora engine type (aurora-postgresql or aurora-mysql)."
  value       = aws_rds_cluster.aurora_cluster.engine
}

output "engine_version_actual" {
  description = <<-EOT
    Actual engine version running on the cluster after minor-version upgrades.
    May differ from var.engine_version after auto-upgrades are applied.
  EOT
  value       = aws_rds_cluster.aurora_cluster.engine_version_actual
}
