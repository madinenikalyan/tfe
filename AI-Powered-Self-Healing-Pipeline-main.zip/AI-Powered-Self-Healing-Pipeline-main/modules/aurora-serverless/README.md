# `modules/aurora-serverless` — Production-Ready Aurora Serverless v2 Module

A Terraform module for provisioning an AWS Aurora Serverless v2 cluster with
KMS encryption, managed credentials, optional Enhanced Monitoring, Performance
Insights, a built-in security group, and a connection-config secret in Secrets Manager.

---

## Features

| Feature | Details |
|---|---|
| **Serverless v2** | Auto-scaling ACUs with configurable min/max capacity (0.5–256) |
| **KMS encryption** | Dedicated CMK auto-created for storage and secrets (annual rotation always on) |
| **Managed credentials** | `manage_master_user_password = true` — RDS generates, stores, and rotates the password in Secrets Manager |
| **Connection secret** | Module-managed secret with endpoint, port, DB, username, and password_secret_arn for single-path app lookup |
| **Security group** | Built-in SG with configurable ingress/egress rules — no external SG required |
| **Enhanced Monitoring** | Disabled by default; enable with `enable_enhanced_monitoring = true` (creates IAM role via `../iam`) |
| **Performance Insights** | Always enabled; uses AWS-managed `aws/rds` key by default (override with `performance_insights_kms_key_id`) |
| **CloudWatch logs** | All available log types exported unconditionally (PostgreSQL: iam-db-auth-error + instance + postgresql; MySQL: audit + error + general + slowquery) |
| **IAM auth** | IAM database authentication always enabled |
| **Audit logging** | PostgreSQL: log_connections, log_disconnections, log_min_duration_statement, log_statement=ddl |
| **Multi-instance** | Configurable writer + reader instances via `var.instances` map |
| **Deletion protection** | Enabled by default (set false only for non-prod) |

---

## Design Decisions

### Managed Master Password

When `manage_master_user_password = true`, RDS generates a strong password and
stores/rotates it in Secrets Manager automatically. No `master_password` argument
is used — no plaintext password in Terraform state. Application code reads
credentials from the connection-config secret (output: `connection_secret_arn`).

### Single KMS CMK

A single CMK is used for storage encryption, the RDS-managed master-password
secret, and the connection-config secret. Performance Insights uses the
AWS-managed `aws/rds` key by default but can be overridden with
`performance_insights_kms_key_id`.

### Built-in Security Group

The module creates a dedicated security group. Callers pass `ingress_rules` and
`egress_rules` to control network access. This follows the same pattern as the
Lambda module and keeps SG lifecycle tied to the cluster. Egress defaults to
allow-all outbound.

### No Data Blocks

`account_id` and `aws_region` are passed as variables rather than looked up via
`data "aws_caller_identity"` / `data "aws_region"`. This avoids duplicate data-source
calls when the root module already has them.

---

## Usage

### Minimal — PostgreSQL with Lambda access

```hcl
module "aurora_postgres" {
  source = "./modules/aurora-serverless"

  account_id = data.aws_caller_identity.current.account_id
  aws_region = var.aws_region

  cluster_identifier = "${local.name_prefix}-aurora-postgres"
  database_name      = "myapp"
  master_username    = "dbadmin"

  vpc_id     = aws_vpc.main.id
  subnet_ids = aws_subnet.private_db[*].id

  ingress_rules = [
    {
      description = "PostgreSQL from Lambda subnets"
      from_port   = 5432
      to_port     = 5432
      protocol    = "tcp"
      cidr_blocks = ["10.0.1.0/24", "10.0.2.0/24"]
    }
  ]

  tags = local.common_tags
}
```

### With reader instances and custom scaling

```hcl
module "aurora_production" {
  source = "./modules/aurora-serverless"

  account_id = data.aws_caller_identity.current.account_id
  aws_region = var.aws_region

  cluster_identifier = "prod-sales-aurora"
  database_name      = "salesdb"
  master_username    = "dbadmin"

  engine                 = "aurora-postgresql"
  engine_version         = "17.4"
  parameter_group_family = "aurora-postgresql17"

  vpc_id     = aws_vpc.main.id
  subnet_ids = aws_subnet.private_db[*].id

  ingress_rules = [
    {
      description     = "PostgreSQL from app security group"
      from_port       = 5432
      to_port         = 5432
      protocol        = "tcp"
      security_groups = [aws_security_group.app.id]
    }
  ]

  min_capacity = 2
  max_capacity = 64

  instances = {
    "writer"   = { promotion_tier = 0 }
    "reader-1" = { promotion_tier = 1, availability_zone = "us-east-1a" }
    "reader-2" = { promotion_tier = 1, availability_zone = "us-east-1b" }
  }

  backup_retention_period = 14
  deletion_protection     = true

  tags = local.common_tags
}
```

### With external KMS key

```hcl
module "aurora_shared_key" {
  source = "./modules/aurora-serverless"

  account_id = data.aws_caller_identity.current.account_id
  aws_region = var.aws_region

  cluster_identifier = "shared-aurora"
  database_name      = "appdb"
  master_username    = "admin"

  vpc_id     = aws_vpc.main.id
  subnet_ids = aws_subnet.private_db[*].id
  kms_key_id = aws_kms_key.shared.arn

  ingress_rules = [
    {
      description = "PostgreSQL from app subnets"
      from_port   = 5432
      to_port     = 5432
      protocol    = "tcp"
      cidr_blocks = ["10.0.0.0/16"]
    }
  ]

  tags = local.common_tags
}
```

---

## Inputs

| Variable | Type | Default | Description |
|---|---|---|---|
| `account_id` | `string` | required | AWS account ID (12-digit) |
| `aws_region` | `string` | required | AWS region name (e.g. `us-east-1`) |
| `aws_partition` | `string` | `"aws"` | AWS partition for ARN construction |
| `cluster_identifier` | `string` | required | Unique cluster identifier (1–63 chars, lowercase) |
| `database_name` | `string` | required | Initial database name |
| `master_username` | `string` | required | Master username |
| `engine` | `string` | `"aurora-postgresql"` | Engine type: `aurora-postgresql` or `aurora-mysql` |
| `engine_version` | `string` | `"17.4"` | Engine version |
| `parameter_group_family` | `string` | `"aurora-postgresql17"` | Parameter group family |
| `port` | `number` | `5432` | TCP port (5432 for PostgreSQL, 3306 for MySQL) |
| `min_capacity` | `number` | `0.5` | Minimum ACUs for Serverless v2 scaling |
| `max_capacity` | `number` | `16` | Maximum ACUs for Serverless v2 scaling |
| `vpc_id` | `string` | required | VPC ID for the security group |
| `subnet_ids` | `list(string)` | required | Private subnet IDs (at least 2 AZs) |
| `security_group_name` | `string` | `null` | SG name override (defaults to `{cluster_identifier}-sg`) |
| `security_group_description` | `string` | `"Managed by..."` | SG description |
| `ingress_rules` | `list(object)` | `[]` | Ingress rules for the Aurora SG |
| `egress_rules` | `list(object)` | allow-all | Egress rules for the Aurora SG |
| `instances` | `map(object)` | 1 writer | Instance map (writer + readers) |
| `backup_retention_period` | `number` | `7` | Automated backup retention (1–35 days) |
| `preferred_backup_window` | `string` | `"03:00-04:00"` | Daily backup window (UTC) |
| `preferred_maintenance_window` | `string` | `"sun:04:00-sun:05:00"` | Weekly maintenance window |
<!-- | `apply_immediately` | `bool` | `false` | Apply changes immediately vs maintenance window | -->
| `skip_final_snapshot` | `bool` | `false` | Skip final snapshot on destroy |
| `final_snapshot_identifier_suffix` | `string` | `"final"` | Final snapshot name suffix |
| `deletion_protection` | `bool` | `true` | Prevent accidental cluster deletion |
| `kms_key_id` | `string` | `null` | Existing KMS CMK ARN; null creates a dedicated CMK |
| `kms_key_deletion_window_in_days` | `number` | `30` | KMS key deletion wait (7–30 days) |
| `performance_insights_retention_period` | `number` | `7` | Performance Insights retention (7 free, 731 paid) |
| `performance_insights_kms_key_id` | `string` | `null` | KMS key ARN for Performance Insights; null uses AWS-managed `aws/rds` key |
| `enable_enhanced_monitoring` | `bool` | `false` | Enable Enhanced Monitoring (creates IAM role) |
| `monitoring_interval` | `number` | `60` | Enhanced Monitoring interval in seconds (1, 5, 10, 15, 30, or 60) |
| `cluster_parameters` | `list(object)` | `[]` | Additional cluster-level parameters |
| `instance_parameters` | `list(object)` | `[]` | Instance-level parameter overrides |
| `secret_recovery_window_in_days` | `number` | `30` | Connection secret soft-delete window |
| `tags` | `map(string)` | `{}` | Tags applied to all resources |

---

## Outputs

| Output | Description |
|---|---|
| `cluster_id` | ID of the Aurora cluster |
| `cluster_arn` | ARN of the Aurora cluster |
| `cluster_identifier` | Cluster identifier as deployed |
| `cluster_resource_id` | RDS cluster resource ID |
| `cluster_endpoint` | Writer endpoint DNS hostname |
| `cluster_reader_endpoint` | Reader endpoint DNS hostname |
| `cluster_port` | TCP port |
| `database_name` | Initial database name |
| `master_username` | Master username |
| `master_user_secret_arn` | ARN of the RDS-managed password secret |
| `connection_secret_arn` | ARN of the connection-config secret |
| `connection_secret_name` | Name of the connection-config secret |
| `kms_key_arn` | ARN of the KMS key (module-managed or caller-supplied) |
| `kms_key_id` | KMS CMK ID (null when caller supplies key) |
| `kms_alias_name` | KMS alias name (null when caller supplies key) |
| `monitoring_role_arn` | ARN of the Enhanced Monitoring IAM role (null when disabled) |
| `monitoring_role_name` | Name of the Enhanced Monitoring IAM role (null when disabled) |
| `security_group_id` | ID of the module-created security group |
| `security_group_arn` | ARN of the module-created security group |
| `security_group_name` | Name of the module-created security group |
| `instance_ids` | Map of label → instance identifier |
| `instance_endpoints` | Map of label → instance endpoint |
| `instance_arns` | Map of label → instance ARN |
| `subnet_group_name` | Name of the DB subnet group |
| `subnet_group_arn` | ARN of the DB subnet group |
| `cluster_parameter_group_name` | Cluster parameter group name |
| `instance_parameter_group_name` | Instance parameter group name |
| `engine` | Engine type |
| `engine_version_actual` | Actual running engine version |

---

## Notes

- **Security group rules**: The module creates the SG with your `ingress_rules` and
  `egress_rules`. Egress defaults to allow-all outbound. Ingress defaults to empty —
  you must pass at least one rule to allow application access.
- **Caller-managed KMS**: When `kms_key_id` is supplied, no CMK is created. The
  caller is responsible for KMS key policy and lifecycle.
- **Connection secret**: Contains `engine`, `host`, `reader_host`, `port`, `database`,
  `username`, and `password_secret_arn`. Application code fetches the password
  from the nested `password_secret_arn` at runtime.
- **IAM database auth**: Always enabled. Create IAM policies referencing
  `cluster_resource_id` for fine-grained database access control.
- **Deletion protection**: Always `true` by default. Must be set to `false` before
  destroying a cluster with Terraform.
