################################################################################
# VPC Endpoint Service Module (PrivateLink Provider)
#
# Creates an AWS VPC Endpoint Service that exposes a Network Load Balancer
# (NLB) or Gateway Load Balancer (GWLB) to consumers in the same or other
# AWS accounts via PrivateLink.
#
# DESIGN NOTES:
#   • Exactly one of gateway_load_balancer_arns or network_load_balancer_arns
#     must be supplied. The module validates this at plan time.
#   • acceptance_required defaults to true — the service owner must manually
#     accept every VPC endpoint connection request. Set to false only for
#     trusted, same-account consumers or when allowed_principals covers
#     the full trust boundary.
#   • allowed_principals restricts which AWS accounts/IAM principals can
#     create endpoints against this service. Empty = no restrictions beyond
#     the acceptance gate.
#   • private_dns_name is optional. When set, AWS generates a TXT record
#     that must be added to the public DNS zone to prove domain ownership
#     before private DNS resolution is enabled for consumers.
#   • supported_ip_address_types defaults to ["ipv4"]. Add "ipv6" only if
#     the backing LB and targets support dual-stack.
#   • An optional SNS topic ARN can be provided to receive endpoint
#     connection notifications (accept, reject, delete events).
################################################################################

################################################################################
# VPC ENDPOINT SERVICE
################################################################################

resource "aws_vpc_endpoint_service" "vpc_endpoint_svc" {
  acceptance_required = var.acceptance_required

  gateway_load_balancer_arns = length(var.gateway_load_balancer_arns) > 0 ? var.gateway_load_balancer_arns : null
  network_load_balancer_arns = length(var.network_load_balancer_arns) > 0 ? var.network_load_balancer_arns : null

  lifecycle {
    precondition {
      condition     = (length(var.network_load_balancer_arns) > 0) != (length(var.gateway_load_balancer_arns) > 0)
      error_message = "Specify exactly one of network_load_balancer_arns or gateway_load_balancer_arns."
    }
  }

  supported_ip_address_types = var.supported_ip_address_types

  private_dns_name = var.private_dns_name

  tags = merge(var.tags, {
    Name = var.name
  })
}

################################################################################
# ALLOWED PRINCIPALS
#
# Each principal is an ARN that is permitted to create VPC endpoints against
# this service. When acceptance_required = true, the connection still needs
# manual acceptance; allowed_principals controls who can even request.
################################################################################

resource "aws_vpc_endpoint_service_allowed_principal" "allowed_principal" {
  for_each = toset(var.allowed_principals)

  vpc_endpoint_service_id = aws_vpc_endpoint_service.vpc_endpoint_svc.id
  principal_arn           = each.value
}

################################################################################
# CONNECTION NOTIFICATIONS (optional)
#
# Sends Accept / Reject / Delete events to an SNS topic so the service
# owner can react (ChatOps, automation, auditing).
################################################################################

resource "aws_vpc_endpoint_connection_notification" "connection_notification" {
  count = var.notification_topic_arn != null ? 1 : 0

  vpc_endpoint_service_id     = aws_vpc_endpoint_service.vpc_endpoint_svc.id
  connection_notification_arn = var.notification_topic_arn
  connection_events           = var.notification_events

  # Prevent destroyed notification from blocking endpoint service deletion
  depends_on = [aws_vpc_endpoint_service.vpc_endpoint_svc]
}
