################################################################################
# VPC Endpoint Service Variables
################################################################################

variable "name" {
  description = "Name tag for the VPC endpoint service and associated resources"
  type        = string
}

################################################################################
# Load Balancer ARNs (exactly one set must be provided)
################################################################################

variable "network_load_balancer_arns" {
  description = "ARNs of Network Load Balancers to expose via PrivateLink. Mutually exclusive with gateway_load_balancer_arns"
  type        = list(string)
  default     = []
}

variable "gateway_load_balancer_arns" {
  description = "ARNs of Gateway Load Balancers to expose via PrivateLink. Mutually exclusive with network_load_balancer_arns"
  type        = list(string)
  default     = []
}

################################################################################
# Acceptance & Access Control
################################################################################

variable "acceptance_required" {
  description = "Whether VPC endpoint connection requests require manual acceptance by the service owner"
  type        = bool
  default     = true
}

variable "allowed_principals" {
  description = "List of ARNs (accounts, IAM users/roles) permitted to create endpoints against this service"
  type        = list(string)
  default     = []
}

################################################################################
# Private DNS
################################################################################

variable "private_dns_name" {
  description = "Private DNS name for the endpoint service. Requires domain ownership verification via a TXT record"
  type        = string
  default     = null
}

################################################################################
# IP Address Types
################################################################################

variable "supported_ip_address_types" {
  description = "IP address types supported by the service. Valid values: ipv4, ipv6"
  type        = list(string)
  default     = ["ipv4"]

  validation {
    condition     = alltrue([for t in var.supported_ip_address_types : contains(["ipv4", "ipv6"], t)])
    error_message = "Each element must be either 'ipv4' or 'ipv6'."
  }
}

################################################################################
# Connection Notifications
################################################################################

variable "notification_topic_arn" {
  description = "ARN of an SNS topic to receive endpoint connection notifications. Set to null to disable"
  type        = string
  default     = null
}

variable "notification_events" {
  description = "List of endpoint connection events to notify on"
  type        = list(string)
  default     = ["Accept", "Reject", "Delete", "Connect"]

  validation {
    condition     = alltrue([for e in var.notification_events : contains(["Accept", "Reject", "Delete", "Connect"], e)])
    error_message = "Valid notification events are: Accept, Reject, Delete, Connect."
  }
}

################################################################################
# Tags
################################################################################

variable "tags" {
  description = "Tags to apply to all resources"
  type        = map(string)
  default     = {}
}
