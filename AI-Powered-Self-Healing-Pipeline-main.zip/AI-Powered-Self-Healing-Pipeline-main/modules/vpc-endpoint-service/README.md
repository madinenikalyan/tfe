# VPC Endpoint Service Module (PrivateLink Provider)

Creates an AWS VPC Endpoint Service that exposes a Network Load Balancer (NLB) or Gateway Load Balancer (GWLB) to consumers in the same or other AWS accounts via PrivateLink.

## Features

| Feature | Details |
|---|---|
| **NLB or GWLB backed** | Supports both Network and Gateway Load Balancer ARNs (mutually exclusive) |
| **Acceptance gate** | `acceptance_required = true` by default — manual approval for each consumer endpoint |
| **Allowed principals** | Restricts which AWS accounts/roles can even request a connection |
| **Private DNS** | Optional custom domain with automatic TXT record verification config in outputs |
| **Connection notifications** | Optional SNS topic for Accept/Reject/Delete/Connect events |
| **Dual-stack** | Configurable `supported_ip_address_types` (ipv4, ipv6) |

## Usage — NLB-backed endpoint service

```hcl
module "my_endpoint_service" {
  source = "./modules/vpc-endpoint-service"

  name                       = "${local.name_prefix}-my-service"
  network_load_balancer_arns = [aws_lb.internal_nlb.arn]
  acceptance_required        = true

  allowed_principals = [
    "arn:aws:iam::123456789012:root",
    "arn:aws:iam::987654321098:root",
  ]

  tags = local.common_tags
}
```

## Usage — with private DNS and SNS notifications

```hcl
module "my_endpoint_service" {
  source = "./modules/vpc-endpoint-service"

  name                       = "${local.name_prefix}-api-service"
  network_load_balancer_arns = [aws_lb.api_nlb.arn]
  acceptance_required        = false
  private_dns_name           = "api.internal.example.com"

  notification_topic_arn = module.connection_notifications.topic_arn
  notification_events    = ["Accept", "Reject", "Delete"]

  allowed_principals = [
    "arn:aws:iam::123456789012:root",
  ]

  tags = local.common_tags
}

# After apply, create a TXT record using the output:
# Name:  module.my_endpoint_service.private_dns_name_configuration[0].name
# Value: module.my_endpoint_service.private_dns_name_configuration[0].value
```

## Usage — GWLB-backed endpoint service

```hcl
module "security_appliance_service" {
  source = "./modules/vpc-endpoint-service"

  name                       = "${local.name_prefix}-security-appliance"
  gateway_load_balancer_arns = [aws_lb.gwlb.arn]
  acceptance_required        = true

  tags = local.common_tags
}
```

## Inputs

| Name | Description | Type | Default | Required |
|---|---|---|---|---|
| `name` | Name tag for the endpoint service | `string` | — | yes |
| `network_load_balancer_arns` | NLB ARNs to expose (mutually exclusive with GWLB) | `list(string)` | `[]` | no* |
| `gateway_load_balancer_arns` | GWLB ARNs to expose (mutually exclusive with NLB) | `list(string)` | `[]` | no* |
| `acceptance_required` | Require manual acceptance of endpoint connections | `bool` | `true` | no |
| `allowed_principals` | ARNs allowed to create endpoints against this service | `list(string)` | `[]` | no |
| `private_dns_name` | Custom private DNS name (requires domain verification) | `string` | `null` | no |
| `supported_ip_address_types` | IP types: `["ipv4"]`, `["ipv6"]`, or both | `list(string)` | `["ipv4"]` | no |
| `notification_topic_arn` | SNS topic ARN for connection event notifications | `string` | `null` | no |
| `notification_events` | Events to notify on | `list(string)` | `["Accept","Reject","Delete","Connect"]` | no |
| `tags` | Tags for all resources | `map(string)` | `{}` | no |

\* One of `network_load_balancer_arns` or `gateway_load_balancer_arns` must be provided.

## Outputs

| Name | Description |
|---|---|
| `id` | Endpoint service ID |
| `arn` | Endpoint service ARN |
| `service_name` | The `com.amazonaws.vpce.<region>.<id>` name consumers use |
| `service_type` | Gateway or Interface |
| `state` | Service state |
| `availability_zones` | AZs the service is available in |
| `base_endpoint_dns_names` | Base DNS names for the service |
| `manages_vpc_endpoints` | Whether the service manages its own endpoints |
| `private_dns_name` | The private DNS name configured |
| `private_dns_name_configuration` | TXT record details for domain verification |
