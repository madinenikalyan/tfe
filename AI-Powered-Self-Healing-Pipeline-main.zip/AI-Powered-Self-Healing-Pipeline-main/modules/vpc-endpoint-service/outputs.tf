################################################################################
# VPC Endpoint Service Outputs
################################################################################

output "id" {
  description = "The ID of the VPC endpoint service"
  value       = aws_vpc_endpoint_service.vpc_endpoint_svc.id
}

output "arn" {
  description = "The ARN of the VPC endpoint service"
  value       = aws_vpc_endpoint_service.vpc_endpoint_svc.arn
}

output "service_name" {
  description = "The service name (com.amazonaws.vpce.<region>.<vpce-svc-id>) consumers use to create endpoints"
  value       = aws_vpc_endpoint_service.vpc_endpoint_svc.service_name
}

output "service_type" {
  description = "The service type: Gateway or Interface"
  value       = aws_vpc_endpoint_service.vpc_endpoint_svc.service_type
}

output "state" {
  description = "The state of the VPC endpoint service"
  value       = aws_vpc_endpoint_service.vpc_endpoint_svc.state
}

output "availability_zones" {
  description = "Availability zones in which the service is available"
  value       = aws_vpc_endpoint_service.vpc_endpoint_svc.availability_zones
}

output "base_endpoint_dns_names" {
  description = "DNS names for the service"
  value       = aws_vpc_endpoint_service.vpc_endpoint_svc.base_endpoint_dns_names
}

output "manages_vpc_endpoints" {
  description = "Whether the service manages its VPC endpoints"
  value       = aws_vpc_endpoint_service.vpc_endpoint_svc.manages_vpc_endpoints
}

output "private_dns_name" {
  description = "The private DNS name for the service"
  value       = aws_vpc_endpoint_service.vpc_endpoint_svc.private_dns_name
}

output "private_dns_name_configuration" {
  description = "Private DNS name verification configuration (contains name, type, value for TXT record)"
  value       = aws_vpc_endpoint_service.vpc_endpoint_svc.private_dns_name_configuration
}
