
################################################################################
# Secrets Manager — Production-Ready Single Secret
#
# Creates one secret per module invocation. Invoke this module once per secret.
#
# Features:
#   - Dedicated KMS CMK (annual rotation always enabled; AWS-managed key never used)
#   - Initial secret version written on first apply
#   - ignore_changes on secret_string prevents Terraform clobbering rotated values
#   - 30-day soft-delete recovery window by default
#   - Optional Lambda-based rotation (automatically_after_days or cron expression)
#   - Optional multi-region replication for disaster recovery
#   - Optional resource-based policy (public access always blocked)
#
# DESIGN NOTE — version stages:
#   Secrets Manager stamps versions with AWSCURRENT / AWSPREVIOUS / AWSPENDING
#   lifecycle stages. These change during rotation without any Terraform input.
#   ignore_changes on version_stages prevents spurious plan diffs.
################################################################################

################################################################################
# KMS KEY — one dedicated CMK per secret
#
# Created only when var.kms_key_id is null (default). Passing an existing key
# ARN skips creation. Annual key rotation is always enabled.
################################################################################

data "aws_iam_policy_document" "secret_kms_policy" {
  count = var.create_kms_key ? 1 : 0

  # Root account retains full administration rights (AWS requirement for CMKs).
  statement {
    sid    = "EnableRootAccountAdmin"
    effect = "Allow"
    principals {
      type        = "AWS"
      identifiers = ["arn:${var.aws_partition}:iam::${var.account_id}:root"]
    }
    actions   = ["kms:*"]
    resources = ["*"]
  }

  # Secrets Manager uses this key for envelope encryption via GenerateDataKey / Decrypt.
  statement {
    sid    = "AllowSecretsManagerEncryption"
    effect = "Allow"
    principals {
      type        = "Service"
      identifiers = ["secretsmanager.amazonaws.com"]
    }
    actions = [
      "kms:GenerateDataKey*",
      "kms:Decrypt",
      "kms:CreateGrant",
    ]
    resources = ["*"]
    condition {
      test     = "StringEquals"
      variable = "kms:CallerAccount"
      values   = [var.account_id]
    }
    condition {
      test     = "StringLike"
      variable = "kms:ViaService"
      values   = ["secretsmanager.${var.aws_region}.amazonaws.com"]
    }
  }

  # Optional: break-glass / security-audit administrators.
  dynamic "statement" {
    for_each = length(var.additional_kms_administrators) > 0 ? [1] : []
    content {
      sid    = "AdditionalKMSAdministrators"
      effect = "Allow"
      principals {
        type        = "AWS"
        identifiers = var.additional_kms_administrators
      }
      actions = [
        "kms:Describe*",
        "kms:Get*",
        "kms:List*",
        "kms:ScheduleKeyDeletion",
        "kms:CancelKeyDeletion",
        "kms:EnableKey",
        "kms:DisableKey",
        "kms:CreateAlias",
        "kms:DeleteAlias",
        "kms:UpdateAlias",
        "kms:UpdateKeyDescription",
      ]
      resources = ["*"]
    }
  }
}

resource "aws_kms_key" "secret_encryption" {
  count = var.create_kms_key ? 1 : 0

  description              = "KMS CMK for Secrets Manager secret: ${var.name}"
  key_usage                = "ENCRYPT_DECRYPT"
  customer_master_key_spec = "SYMMETRIC_DEFAULT"
  deletion_window_in_days  = var.kms_key_deletion_window_in_days

  # Annual key rotation always on — satisfies CIS AWS Foundations Benchmark.
  enable_key_rotation = true
  multi_region        = false
  policy              = data.aws_iam_policy_document.secret_kms_policy[0].json

  tags = merge({ Name = "${replace(var.name, "/", "-")}-secret-cmk" }, var.tags)
}

resource "aws_kms_alias" "secret_encryption" {
  count = var.create_kms_key ? 1 : 0

  name          = "alias/${replace(var.name, "/", "-")}-secret"
  target_key_id = aws_kms_key.secret_encryption[0].key_id
}

locals {
  # Caller-supplied key takes precedence; module-managed key used otherwise.
  kms_key_arn = var.create_kms_key ? aws_kms_key.secret_encryption[0].arn : var.kms_key_id
}

################################################################################
# SECRET
################################################################################

resource "aws_secretsmanager_secret" "secret" {
  name        = var.name
  description = var.description
  kms_key_id  = local.kms_key_arn

  # 30-day window allows recovery from accidental deletion.
  # Set to 0 only when immediate permanent deletion is required.
  recovery_window_in_days = var.recovery_window_in_days

  # Multi-region replication — empty by default.
  dynamic "replica" {
    for_each = var.replica_regions
    content {
      region     = replica.value.region
      kms_key_id = replica.value.kms_key_id
    }
  }

  tags = merge({ Name = var.name }, var.tags)

}

################################################################################
# INITIAL SECRET VERSION
#
# Writes the first value on creation.
# ignore_changes prevents Terraform from overwriting values that have since been
# rotated by Lambda or updated out-of-band.
################################################################################

resource "aws_secretsmanager_secret_version" "secret_version" {
  secret_id     = aws_secretsmanager_secret.secret.id
  secret_string = var.secret_string

}

################################################################################
# RESOURCE-BASED POLICY (optional)
#
# Attach a JSON IAM policy to the secret for cross-account access control.
# Public access is always blocked regardless of policy content.
################################################################################

resource "aws_secretsmanager_secret_policy" "secret_policy" {
  count = var.resource_policy != null ? 1 : 0

  secret_arn = aws_secretsmanager_secret.secret.arn
  policy     = var.resource_policy

  # Always block any policy statement that grants broad public access.
  block_public_policy = true
}

################################################################################
# ROTATION (optional)
#
# Requires a Lambda function that implements the Secrets Manager rotation
# protocol. Use automatically_after_days for a simple fixed cadence, or
# schedule_expression for cron-based scheduling. Set only one.
################################################################################

resource "aws_secretsmanager_secret_rotation" "secret_rotation" {
  count = var.rotation != null ? 1 : 0

  secret_id           = aws_secretsmanager_secret.secret.id
  rotation_lambda_arn = var.rotation.rotation_lambda_arn

  rotation_rules {
    # Use schedule_expression for cron control; automatically_after_days otherwise.
    automatically_after_days = var.rotation.schedule_expression == null ? var.rotation.automatically_after_days : null
    duration                 = var.rotation.duration
    schedule_expression      = var.rotation.schedule_expression
  }

  depends_on = [aws_secretsmanager_secret_version.secret_version]
}
