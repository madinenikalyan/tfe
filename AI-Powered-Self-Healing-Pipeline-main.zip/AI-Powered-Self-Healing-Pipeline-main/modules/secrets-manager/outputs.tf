################################################################################
# SECRET
################################################################################

output "secret_arn" {
  description = "ARN of the Secrets Manager secret."
  value       = aws_secretsmanager_secret.secret.arn
}

output "secret_id" {
  description = "ID of the secret (same as the secret name)."
  value       = aws_secretsmanager_secret.secret.id
}

output "secret_name" {
  description = "Full name of the secret as stored in AWS Secrets Manager."
  value       = aws_secretsmanager_secret.secret.name
}

################################################################################
# SECRET VERSION
################################################################################

output "version_id" {
  description = "Unique version ID of the initial secret version written by this module."
  value       = aws_secretsmanager_secret_version.secret_version.version_id
}

################################################################################
# KMS KEY
################################################################################

output "kms_key_arn" {
  description = <<-EOT
    ARN of the KMS key used to encrypt this secret.
    Either the module-managed CMK or the caller-supplied key, depending on
    whether var.kms_key_id was set.
    Pass this to other modules that need to decrypt the same secret.
  EOT
  value       = local.kms_key_arn
}

output "kms_key_id" {
  description = <<-EOT
    ID of the module-managed KMS CMK.
    Null when var.kms_key_id was supplied (caller-managed key).
  EOT
  value       = length(aws_kms_key.secret_encryption) > 0 ? aws_kms_key.secret_encryption[0].key_id : null
}

output "kms_alias_name" {
  description = <<-EOT
    KMS alias name for the module-managed CMK (e.g. "alias/my-secret-secret").
    Null when var.kms_key_id was supplied (caller-managed key).
  EOT
  value       = length(aws_kms_alias.secret_encryption) > 0 ? aws_kms_alias.secret_encryption[0].name : null
}
