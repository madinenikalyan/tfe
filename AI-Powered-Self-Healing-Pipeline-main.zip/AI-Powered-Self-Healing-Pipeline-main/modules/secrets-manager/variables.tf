################################################################################
# AWS ACCOUNT & REGION — passed from root module
################################################################################

variable "account_id" {
  description = <<-EOT
    AWS account ID. Passed from the root module's data.aws_caller_identity.current.account_id.
    Used in KMS key policies and IAM ARN construction.
  EOT
  type        = string

  validation {
    condition     = can(regex("^[0-9]{12}$", var.account_id))
    error_message = "'account_id' must be a 12-digit AWS account ID."
  }
}

variable "aws_region" {
  description = <<-EOT
    AWS region name (e.g. "us-east-1"). Passed from the root module's data.aws_region.current.name.
    Used in KMS ViaService conditions for Secrets Manager.
  EOT
  type        = string

  validation {
    condition     = can(regex("^[a-z]{2}-[a-z]+-[0-9]{1}$", var.aws_region))
    error_message = "'aws_region' must be a valid AWS region name (e.g. 'us-east-1')."
  }
}

variable "aws_partition" {
  description = "AWS partition for ARN construction (e.g. 'aws', 'aws-cn', 'aws-us-gov')."
  type        = string
  default     = "aws"
}

################################################################################
# SECRET IDENTITY
################################################################################

variable "name" {
  description = <<-EOT
    Full name of the secret as it will appear in Secrets Manager.
    Use a path-like naming convention for organisation:
      "myapp/prod/db-credentials"
      "sales-automation/uat/api-key"

    Must be unique within the AWS account and region.
    Slashes are used in the KMS alias name after replacing "/" with "-".
  EOT
  type        = string

  validation {
    condition     = length(trimspace(var.name)) > 0
    error_message = "'name' must not be empty."
  }
}

variable "description" {
  description = "Human-readable description of the secret's purpose. Shown in the Secrets Manager console."
  type        = string
  default     = ""
}

variable "recovery_window_in_days" {
  description = <<-EOT
    Number of days Secrets Manager waits before permanently deleting a secret.
    The secret can be restored during this window. Valid values: 0 or 7–30.
    Set to 0 only if immediate permanent deletion is required (e.g. ephemeral CI/CD secrets).
    Default: 30 days (recommended for production).
  EOT
  type        = number
  default     = 30

  validation {
    condition     = var.recovery_window_in_days == 0 || (var.recovery_window_in_days >= 7 && var.recovery_window_in_days <= 30)
    error_message = "'recovery_window_in_days' must be 0 (immediate delete) or between 7 and 30."
  }
}

################################################################################
# SECRET VALUE — initial version
################################################################################

variable "secret_string" {
  description = <<-EOT
    Initial plaintext or JSON string to store in the first secret version.
    For structured credentials use jsonencode():
      secret_string = jsonencode({ username = "admin", password = var.db_password })

    SECURITY: This value is stored in Terraform state. For production:
      - Use a placeholder here and rotate immediately with a Lambda function, OR
      - Inject the value out-of-band via CLI / console after initial apply.
    Terraform will NOT overwrite the value after initial creation
    (ignore_changes is applied on the version resource).
  EOT
  type        = string
  sensitive   = true
}

################################################################################
# KMS ENCRYPTION — always enabled; AWS-managed key is never used
################################################################################

variable "kms_key_id" {
  description = <<-EOT
    ARN or ID of an existing KMS CMK to use for encrypting this secret.
    Leave null (default) to have the module create a dedicated CMK automatically.
    When supplying an external key, also set create_kms_key = false.
    The module always encrypts secrets — the default AWS-managed key is never used.
  EOT
  type        = string
  default     = null
}

variable "create_kms_key" {
  description = <<-EOT
    Whether the module should create a dedicated KMS CMK for this secret.
    Set to false when passing an existing key via var.kms_key_id.
    This avoids count issues with computed kms_key_id values.
  EOT
  type        = bool
  default     = true
}

variable "kms_key_deletion_window_in_days" {
  description = <<-EOT
    Number of days to wait before permanently deleting the module-managed KMS key
    when the module is destroyed. Valid range: 7–30. Default: 30.
    Ignored when var.kms_key_id is supplied (caller-managed key).
  EOT
  type        = number
  default     = 30

  validation {
    condition     = var.kms_key_deletion_window_in_days >= 7 && var.kms_key_deletion_window_in_days <= 30
    error_message = "'kms_key_deletion_window_in_days' must be between 7 and 30."
  }
}

variable "additional_kms_administrators" {
  description = <<-EOT
    Additional IAM principal ARNs (users or roles) to grant KMS management rights
    on the module-managed CMK. The AWS root account always retains admin access.
    Use this to grant break-glass access to a security-audit role.
    Ignored when var.kms_key_id is supplied.

    Example:
      additional_kms_administrators = [
        "arn:aws:iam::123456789012:role/SecurityAuditRole"
      ]
  EOT
  type        = list(string)
  default     = []
}

################################################################################
# ROTATION (optional)
################################################################################

variable "rotation" {
  description = <<-EOT
    Configure automatic secret rotation using an AWS Lambda rotation function.
    Leave null (default) to disable rotation.

    rotation_lambda_arn:       ARN of the Lambda function that implements the
                               Secrets Manager rotation protocol.
    automatically_after_days:  Fixed rotation period in days (e.g. 30, 60, 90).
                               Ignored when schedule_expression is set.
    duration:                  Maximum rotation window duration (ISO 8601, e.g. "3h").
    schedule_expression:       cron() or rate() expression for custom schedules.
                               When set, automatically_after_days is ignored.

    Example (rotate every 30 days):
      rotation = {
        rotation_lambda_arn      = module.rotation_lambda.function_arn
        automatically_after_days = 30
      }

    Example (cron-based rotation):
      rotation = {
        rotation_lambda_arn = module.rotation_lambda.function_arn
        schedule_expression = "cron(0 3 1 * ? *)"   # 03:00 UTC on the 1st of each month
      }
  EOT
  type = object({
    rotation_lambda_arn      = string
    automatically_after_days = optional(number, 30)
    duration                 = optional(string)
    schedule_expression      = optional(string)
  })
  default = null
}

################################################################################
# REPLICATION (optional)
################################################################################

variable "replica_regions" {
  description = <<-EOT
    List of AWS regions to replicate the secret into for multi-region disaster recovery.
    Each entry may specify an optional per-region KMS key. Leave empty (default) to
    disable replication.

    Example:
      replica_regions = [
        { region = "us-west-2" }
        { region = "eu-west-1", kms_key_id = "arn:aws:kms:eu-west-1:123456789012:key/..." }
      ]
  EOT
  type = list(object({
    region     = string
    kms_key_id = optional(string)
  }))
  default = []
}

################################################################################
# RESOURCE POLICY (optional)
################################################################################

variable "resource_policy" {
  description = <<-EOT
    JSON-encoded IAM resource policy attached to the secret.
    Use for cross-account access grants or to restrict which principals can read the secret.
    Public access is always blocked regardless of policy content.
    Leave null (default) to skip (no resource policy).

    Example (grant a specific role read access from another account):
      resource_policy = jsonencode({
        Version = "2012-10-17"
        Statement = [{
          Effect    = "Allow"
          Principal = { AWS = "arn:aws:iam::111122223333:role/app-role" }
          Action    = ["secretsmanager:GetSecretValue"]
          Resource  = "*"
        }]
      })
  EOT
  type        = string
  default     = null
}

################################################################################
# TAGS
################################################################################

variable "tags" {
  description = "Map of tags applied to all resources created by this module."
  type        = map(string)
  default     = {}
}
