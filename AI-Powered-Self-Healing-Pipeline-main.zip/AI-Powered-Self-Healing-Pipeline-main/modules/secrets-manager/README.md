# `modules/secrets-manager` — Production-Ready Secrets Manager Module

A Terraform module for provisioning an AWS Secrets Manager **single secret** with
KMS CMK encryption, optional rotation, multi-region replication, and resource-based policies.

---

## Features

| Feature | Details |
|---|---|
| **KMS encryption** | Dedicated CMK auto-created per secret (annual rotation always on); AWS-managed key never used |
| **Initial version** | First secret value written on creation |
| **Soft-delete** | 30-day recovery window by default (configurable 7–30 days or 0 for immediate) |
| **Rotation** | Optional Lambda-based rotation (fixed cadence or cron expression) |
| **Replication** | Optional multi-region replication for disaster recovery |
| **Resource policy** | Optional IAM resource policy; public access always blocked |
| **Break-glass admins** | Optional additional KMS administrators for security/audit roles |

---

## Design Decisions

### One Secret per Module Call

Each module invocation creates exactly one secret. This keeps the interface simple and
makes it easy to compose — the Aurora module calls this module internally for its
connection-config secret.

### KMS Root Account Policy

Every KMS key policy includes a root account statement (`kms:*`). This is an **AWS
requirement** — without it the key can become permanently orphaned if the creating
IAM principal is deleted. The statement does NOT grant any IAM user/role direct access;
it only enables administration through IAM policies.

### No Data Blocks

`account_id` and `aws_region` are passed as variables rather than looked up via
`data "aws_caller_identity"` / `data "aws_region"`. This avoids duplicate data-source
calls when the root module already has them and makes the module deterministic in
plan-time evaluation.

---

## Usage

### Minimal — store a database password

```hcl
module "db_password" {
  source = "./modules/secrets-manager"

  name          = "myapp/prod/db-password"
  description   = "Database password for myapp production"
  secret_string = var.db_password   # or use jsonencode({...}) for structured secrets

  account_id = data.aws_caller_identity.current.account_id
  aws_region = data.aws_region.current.name

  tags = local.common_tags
}
```

### With external KMS key

```hcl
module "api_key" {
  source = "./modules/secrets-manager"

  name          = "myapp/prod/api-key"
  secret_string = var.api_key
  kms_key_id     = aws_kms_key.shared.arn   # reuse an existing CMK
  create_kms_key = false                     # skip module-managed CMK

  account_id = data.aws_caller_identity.current.account_id
  aws_region = data.aws_region.current.name

  tags = local.common_tags
}
```

### With rotation

```hcl
module "rotating_secret" {
  source = "./modules/secrets-manager"

  name          = "myapp/prod/rotating-credential"
  secret_string = jsonencode({ username = "svc_user", password = "initial" })

  rotation = {
    rotation_lambda_arn      = module.rotation_lambda.function_arn
    automatically_after_days = 30
  }

  account_id = data.aws_caller_identity.current.account_id
  aws_region = data.aws_region.current.name

  tags = local.common_tags
}
```

---

## Inputs

| Variable | Type | Default | Description |
|---|---|---|---|
| `account_id` | `string` | required | AWS account ID (12-digit) |
| `aws_region` | `string` | required | AWS region name (e.g. `us-east-1`) |
| `name` | `string` | required | Secret name in Secrets Manager |
| `description` | `string` | `""` | Human-readable description |
| `secret_string` | `string` | required | Initial secret value (sensitive) |
| `recovery_window_in_days` | `number` | `30` | Soft-delete recovery window (0, 7–30) |
| `kms_key_id` | `string` | `null` | Existing KMS CMK ARN/ID; null creates a dedicated CMK |
| `create_kms_key` | `bool` | `true` | Whether to create a module-managed CMK; set false when passing kms_key_id |
| `kms_key_deletion_window_in_days` | `number` | `30` | KMS key deletion wait (7–30 days) |
| `additional_kms_administrators` | `list(string)` | `[]` | Additional IAM principal ARNs for KMS admin |
| `rotation` | `object` | `null` | Lambda rotation config (ARN, cadence, schedule) |
| `replica_regions` | `list(object)` | `[]` | Multi-region replication targets |
| `resource_policy` | `string` | `null` | JSON IAM resource policy for the secret |
| `tags` | `map(string)` | `{}` | Tags applied to all resources |

---

## Outputs

| Output | Description |
|---|---|
| `secret_arn` | ARN of the Secrets Manager secret |
| `secret_id` | ID of the secret |
| `secret_name` | Full name of the secret |
| `version_id` | Version ID of the initial secret version |
| `kms_key_arn` | ARN of the KMS key (module-managed or caller-supplied) |
| `kms_key_id` | ID of the module-managed KMS CMK (null when caller supplies key) |
| `kms_alias_name` | KMS alias name (null when caller supplies key) |

---

## Notes

- **Sensitive state**: `secret_string` is stored in Terraform state. For production,
  consider injecting the value out-of-band or rotating immediately after initial apply.
- **Caller-managed KMS**: When `kms_key_id` is supplied, set `create_kms_key = false`.
  The caller is responsible for KMS key policy and lifecycle.
- **Public access**: `block_public_policy = true` is always set on any resource policy,
  even if the caller's policy document would otherwise allow broad access.
