# VPC Endpoint Module

Creates an AWS VPC endpoint with support for **Gateway**, **Interface**, and **GatewayLoadBalancer** types.

## Features

| Feature | Details |
|---|---|
| **Gateway endpoints** | S3, DynamoDB — associates with route tables, zero per-hour cost |
| **Interface endpoints** | PrivateLink ENI-based — attaches to subnets with a security group |
| **Security group** | Auto-created for Interface/GLB endpoints; allows HTTPS (443) from VPC CIDR |
| **Private DNS** | Enabled by default for Interface endpoints so AWS SDK traffic resolves privately |
| **IAM policy** | Optional `policy` restricts which principals/actions may traverse the endpoint |
| **Timeouts** | Configurable create/update/delete timeouts |

## Usage — Gateway endpoint (S3)

```hcl
module "s3_gateway_endpoint" {
  source = "./modules/vpc-endpoint"

  name          = "${local.name_prefix}-vpce-s3"
  vpc_id        = aws_vpc.main.id
  service_name  = "com.amazonaws.${var.aws_region}.s3"
  endpoint_type = "Gateway"
  route_table_ids = aws_route_table.private[*].id

  tags = local.common_tags
}
```

## Usage — Interface endpoint (Secrets Manager)

```hcl
module "secretsmanager_endpoint" {
  source = "./modules/vpc-endpoint"

  name          = "${local.name_prefix}-vpce-secretsmanager"
  vpc_id        = aws_vpc.main.id
  service_name  = "com.amazonaws.${var.aws_region}.secretsmanager"
  endpoint_type = "Interface"
  subnet_ids    = aws_subnet.private_lambda[*].id

  tags = local.common_tags
}
```

## Inputs

| Name | Description | Type | Default | Required |
|---|---|---|---|---|
| `name` | Name tag for the VPC endpoint | `string` | — | yes |
| `vpc_id` | VPC ID | `string` | — | yes |
| `service_name` | AWS service name (e.g. `com.amazonaws.us-east-1.s3`) | `string` | — | yes |
| `endpoint_type` | `Gateway`, `Interface`, or `GatewayLoadBalancer` | `string` | `"Gateway"` | no |
| `route_table_ids` | Route table IDs for Gateway endpoints | `list(string)` | `[]` | no |
| `subnet_ids` | Subnet IDs for Interface/GLB endpoints | `list(string)` | `[]` | no |
| `private_dns_enabled` | Enable private DNS on Interface endpoints | `bool` | `true` | no |
| `dns_record_ip_type` | DNS record IP type (`ipv4`, `dualstack`, etc.) | `string` | `null` | no |
| `create_security_group` | Create a dedicated SG for Interface/GLB endpoints | `bool` | `true` | no |
| `security_group_name` | Override the SG name | `string` | `null` | no |
| `security_group_ids` | Extra SG IDs to attach | `list(string)` | `[]` | no |
| `policy` | IAM policy JSON | `string` | `null` | no |
| `auto_accept` | Auto-accept cross-account endpoints | `bool` | `null` | no |
| `timeouts` | Create/update/delete timeouts | `object` | `{}` | no |
| `tags` | Tags for all resources | `map(string)` | `{}` | no |

## Outputs

| Name | Description |
|---|---|
| `id` | VPC endpoint ID |
| `arn` | VPC endpoint ARN |
| `state` | Endpoint state |
| `prefix_list_id` | Prefix list ID (Gateway only) |
| `cidr_blocks` | CIDR blocks for the service (Gateway only) |
| `network_interface_ids` | ENI IDs (Interface only) |
| `dns_entry` | DNS entries |
| `security_group_id` | Module-created SG ID |
| `security_group_arn` | Module-created SG ARN |
