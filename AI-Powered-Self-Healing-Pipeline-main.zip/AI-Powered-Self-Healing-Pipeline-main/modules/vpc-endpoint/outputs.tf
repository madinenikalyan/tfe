################################################################################
# VPC Endpoint Outputs
################################################################################

output "id" {
  description = "The ID of the VPC endpoint"
  value       = aws_vpc_endpoint.vpc_endpoint.id
}

output "arn" {
  description = "The ARN of the VPC endpoint"
  value       = aws_vpc_endpoint.vpc_endpoint.arn
}

output "state" {
  description = "The state of the VPC endpoint (pendingAcceptance, pending, available, deleting, deleted, rejected, failed, expired)"
  value       = aws_vpc_endpoint.vpc_endpoint.state
}

output "prefix_list_id" {
  description = "The prefix list ID of a Gateway endpoint (useful for security group rules)"
  value       = var.endpoint_type == "Gateway" ? aws_vpc_endpoint.vpc_endpoint.prefix_list_id : null
}

output "cidr_blocks" {
  description = "The list of CIDR blocks for the exposed AWS service (Gateway endpoints only)"
  value       = var.endpoint_type == "Gateway" ? aws_vpc_endpoint.vpc_endpoint.cidr_blocks : []
}

output "network_interface_ids" {
  description = "The network interface IDs created by an Interface endpoint"
  value       = var.endpoint_type != "Gateway" ? aws_vpc_endpoint.vpc_endpoint.network_interface_ids : []
}

output "dns_entry" {
  description = "DNS entries for the VPC endpoint"
  value       = aws_vpc_endpoint.vpc_endpoint.dns_entry
}

output "security_group_id" {
  description = "The ID of the module-created security group (null for Gateway endpoints or when create_security_group = false)"
  value       = length(aws_security_group.endpoint_sg) > 0 ? aws_security_group.endpoint_sg[0].id : null
}

output "security_group_arn" {
  description = "The ARN of the module-created security group"
  value       = length(aws_security_group.endpoint_sg) > 0 ? aws_security_group.endpoint_sg[0].arn : null
}
