################################################################################
# VPC Endpoint Variables
################################################################################

variable "name" {
  description = "Name tag for the VPC endpoint and associated resources"
  type        = string
}

variable "vpc_id" {
  description = "ID of the VPC in which to create the endpoint"
  type        = string
}

variable "service_name" {
  description = "The AWS service name for the endpoint (e.g. com.amazonaws.us-east-1.s3)"
  type        = string
}

variable "endpoint_type" {
  description = "Type of VPC endpoint: Gateway, Interface, or GatewayLoadBalancer"
  type        = string
  default     = "Gateway"

  validation {
    condition     = contains(["Gateway", "Interface", "GatewayLoadBalancer"], var.endpoint_type)
    error_message = "endpoint_type must be one of: Gateway, Interface, GatewayLoadBalancer."
  }
}

################################################################################
# Gateway Endpoint Variables
################################################################################

variable "route_table_ids" {
  description = "List of route table IDs to associate with a Gateway endpoint"
  type        = list(string)
  default     = []
}

################################################################################
# Interface / GatewayLoadBalancer Endpoint Variables
################################################################################

variable "subnet_ids" {
  description = "List of subnet IDs for Interface or GatewayLoadBalancer endpoints (one per AZ recommended)"
  type        = list(string)
  default     = []
}

variable "private_dns_enabled" {
  description = "Enable private DNS for Interface endpoints (requires enable_dns_support and enable_dns_hostnames on the VPC)"
  type        = bool
  default     = true
}

variable "dns_record_ip_type" {
  description = "The DNS records created for the endpoint. Valid values: ipv4, dualstack, service-defined, ipv6"
  type        = string
  default     = null
}

################################################################################
# Security Group Variables
################################################################################

variable "create_security_group" {
  description = "Create a dedicated security group for Interface/GatewayLoadBalancer endpoints (allows HTTPS from VPC CIDR)"
  type        = bool
  default     = true
}

variable "security_group_name" {
  description = "Override the name of the module-created security group. Defaults to <name>-vpce-sg"
  type        = string
  default     = null
}

variable "security_group_ids" {
  description = "Additional security group IDs to attach to the endpoint (merged with the module-created SG if create_security_group = true)"
  type        = list(string)
  default     = []
}

################################################################################
# Policy & Acceptance
################################################################################

variable "policy" {
  description = "IAM policy document (JSON) to attach to the endpoint. If null, the default full-access policy is used"
  type        = string
  default     = null
}

variable "auto_accept" {
  description = "Accept the VPC endpoint (required for cross-account endpoints with PrivateLink)"
  type        = bool
  default     = null
}

################################################################################
# Timeouts
################################################################################

variable "timeouts" {
  description = "Timeouts for endpoint create/update/delete operations"
  type = object({
    create = optional(string, "10m")
    update = optional(string, "10m")
    delete = optional(string, "10m")
  })
  default = {}
}

################################################################################
# Tags
################################################################################

variable "tags" {
  description = "Tags to apply to all resources"
  type        = map(string)
  default     = {}
}
