################################################################################
# VPC Endpoint Module
#
# Creates AWS VPC endpoints with support for all three endpoint types:
#   - Gateway   (S3, DynamoDB) — route-table based, no per-hour charge
#   - Interface (most other AWS services) — ENI-based, PrivateLink
#   - GatewayLoadBalancer — for third-party appliances
#
# DESIGN NOTES:
#   • Gateway endpoints attach to route tables; Interface endpoints attach
#     to subnets and require a security group.
#   • When create_security_group = true (default for Interface endpoints),
#     the module creates a security group that allows HTTPS (443) inbound
#     from the VPC CIDR. This is required for PrivateLink communication.
#   • private_dns_enabled defaults to true for Interface endpoints so that
#     AWS SDK calls resolve to the private endpoint automatically.
#   • An optional IAM policy document can restrict which principals or
#     actions are allowed through the endpoint.
################################################################################

################################################################################
# DATA SOURCES
################################################################################

data "aws_vpc" "selected" {
  id = var.vpc_id
}

################################################################################
# SECURITY GROUP — created only for Interface / GatewayLoadBalancer endpoints
################################################################################

resource "aws_security_group" "endpoint_sg" {
  count = var.endpoint_type != "Gateway" && var.create_security_group ? 1 : 0

  name        = coalesce(var.security_group_name, "${var.name}-vpce-sg")
  description = "Security group for VPC endpoint ${var.name}"
  vpc_id      = var.vpc_id

  tags = merge(var.tags, {
    Name = coalesce(var.security_group_name, "${var.name}-vpce-sg")
  })
}

resource "aws_vpc_security_group_ingress_rule" "https_ingress" {
  count = var.endpoint_type != "Gateway" && var.create_security_group ? 1 : 0

  security_group_id = aws_security_group.endpoint_sg[0].id
  description       = "Allow HTTPS from VPC CIDR"
  cidr_ipv4         = data.aws_vpc.selected.cidr_block
  from_port         = 443
  to_port           = 443
  ip_protocol       = "tcp"

  tags = var.tags
}

resource "aws_vpc_security_group_egress_rule" "all_egress" {
  count = var.endpoint_type != "Gateway" && var.create_security_group ? 1 : 0

  security_group_id = aws_security_group.endpoint_sg[0].id
  description       = "Allow all outbound"
  cidr_ipv4         = "0.0.0.0/0"
  ip_protocol       = "-1"

  tags = var.tags
}

################################################################################
# LOCALS
################################################################################

locals {
  # Merge module-created SG with any caller-supplied SG IDs
  effective_security_group_ids = var.endpoint_type != "Gateway" ? concat(
    aws_security_group.endpoint_sg[*].id,
    var.security_group_ids
  ) : []
}

################################################################################
# VPC ENDPOINT
################################################################################

resource "aws_vpc_endpoint" "vpc_endpoint" {
  vpc_id            = var.vpc_id
  service_name      = var.service_name
  vpc_endpoint_type = var.endpoint_type

  # Gateway endpoint settings
  route_table_ids = var.endpoint_type == "Gateway" ? var.route_table_ids : null

  # Interface / GatewayLoadBalancer endpoint settings
  subnet_ids         = var.endpoint_type != "Gateway" ? var.subnet_ids : null
  security_group_ids = var.endpoint_type != "Gateway" ? local.effective_security_group_ids : null
  private_dns_enabled = (
    var.endpoint_type == "Interface" ? var.private_dns_enabled : null
  )

  # Optional IAM policy
  policy = var.policy

  # Optional auto-accept for cross-account endpoints
  auto_accept = var.auto_accept

  # DNS options for Interface endpoints
  dynamic "dns_options" {
    for_each = var.endpoint_type == "Interface" && var.dns_record_ip_type != null ? [1] : []
    content {
      dns_record_ip_type = var.dns_record_ip_type
    }
  }

  tags = merge(var.tags, {
    Name = var.name
  })

  timeouts {
    create = var.timeouts.create
    update = var.timeouts.update
    delete = var.timeouts.delete
  }
}
