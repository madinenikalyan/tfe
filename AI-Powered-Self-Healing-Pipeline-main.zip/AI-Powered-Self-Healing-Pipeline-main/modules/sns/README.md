# `modules/sns` — Production-Ready SNS Topic Module

A Terraform module for provisioning an AWS SNS **single topic** with KMS CMK
encryption, optional FIFO support, subscriptions, and resource-based policies.

---

## Features

| Feature | Details |
|---|---|
| **KMS encryption** | Dedicated CMK auto-created per topic (annual rotation always on); or reuse a caller-supplied key |
| **FIFO topics** | Optional strict ordering and exactly-once delivery with auto `.fifo` suffix |
| **Subscriptions** | Map-based subscriptions: Lambda, SQS, HTTP/S, email, SMS, Firehose, etc. |
| **Filter policies** | Per-subscription message filtering with configurable scope |
| **Topic policy** | Optional IAM resource policy for cross-account/cross-service access |
| **Delivery policy** | Optional HTTP/S retry configuration |
| **Archive** | Optional FIFO topic message archiving with configurable retention |

---

## Design Decisions

### One Topic per Module Call

Each module invocation creates exactly one topic. This keeps the interface simple,
limits the blast radius, and allows per-topic KMS/IAM scoping. For multiple topics,
invoke the module once per topic.

### KMS Encryption Always On

Server-side encryption is enforced — plaintext topics are never created. When
`kms_key_arn` is null the module provisions a dedicated CMK with annual key
rotation enabled. The key policy grants `sns.amazonaws.com` the minimum
required permissions (`GenerateDataKey*`, `Decrypt`).

### No Data Blocks

`account_id` and `aws_region` are passed as variables rather than looked up via
`data "aws_caller_identity"` / `data "aws_region"`. This avoids duplicate data-source
calls when the root module already has them.

---

## Usage

### Minimal — encrypted topic

```hcl
module "alerts_topic" {
  source = "./modules/sns"

  name         = "sales-automation-alerts"
  display_name = "Sales Automation Alerts"

  account_id = data.aws_caller_identity.current.account_id
  aws_region = data.aws_region.current.name

  tags = local.common_tags
}
```

### With subscriptions

```hcl
module "order_events" {
  source = "./modules/sns"

  name = "order-events"

  subscriptions = {
    process_lambda = {
      protocol = "lambda"
      endpoint = module.order_processor.function_arn
    }
    audit_queue = {
      protocol             = "sqs"
      endpoint             = module.audit_queue.queue_arn
      raw_message_delivery = true
    }
    ops_email = {
      protocol = "email"
      endpoint = "ops-team@example.com"
    }
  }

  account_id = data.aws_caller_identity.current.account_id
  aws_region = data.aws_region.current.name

  tags = local.common_tags
}
```

### FIFO topic with external KMS key

```hcl
module "ordered_events" {
  source = "./modules/sns"

  name                        = "transaction-events"
  fifo_topic                  = true
  content_based_deduplication = true
  kms_key_arn                 = module.shared_kms.key_arn

  account_id = data.aws_caller_identity.current.account_id
  aws_region = data.aws_region.current.name

  tags = local.common_tags
}
```

### With topic policy (allow S3 event notifications)

```hcl
module "s3_events_topic" {
  source = "./modules/sns"

  name         = "s3-upload-notifications"
  topic_policy = data.aws_iam_policy_document.s3_publish.json

  account_id = data.aws_caller_identity.current.account_id
  aws_region = data.aws_region.current.name

  tags = local.common_tags
}
```

---

## Inputs

| Variable | Type | Default | Description |
|---|---|---|---|
| `account_id` | `string` | required | AWS account ID (12-digit) |
| `aws_region` | `string` | required | AWS region name (e.g. `us-east-1`) |
| `aws_partition` | `string` | `"aws"` | AWS partition for ARN construction |
| `name` | `string` | required | Topic name (1–256 chars) |
| `display_name` | `string` | `null` | Human-readable display name |
| `fifo_topic` | `bool` | `false` | Create a FIFO topic |
| `content_based_deduplication` | `bool` | `false` | Enable content-based deduplication (FIFO only) |
| `kms_key_arn` | `string` | `null` | Existing KMS CMK ARN; null creates a dedicated CMK |
| `kms_key_deletion_window_in_days` | `number` | `30` | KMS key deletion wait (7–30 days) |
| `delivery_policy` | `string` | `null` | JSON delivery policy for HTTP/S endpoints |
| `archive_policy` | `string` | `null` | JSON archive policy for FIFO topics |
| `delivery_status_logging` | `object` | `null` | CloudWatch delivery status logging config |
| `topic_policy` | `string` | `null` | JSON IAM resource policy for the topic |
| `subscriptions` | `map(object)` | `{}` | Map of subscriptions (protocol, endpoint, filters, etc.) |
| `tags` | `map(string)` | `{}` | Tags applied to all resources |

---

## Outputs

| Output | Description |
|---|---|
| `topic_arn` | ARN of the SNS topic |
| `topic_id` | ID of the SNS topic |
| `topic_name` | Name of the SNS topic |
| `topic_owner` | AWS account ID of the topic owner |
| `subscription_arns` | Map of subscription label to subscription ARN |
| `kms_key_arn` | ARN of the KMS key (module-managed or caller-supplied) |
| `kms_key_id` | ID of the module-managed KMS CMK (null when caller supplies key) |
| `kms_alias_name` | KMS alias name (null when caller supplies key) |

---

## Notes

- **FIFO suffix**: When `fifo_topic = true`, the module appends `.fifo` to the name
  automatically if not already present.
- **Caller-managed KMS**: When `kms_key_arn` is supplied, no CMK is created. The
  caller is responsible for KMS key policy and lifecycle.
- **Email subscriptions**: Email and SMS subscriptions require manual confirmation
  by the recipient. Terraform will show `PendingConfirmation` until confirmed.
- **Raw message delivery**: Set `raw_message_delivery = true` for SQS and HTTP/S
  subscriptions to receive the raw message body instead of the SNS JSON envelope.
