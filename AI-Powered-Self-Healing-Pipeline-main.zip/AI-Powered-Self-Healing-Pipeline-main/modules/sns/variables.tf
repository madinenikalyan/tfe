################################################################################
# AWS ACCOUNT & REGION — passed from root module
################################################################################

variable "account_id" {
  description = <<-EOT
    AWS account ID. Passed from the root module's data.aws_caller_identity.current.account_id.
    Used in KMS key policies.
  EOT
  type        = string

  validation {
    condition     = can(regex("^[0-9]{12}$", var.account_id))
    error_message = "'account_id' must be a 12-digit AWS account ID."
  }
}

variable "aws_region" {
  description = <<-EOT
    AWS region name (e.g. "us-east-1"). Passed from the root module's data.aws_region.current.name.
  EOT
  type        = string

  validation {
    condition     = can(regex("^[a-z]{2}-[a-z]+-[0-9]{1}$", var.aws_region))
    error_message = "'aws_region' must be a valid AWS region name (e.g. 'us-east-1')."
  }
}

variable "aws_partition" {
  description = "AWS partition for ARN construction (e.g. 'aws', 'aws-cn', 'aws-us-gov')."
  type        = string
  default     = "aws"
}

################################################################################
# TOPIC IDENTITY
################################################################################

variable "name" {
  description = <<-EOT
    Name of the SNS topic. For FIFO topics, ".fifo" suffix is appended automatically
    if not already present when fifo_topic = true.
  EOT
  type        = string

  validation {
    condition     = length(var.name) >= 1 && length(var.name) <= 256
    error_message = "'name' must be between 1 and 256 characters."
  }
}

variable "display_name" {
  description = "Human-readable display name for the topic (used in email subject lines for email subscriptions)."
  type        = string
  default     = null
}

################################################################################
# FIFO SETTINGS
################################################################################

variable "fifo_topic" {
  description = <<-EOT
    Whether to create a FIFO topic (strict message ordering, exactly-once delivery).
    FIFO topic names must end in ".fifo" — the module appends this automatically.
  EOT
  type        = bool
  default     = false
}

variable "content_based_deduplication" {
  description = <<-EOT
    Enable content-based deduplication for FIFO topics.
    When true, SNS uses a SHA-256 hash of the message body for deduplication.
    When false, a MessageDeduplicationId must be provided with each publish call.
    Only applies when fifo_topic = true.
  EOT
  type        = bool
  default     = false
}

################################################################################
# ENCRYPTION
################################################################################

variable "kms_key_arn" {
  description = <<-EOT
    ARN of a KMS CMK for server-side encryption.
    When null (default), the module creates a dedicated CMK with annual key rotation.
    Pass an existing key ARN to reuse a shared KMS key.
  EOT
  type        = string
  default     = null
}

variable "kms_key_deletion_window_in_days" {
  description = "Waiting period (in days) before KMS key deletion. Valid range: 7–30."
  type        = number
  default     = 30

  validation {
    condition     = var.kms_key_deletion_window_in_days >= 7 && var.kms_key_deletion_window_in_days <= 30
    error_message = "'kms_key_deletion_window_in_days' must be between 7 and 30."
  }
}

################################################################################
# DELIVERY
################################################################################

variable "delivery_policy" {
  description = <<-EOT
    JSON-encoded SNS delivery policy for HTTP/S endpoints.
    Controls retry behaviour (backoff, max retries, throttle).
    Null uses AWS default delivery policy.
  EOT
  type        = string
  default     = null
}

variable "archive_policy" {
  description = <<-EOT
    JSON-encoded archive policy for FIFO topic message archiving.
    Example: jsonencode({ MessageRetentionPeriod = 7 })
    Only applies to FIFO topics. Null disables archiving.
  EOT
  type        = string
  default     = null
}

variable "delivery_status_logging" {
  description = <<-EOT
    Configuration for CloudWatch delivery status logging.
    Requires an IAM role with CloudWatch Logs write permissions.
    Example:
      {
        iam_role_arn          = module.sns_logging_role.role_arn
        iam_failure_role_arn  = module.sns_logging_role.role_arn
        success_sample_rate  = 100
      }
  EOT
  type = object({
    iam_role_arn         = string
    iam_failure_role_arn = optional(string)
    success_sample_rate  = optional(number, 100)
  })
  default = null
}

################################################################################
# TOPIC POLICY
################################################################################

variable "topic_policy" {
  description = <<-EOT
    JSON-encoded IAM resource policy to attach to the topic.
    Controls which principals can publish or subscribe.
    Use aws_iam_policy_document data source in the caller for type safety.
    Null skips policy creation.
  EOT
  type        = string
  default     = null
}

################################################################################
# SUBSCRIPTIONS
################################################################################

variable "subscriptions" {
  description = <<-EOT
    Map of subscriptions to create for this topic.
    Each key is an arbitrary label; value defines the subscription.

    Supported protocols: lambda, sqs, http, https, email, email-json, sms, application, firehose.

    Example:
      subscriptions = {
        process_lambda = {
          protocol = "lambda"
          endpoint = module.my_lambda.function_arn
        }
        alert_email = {
          protocol = "email"
          endpoint = "team@example.com"
        }
        dlq_sqs = {
          protocol             = "sqs"
          endpoint             = module.my_queue.queue_arn
          raw_message_delivery = true
        }
      }
  EOT
  type = map(object({
    protocol                        = string
    endpoint                        = string
    filter_policy                   = optional(string)
    filter_policy_scope             = optional(string)
    raw_message_delivery            = optional(bool, false)
    redrive_policy                  = optional(string)
    subscription_role_arn           = optional(string)
    confirmation_timeout_in_minutes = optional(number)
  }))
  default = {}
}

################################################################################
# TAGS
################################################################################

variable "tags" {
  description = "Map of tags applied to all resources created by this module."
  type        = map(string)
  default     = {}
}
