################################################################################
# SNS — Production-Ready Topic Module
#
# Creates a production-ready AWS SNS topic with:
#   - KMS encryption always enabled (dedicated CMK or caller-supplied key)
#   - Optional FIFO topic support with content-based deduplication
#   - Optional subscriptions (Lambda, SQS, HTTP/S, email, SMS)
#   - Optional resource-based access policy
#   - Optional delivery status logging for supported protocols
#   - Optional message filtering per subscription
#   - Server-side encryption enforced — plaintext topics are never created
#
# DESIGN NOTE — single topic per invocation:
#   This module follows the same pattern as secrets-manager: one resource per
#   module call. For multiple topics, invoke the module once per topic.
#   This keeps the blast radius small and allows per-topic IAM/KMS scoping.
#
# DESIGN NOTE — KMS encryption:
#   When kms_key_arn is null (default), a dedicated CMK is created with
#   annual key rotation enabled. The key policy grants sns.amazonaws.com
#   the minimum required permissions. Pass an existing key ARN to skip
#   CMK creation and reuse a shared key.
#
# DESIGN NOTE — FIFO topics:
#   FIFO topics guarantee strict ordering and exactly-once delivery.
#   The topic name must end in ".fifo" — set fifo_topic = true and the
#   module appends the suffix automatically if not already present.
################################################################################

################################################################################
# LOCALS
################################################################################

locals {
  kms_key_arn = var.kms_key_arn != null ? var.kms_key_arn : aws_kms_key.sns_encryption[0].arn
}

################################################################################
# KMS KEY — one CMK per topic (unless caller supplies their own key)
#
# Key policy grants:
#   - Root account: full administration (AWS requirement)
#   - sns.amazonaws.com: GenerateDataKey / Decrypt for envelope encryption
################################################################################

data "aws_iam_policy_document" "sns_kms_policy" {
  count = var.kms_key_arn == null ? 1 : 0

  statement {
    sid    = "EnableRootAccountAdmin"
    effect = "Allow"
    principals {
      type        = "AWS"
      identifiers = ["arn:${var.aws_partition}:iam::${var.account_id}:root"]
    }
    actions   = ["kms:*"]
    resources = ["*"]
  }

  statement {
    sid    = "AllowSNSServiceEncryption"
    effect = "Allow"
    principals {
      type        = "Service"
      identifiers = ["sns.amazonaws.com"]
    }
    actions = [
      "kms:GenerateDataKey*",
      "kms:Decrypt",
    ]
    resources = ["*"]
    condition {
      test     = "StringEquals"
      variable = "kms:CallerAccount"
      values   = [var.account_id]
    }
  }
}

resource "aws_kms_key" "sns_encryption" {
  count = var.kms_key_arn == null ? 1 : 0

  description              = "KMS CMK for SNS topic: ${var.name}"
  key_usage                = "ENCRYPT_DECRYPT"
  customer_master_key_spec = "SYMMETRIC_DEFAULT"
  deletion_window_in_days  = var.kms_key_deletion_window_in_days
  enable_key_rotation      = true
  multi_region             = false
  policy                   = data.aws_iam_policy_document.sns_kms_policy[0].json

  tags = merge({ Name = "${var.name}-sns-cmk" }, var.tags)
}

resource "aws_kms_alias" "sns_encryption" {
  count = var.kms_key_arn == null ? 1 : 0

  name          = "alias/${replace(var.name, "/", "-")}-sns"
  target_key_id = aws_kms_key.sns_encryption[0].key_id
}

################################################################################
# SNS TOPIC
################################################################################

resource "aws_sns_topic" "sns_topic" {
  name         = var.fifo_topic ? (endswith(var.name, ".fifo") ? var.name : "${var.name}.fifo") : var.name
  display_name = var.display_name

  # Encryption — always enabled with CMK.
  kms_master_key_id = local.kms_key_arn

  # FIFO settings
  fifo_topic                  = var.fifo_topic
  content_based_deduplication = var.fifo_topic ? var.content_based_deduplication : null

  # Delivery policy (HTTP/S endpoints)
  delivery_policy = var.delivery_policy

  # Message retention for FIFO topics (1–14 days in archive)
  archive_policy = var.archive_policy

  tags = merge({ Name = var.name }, var.tags)
}

################################################################################
# SNS TOPIC POLICY (optional)
#
# Controls which AWS principals/services can publish or subscribe.
# Public access is restricted by design.
################################################################################

resource "aws_sns_topic_policy" "sns_topic_policy" {
  count = var.topic_policy != null ? 1 : 0

  arn    = aws_sns_topic.sns_topic.arn
  policy = var.topic_policy
}

################################################################################
# SNS SUBSCRIPTIONS
#
# Supports: lambda, sqs, http, https, email, email-json, sms, application, firehose.
# Each entry in var.subscriptions creates one subscription.
################################################################################

resource "aws_sns_topic_subscription" "sns_subscription" {
  for_each = var.subscriptions

  topic_arn = aws_sns_topic.sns_topic.arn
  protocol  = each.value.protocol
  endpoint  = each.value.endpoint

  # Filtering
  filter_policy       = each.value.filter_policy
  filter_policy_scope = each.value.filter_policy_scope

  # Delivery
  raw_message_delivery = each.value.raw_message_delivery
  redrive_policy       = each.value.redrive_policy

  # SQS / Lambda specific
  subscription_role_arn = each.value.subscription_role_arn

  # DLQ for failed deliveries
  confirmation_timeout_in_minutes = each.value.confirmation_timeout_in_minutes
}
