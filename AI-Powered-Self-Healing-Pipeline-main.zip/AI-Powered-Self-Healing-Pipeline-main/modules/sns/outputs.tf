################################################################################
# TOPIC
################################################################################

output "topic_arn" {
  description = "ARN of the SNS topic."
  value       = aws_sns_topic.sns_topic.arn
}

output "topic_id" {
  description = "ID of the SNS topic (same as ARN)."
  value       = aws_sns_topic.sns_topic.id
}

output "topic_name" {
  description = "Name of the SNS topic as created in AWS."
  value       = aws_sns_topic.sns_topic.name
}

output "topic_owner" {
  description = "AWS account ID of the topic owner."
  value       = aws_sns_topic.sns_topic.owner
}

################################################################################
# SUBSCRIPTIONS
################################################################################

output "subscription_arns" {
  description = "Map of subscription label → subscription ARN."
  value       = { for k, s in aws_sns_topic_subscription.sns_subscription : k => s.arn }
}

################################################################################
# KMS KEY
################################################################################

output "kms_key_arn" {
  description = <<-EOT
    ARN of the KMS key used to encrypt this topic.
    Either the module-managed CMK or the caller-supplied key.
  EOT
  value       = local.kms_key_arn
}

output "kms_key_id" {
  description = "ID of the module-managed KMS CMK. Null when kms_key_arn is supplied."
  value       = length(aws_kms_key.sns_encryption) > 0 ? aws_kms_key.sns_encryption[0].key_id : null
}

output "kms_alias_name" {
  description = "KMS alias name for the module-managed CMK. Null when kms_key_arn is supplied."
  value       = length(aws_kms_alias.sns_encryption) > 0 ? aws_kms_alias.sns_encryption[0].name : null
}
