################################################################################
# REST API
################################################################################

output "rest_api_id" {
  description = "ID of the REST API. Used to construct resource IDs and ARNs."
  value       = aws_api_gateway_rest_api.api.id
}

output "rest_api_arn" {
  description = "ARN of the REST API."
  value       = aws_api_gateway_rest_api.api.arn
}

output "rest_api_name" {
  description = "Name of the REST API."
  value       = aws_api_gateway_rest_api.api.name
}

output "root_resource_id" {
  description = <<-EOT
    Resource ID of the API root resource (/).
    Use this as parent_id when creating additional resources outside this module.
  EOT
  value       = aws_api_gateway_rest_api.api.root_resource_id
}

output "execution_arn" {
  description = <<-EOT
    Execution ARN prefix of the REST API (without stage, method, or resource path).
    Format: arn:aws:execute-api:{region}:{account}:{api-id}
    Append /{stage}/{method}/{resource} to scope Lambda permissions to specific methods.
  EOT
  value       = aws_api_gateway_rest_api.api.execution_arn
}

################################################################################
# DEPLOYMENT
################################################################################

output "deployment_id" {
  description = "ID of the most recent API Gateway deployment."
  value       = aws_api_gateway_deployment.deployment.id
}

output "deployment_redeployment_hash" {
  description = <<-EOT
    SHA1 hash of the deployment trigger configuration. Changes whenever
    var.resources, var.methods, var.gateway_responses, or var.api_body change.
    Useful for CI/CD pipelines to detect whether a re-deployment occurred.
  EOT
  value       = aws_api_gateway_deployment.deployment.triggers["redeployment"]
}

################################################################################
# STAGE
################################################################################

output "stage_name" {
  description = "Name of the deployed stage (e.g. 'v1', 'prod')."
  value       = aws_api_gateway_stage.stage.stage_name
}

output "stage_arn" {
  description = "ARN of the API Gateway stage."
  value       = aws_api_gateway_stage.stage.arn
}

output "stage_execution_arn" {
  description = <<-EOT
    Execution ARN of the deployed stage.
    Format: arn:aws:execute-api:{region}:{account}:{api-id}/{stage}

    Use this to build Lambda invoke permission source ARNs:
      Allow stage-wide access:      "$${module.api_gateway.stage_execution_arn}/*/*"
      Allow specific method/path:   "$${module.api_gateway.stage_execution_arn}/GET/v1/users"

    Pass it to the Lambda module's api_gateway_invoke_permissions if you prefer
    managing permissions from the Lambda side instead of var.lambda_invoke_permissions.
  EOT
  value       = aws_api_gateway_stage.stage.execution_arn
}

output "invoke_url" {
  description = <<-EOT
    Base URL for invoking this API stage.
    Format: https://{api-id}.execute-api.{region}.amazonaws.com/{stage}
    Append the resource path to construct a full endpoint URL.
  EOT
  value       = aws_api_gateway_stage.stage.invoke_url
}

################################################################################
# API RESOURCES
################################################################################

output "resource_ids" {
  description = <<-EOT
    Map of resource key → resource ID for all path resources created by this module.
    Includes resources at all nesting levels (level1 through level3).
    Use these IDs to create additional methods or resources outside this module.
  EOT
  value       = local.all_resource_ids
}

output "resource_paths" {
  description = "Map of resource key → full resource path for all API resources."
  value = merge(
    { for k, r in aws_api_gateway_resource.level1 : k => r.path },
    { for k, r in aws_api_gateway_resource.level2 : k => r.path },
    { for k, r in aws_api_gateway_resource.level3 : k => r.path },
  )
}

################################################################################
# AUTHORIZERS
################################################################################

output "authorizer_ids" {
  description = <<-EOT
    Map of authorizer key → authorizer ID for all authorizers created by this module.
    Use these IDs when creating additional methods outside this module.
  EOT
  value       = { for k, a in aws_api_gateway_authorizer.authorizers : k => a.id }
}

################################################################################
# REQUEST VALIDATORS
################################################################################

output "request_validator_ids" {
  description = "Map of validator key → validator ID for all request validators."
  value       = { for k, v in aws_api_gateway_request_validator.validators : k => v.id }
}

################################################################################
# VPC LINKS
################################################################################

output "vpc_link_ids" {
  description = <<-EOT
    Map of VPC Link key → VPC Link ID for all VPC Links created by this module.
    Use these IDs in integration configurations outside this module.
  EOT
  value       = { for k, l in aws_api_gateway_vpc_link.vpc_links : k => l.id }
}

################################################################################
# API KEYS
################################################################################

output "api_key_ids" {
  description = "Map of API key variable key → API key ID."
  value       = { for k, key in aws_api_gateway_api_key.keys : k => key.id }
}

output "api_key_values" {
  description = <<-EOT
    Map of API key variable key → API key value (sensitive).
    Store these in AWS Secrets Manager rather than in Terraform state for production use.
  EOT
  sensitive   = true
  value       = { for k, key in aws_api_gateway_api_key.keys : k => key.value }
}

output "api_key_arns" {
  description = "Map of API key variable key → API key ARN."
  value       = { for k, key in aws_api_gateway_api_key.keys : k => key.arn }
}

################################################################################
# USAGE PLANS
################################################################################

output "usage_plan_ids" {
  description = "Map of usage plan key → usage plan ID."
  value       = { for k, plan in aws_api_gateway_usage_plan.plans : k => plan.id }
}

output "usage_plan_arns" {
  description = "Map of usage plan key → usage plan ARN."
  value       = { for k, plan in aws_api_gateway_usage_plan.plans : k => plan.arn }
}

################################################################################
# IAM
################################################################################

output "cloudwatch_role_arn" {
  description = <<-EOT
    ARN of the IAM role created for API Gateway CloudWatch Logs access.
    Null when create_cloudwatch_role = false.
    Share this ARN with other API GW modules in the same account/region via
    their cloudwatch_role_arn variable to avoid duplicate role creation.
  EOT
  value       = var.create_cloudwatch_role ? module.cloudwatch_role[0].role_arn : null
}

output "cloudwatch_role_name" {
  description = "Name of the IAM role for API Gateway CloudWatch Logs. Null when not created."
  value       = var.create_cloudwatch_role ? module.cloudwatch_role[0].role_name : null
}

################################################################################
# CLOUDWATCH LOG GROUP
################################################################################

output "access_log_group_name" {
  description = <<-EOT
    Name of the module-managed CloudWatch log group for API Gateway access logs.
    Null when access logging is disabled or when an external destination ARN is supplied.
  EOT
  value = (
    length(aws_cloudwatch_log_group.access_logs) > 0
    ? aws_cloudwatch_log_group.access_logs[0].name
    : null
  )
}

output "access_log_group_arn" {
  description = <<-EOT
    ARN of the module-managed CloudWatch log group for access logs.
    Null when access logging is disabled or when an external destination ARN is supplied.
  EOT
  value = (
    length(aws_cloudwatch_log_group.access_logs) > 0
    ? aws_cloudwatch_log_group.access_logs[0].arn
    : null
  )
}

output "execution_log_group_name" {
  description = <<-EOT
    Name of the module-managed CloudWatch log group for API Gateway execution logs.
    Format: API-Gateway-Execution-Logs_{api-id}/{stage-name}
    Always created — execution logging is unconditionally enabled by this module.
  EOT
  value       = aws_cloudwatch_log_group.execution_logs.name
}

output "execution_log_group_arn" {
  description = <<-EOT
    ARN of the module-managed CloudWatch log group for execution logs.
    Always created — execution logging is unconditionally enabled by this module.
  EOT
  value       = aws_cloudwatch_log_group.execution_logs.arn
}

################################################################################
# CUSTOM DOMAIN
################################################################################

output "custom_domain_name" {
  description = "The custom domain name string. Null when no custom domain is configured."
  value       = var.custom_domain != null ? aws_api_gateway_domain_name.custom_domain[0].domain_name : null
}

output "custom_domain_regional_domain_name" {
  description = <<-EOT
    Regional hostname to use as the ALIAS/CNAME DNS target for REGIONAL custom domains.
    Create a Route 53 Alias record (or CNAME) pointing to this hostname.
    Null when endpoint_type = EDGE or when no custom domain is configured.
  EOT
  value = (
    var.custom_domain != null && var.custom_domain.endpoint_type == "REGIONAL"
    ? aws_api_gateway_domain_name.custom_domain[0].regional_domain_name
    : null
  )
}

output "custom_domain_regional_zone_id" {
  description = <<-EOT
    Hosted zone ID for the regional custom domain — required for Route 53 Alias records.
    Null when endpoint_type = EDGE or when no custom domain is configured.
  EOT
  value = (
    var.custom_domain != null && var.custom_domain.endpoint_type == "REGIONAL"
    ? aws_api_gateway_domain_name.custom_domain[0].regional_zone_id
    : null
  )
}

output "custom_domain_cloudfront_domain_name" {
  description = <<-EOT
    CloudFront distribution hostname for EDGE custom domains.
    Create a Route 53 Alias record pointing to this hostname.
    Null when endpoint_type = REGIONAL or when no custom domain is configured.
  EOT
  value = (
    var.custom_domain != null && var.custom_domain.endpoint_type == "EDGE"
    ? aws_api_gateway_domain_name.custom_domain[0].cloudfront_domain_name
    : null
  )
}

output "custom_domain_cloudfront_zone_id" {
  description = <<-EOT
    Hosted zone ID of the CloudFront distribution for EDGE custom domains.
    Required for Route 53 Alias records targeting CloudFront.
    Null when endpoint_type = REGIONAL or when no custom domain is configured.
  EOT
  value = (
    var.custom_domain != null && var.custom_domain.endpoint_type == "EDGE"
    ? aws_api_gateway_domain_name.custom_domain[0].cloudfront_zone_id
    : null
  )
}
