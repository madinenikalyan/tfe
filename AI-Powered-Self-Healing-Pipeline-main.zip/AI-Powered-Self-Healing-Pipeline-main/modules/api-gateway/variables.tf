################################################################################
# API IDENTITY
################################################################################

variable "api_name" {
  description = <<-EOT
    Name of the REST API. Must be unique per AWS account and region.
    Used as the base name for the CloudWatch log group, IAM roles, and domain mapping.
  EOT
  type        = string

  validation {
    condition     = length(trimspace(var.api_name)) > 0
    error_message = "'api_name' must not be empty."
  }
}

variable "description" {
  description = "Human-readable description of this API's purpose."
  type        = string
  default     = ""
}

################################################################################
# ENDPOINT CONFIGURATION
################################################################################

variable "endpoint_configuration" {
  description = <<-EOT
    Endpoint type and optional VPC endpoint IDs for private APIs.

    types:
      ["REGIONAL"] — deploys in a single AWS region (recommended for most use cases)
      ["EDGE"]     — CloudFront-fronted global edge endpoint (lower latency globally)
      ["PRIVATE"]  — only accessible from within a VPC via interface VPC endpoints

    vpc_endpoint_ids: required only when types = ["PRIVATE"]; list of VPC endpoint IDs
    that are allowed to access the API. Ignored for REGIONAL and EDGE.

    Example (regional):
      endpoint_configuration = { types = ["REGIONAL"], vpc_endpoint_ids = [] }

    Example (private):
      endpoint_configuration = {
        types            = ["PRIVATE"]
        vpc_endpoint_ids = ["vpce-0abc123def456"]
      }
  EOT
  type = object({
    types            = list(string)
    vpc_endpoint_ids = optional(list(string), [])
  })
  default = {
    types            = ["REGIONAL"]
    vpc_endpoint_ids = []
  }

  validation {
    condition = (
      length(var.endpoint_configuration.types) == 1 &&
      contains(["REGIONAL", "EDGE", "PRIVATE"], var.endpoint_configuration.types[0])
    )
    error_message = "'endpoint_configuration.types' must be exactly one of: [\"REGIONAL\"], [\"EDGE\"], or [\"PRIVATE\"]."
  }
}

variable "api_key_source" {
  description = <<-EOT
    Source of the API key for API key-based usage plan enforcement.
      "HEADER"     — API GW reads the x-api-key request header (default)
      "AUTHORIZER" — API GW reads the key from a Lambda authorizer's context variable
  EOT
  type        = string
  default     = "HEADER"

  validation {
    condition     = contains(["HEADER", "AUTHORIZER"], var.api_key_source)
    error_message = "'api_key_source' must be either \"HEADER\" or \"AUTHORIZER\"."
  }
}

variable "minimum_compression_size" {
  description = <<-EOT
    Minimum response payload size in bytes to enable response compression (gzip).
    Set to -1 to disable compression. Valid range: 0 – 10485760 (10 MB).
    A value of 0 compresses every response regardless of size.
  EOT
  type        = number
  default     = -1

  validation {
    condition     = var.minimum_compression_size == -1 || (var.minimum_compression_size >= 0 && var.minimum_compression_size <= 10485760)
    error_message = "'minimum_compression_size' must be -1 (disabled) or a value between 0 and 10485760."
  }
}

variable "binary_media_types" {
  description = <<-EOT
    List of MIME types whose request/response payloads should be treated as binary
    (base64-encoded when passed through API GW). Common values:
      ["image/png", "image/jpeg", "application/pdf", "application/octet-stream"]
    Use ["*/*"] to treat all types as binary.
    Leave empty (default) to treat all content as text/UTF-8.
  EOT
  type        = list(string)
  default     = []
}

variable "disable_execute_api_endpoint" {
  description = <<-EOT
    When true, disables the default "execute-api" endpoint
    (https://{api-id}.execute-api.{region}.amazonaws.com/{stage}).
    Set to true when using a custom domain so the default URL is not accessible.
  EOT
  type        = bool
  default     = false
}

variable "api_body" {
  description = <<-EOT
    Optional OpenAPI 3.0 / Swagger 2.0 specification (JSON or YAML string).
    When set, API GW imports the full API definition from the spec.
    Leave var.resources and var.methods empty when using api_body — the spec
    owns all resource and method definitions and mixing both causes conflicts.
  EOT
  type        = string
  default     = null
}

################################################################################
# PATH RESOURCES — up to 3 levels of nesting
#
# The module auto-detects nesting depth from parent_key references:
#   parent_key = null      → level 1 (child of root resource /)
#   parent_key = "key"     → level 2 (child of the level-1 resource with that key)
#   parent_key = "key2"    → level 3 (child of the level-2 resource with that key)
#
# Example:
#   resources = {
#     "v1"     = { path_part = "v1",     parent_key = null  }  # /v1
#     "users"  = { path_part = "users",  parent_key = "v1"  }  # /v1/users
#     "user"   = { path_part = "{id}",   parent_key = "users" } # /v1/users/{id}
#   }
################################################################################

variable "resources" {
  description = <<-EOT
    Map of API path resources. Each key is a unique identifier used to reference
    the resource in var.methods (via resource_key) and to build parent_key links.

    path_part : the URL path segment for this resource. Use {param} for path parameters.
    parent_key: key of the parent resource (must be another key in this map);
                null targets the root resource (/).

    Supports up to 3 levels of nesting (root → level1 → level2 → level3).

    Example:
      resources = {
        "api"      = { path_part = "api",     parent_key = null    }  # /api
        "v1"       = { path_part = "v1",      parent_key = "api"   }  # /api/v1
        "users"    = { path_part = "users",   parent_key = "v1"    }  # /api/v1/users
        "user_id"  = { path_part = "{userId}",parent_key = "users" }  # /api/v1/users/{userId}
      }
  EOT
  type = map(object({
    path_part  = string
    parent_key = optional(string) # null = child of root resource
  }))
  default = {}
}

################################################################################
# REQUEST VALIDATORS
################################################################################

variable "request_validators" {
  description = <<-EOT
    Map of request validators. Each entry defines what to validate on inbound requests.
    Reference a validator by its key in var.methods[*].request_validator_id.

    validate_request_body:       validate the request body against the registered model
    validate_request_parameters: validate required query strings and headers

    Example:
      request_validators = {
        "body_only"   = { name = "body-validator",   validate_request_body = true,  validate_request_parameters = false }
        "params_only" = { name = "params-validator", validate_request_body = false, validate_request_parameters = true  }
        "full"        = { name = "full-validator",   validate_request_body = true,  validate_request_parameters = true  }
      }
  EOT
  type = map(object({
    name                        = string
    validate_request_body       = optional(bool, false)
    validate_request_parameters = optional(bool, false)
  }))
  default = {}
}

################################################################################
# AUTHORIZERS
################################################################################

variable "authorizers" {
  description = <<-EOT
    Map of API Gateway authorizers. Reference an authorizer by its key in
    var.methods[*].authorizer_id.

    type:
      "TOKEN"              — Lambda authorizer that receives a bearer token
      "REQUEST"            — Lambda authorizer that receives the full request context
      "COGNITO_USER_POOLS" — Cognito user pool JWT validation

    For Lambda authorizers:
      authorizer_uri       — Lambda invoke ARN (use module.lambda.function_invoke_arn)
      authorizer_credentials — IAM role ARN for API GW to assume when calling Lambda;
                               leave null if the Lambda has a resource-based policy instead
      authorizer_result_ttl_in_seconds — cache TTL for the authorizer response (0 = no cache)
      identity_source      — where to extract the token from; default: Authorization header
      identity_validation_expression — regex to pre-validate the token format

    For Cognito authorizers:
      provider_arns — list of Cognito User Pool ARNs

    Example (Lambda TOKEN authorizer):
      authorizers = {
        "jwt_auth" = {
          name             = "jwt-authorizer"
          type             = "TOKEN"
          authorizer_uri   = module.auth_lambda.function_invoke_arn
          identity_source  = "method.request.header.Authorization"
          authorizer_result_ttl_in_seconds = 300
        }
      }

    Example (Cognito):
      authorizers = {
        "cognito" = {
          name          = "cognito-authorizer"
          type          = "COGNITO_USER_POOLS"
          provider_arns = [aws_cognito_user_pool.pool.arn]
        }
      }
  EOT
  type = map(object({
    name                             = string
    type                             = string
    authorizer_uri                   = optional(string)
    authorizer_credentials           = optional(string)
    authorizer_result_ttl_in_seconds = optional(number, 300)
    identity_source                  = optional(string, "method.request.header.Authorization")
    identity_validation_expression   = optional(string)
    provider_arns                    = optional(list(string), [])
  }))
  default = {}
}

################################################################################
# MODELS — JSON Schema definitions for request / response bodies
################################################################################

variable "models" {
  description = <<-EOT
    Map of API Gateway models (JSON Schema draft 4 definitions).
    Use model names in var.methods[*].request_models or method/integration responses.

    Example:
      models = {
        "create_user" = {
          name         = "CreateUserRequest"
          description  = "Schema for POST /users request body"
          content_type = "application/json"
          schema       = jsonencode({
            "$schema" = "http://json-schema.org/draft-04/schema#"
            type      = "object"
            required  = ["name", "email"]
            properties = {
              name  = { type = "string" }
              email = { type = "string", format = "email" }
            }
          })
        }
      }
  EOT
  type = map(object({
    name         = string
    description  = optional(string, "")
    content_type = optional(string, "application/json")
    schema       = string
  }))
  default = {}
}

################################################################################
# VPC LINKS — private NLB-backed integrations
################################################################################

variable "vpc_links" {
  description = <<-EOT
    Map of VPC Links for private HTTP integrations through a Network Load Balancer.
    Reference a VPC link by its key in var.methods[*].integration.vpc_link_key.

    target_arns: list of NLB ARNs to include in the VPC Link (typically one NLB).

    Example:
      vpc_links = {
        "private_nlb" = {
          name        = "internal-services-vpclink"
          description = "VPC Link to internal microservices NLB"
          target_arns = [aws_lb.internal.arn]
        }
      }
  EOT
  type = map(object({
    name        = string
    description = optional(string, "")
    target_arns = list(string) # NLB ARN(s)
  }))
  default = {}
}

################################################################################
# METHODS — HTTP methods, integrations, responses
#
# Each map entry is keyed by a unique identifier (e.g. "get_users").
# resource_key references a key in var.resources; use "ROOT" for the root resource.
################################################################################

variable "methods" {
  description = <<-EOT
    Map of HTTP methods with their integrations and response configurations.
    Each entry defines one route: resource + HTTP method + backend integration.

    KEY FIELDS:
      resource_key          — key from var.resources or "ROOT" for the root resource /
      http_method           — GET | POST | PUT | PATCH | DELETE | HEAD | OPTIONS | ANY
      authorization         — NONE | AWS_IAM | COGNITO_USER_POOLS | CUSTOM
      authorizer_id         — key from var.authorizers (required when authorization = CUSTOM or COGNITO_USER_POOLS)
      authorization_scopes  — list of Cognito scopes (for COGNITO_USER_POOLS)
      api_key_required      — true to enforce API key validation on this method
      request_parameters    — map of "method.request.{querystring|header|path}.name" → bool (true=required)
      request_validator_id  — key from var.request_validators; null skips validation
      request_models        — map of content-type → model name for body validation

    INTEGRATION FIELDS:
      type               — AWS_PROXY | HTTP_PROXY | AWS | HTTP | MOCK
      uri                — Lambda invoke_arn (AWS_PROXY/AWS) or full HTTPS URL (HTTP/HTTP_PROXY); null for MOCK
      http_method        — backend HTTP method; always "POST" for Lambda; null for MOCK
      credentials        — IAM role ARN for API GW to use when calling backend (optional)
      request_templates  — map of content-type → Velocity template (non-proxy only)
      request_parameters — map of "integration.request.*" → "method.request.*" (non-proxy only)
      passthrough_behavior — WHEN_NO_MATCH | WHEN_NO_TEMPLATES | NEVER
      content_handling   — CONVERT_TO_BINARY | CONVERT_TO_TEXT | null
      timeout_milliseconds — 50–29000 ms (default 29000)
      connection_type    — INTERNET (default) | VPC_LINK
      vpc_link_key       — key from var.vpc_links; takes precedence over connection_id
      connection_id      — literal VPC Link ID (for externally-created VPC Links)
      cache_key_parameters — list of request parameters to use as cache keys
      cache_namespace    — custom cache namespace identifier

    RESPONSES (method responses):
      Map from status_code string to response config. Keys are HTTP status codes.
      For AWS_PROXY and HTTP_PROXY, a single "200" entry is sufficient.
      For non-proxy integrations, add every status code the backend can return.
        response_models     — map of content-type → model name
        response_parameters — map of "method.response.header.Name" → bool (true=required)

    INTEGRATION RESPONSES:
      Map from status_code string to integration response config.
      Leave empty ({}) for AWS_PROXY and HTTP_PROXY integrations.
        selection_pattern   — regex matched against backend status code / Lambda errorType (null = default catch-all)
        response_templates  — map of content-type → Velocity template
        response_parameters — map of "method.response.header.X" = "integration.response.header.Y"
        content_handling    — CONVERT_TO_BINARY | CONVERT_TO_TEXT | null

    Example (Lambda proxy):
      methods = {
        "list_users" = {
          resource_key     = "users"
          http_method      = "GET"
          authorization    = "AWS_IAM"
          api_key_required = true
          integration = {
            type       = "AWS_PROXY"
            uri        = module.users_lambda.function_invoke_arn
            http_method = "POST"
          }
          responses = {
            "200" = { response_models = {}, response_parameters = {} }
          }
          integration_responses = {}
        }
      }

    Example (MOCK health-check — no backend):
      methods = {
        "health_check" = {
          resource_key  = "health"
          http_method   = "GET"
          authorization = "NONE"
          integration = {
            type              = "MOCK"
            request_templates = { "application/json" = "{\"statusCode\": 200}" }
          }
          responses = {
            "200" = { response_models = { "application/json" = "Empty" }, response_parameters = {} }
          }
          integration_responses = {
            "200" = {
              status_code        = "200"
              selection_pattern  = null
              response_templates = { "application/json" = "{\"status\": \"ok\"}" }
              response_parameters = {}
            }
          }
        }
      }
  EOT
  type = map(object({
    resource_key         = string
    http_method          = string
    authorization        = optional(string, "NONE")
    authorizer_id        = optional(string)
    authorization_scopes = optional(list(string), [])
    api_key_required     = optional(bool, false)
    request_parameters   = optional(map(bool), {})
    request_validator_id = optional(string)
    request_models       = optional(map(string), {})
    # Human-readable name shown in the API GW console and Swagger/OpenAPI exports.
    # Examples: "ListUsers", "CreateOrder", "HealthCheck"
    operation_name = optional(string)

    integration = object({
      type                 = optional(string, "AWS_PROXY") # AWS_PROXY | HTTP_PROXY | AWS | HTTP | MOCK
      uri                  = optional(string)
      http_method          = optional(string, "POST")
      credentials          = optional(string)
      request_templates    = optional(map(string), {})
      request_parameters   = optional(map(string), {})
      passthrough_behavior = optional(string, "WHEN_NO_MATCH")
      content_handling     = optional(string, "CONVERT_TO_TEXT") # CONVERT_TO_TEXT | CONVERT_TO_BINARY
      timeout_milliseconds = optional(number, 29000)
      connection_type      = optional(string, "INTERNET")
      vpc_link_key         = optional(string) # key from var.vpc_links (takes precedence over connection_id)
      connection_id        = optional(string) # literal VPC Link ID for externally-created links
      cache_key_parameters = optional(list(string), [])
      cache_namespace      = optional(string)
    })

    responses = optional(map(object({
      response_models     = optional(map(string), {})
      response_parameters = optional(map(bool), {})
      })), {
      "200" = {
        response_models     = {}
        response_parameters = {}
      }
    })

    integration_responses = optional(map(object({
      status_code         = string
      selection_pattern   = optional(string)
      response_templates  = optional(map(string), {})
      response_parameters = optional(map(string), {})
      content_handling    = optional(string, "CONVERT_TO_TEXT") # CONVERT_TO_TEXT | CONVERT_TO_BINARY
    })), {})
  }))
  default = {}
}

################################################################################
# GATEWAY RESPONSES — custom error response format / CORS headers
################################################################################

variable "gateway_responses" {
  description = <<-EOT
    Map of custom gateway responses for API-level errors. Common use cases:
      • Inject CORS headers into 4xx/5xx responses (DEFAULT_4XX, DEFAULT_5XX)
      • Override the default 401/403 response format (UNAUTHORIZED, ACCESS_DENIED)
      • Customize 400 bad request response (BAD_REQUEST_BODY, BAD_REQUEST_PARAMETERS)

    response_type: one of the AWS-defined response types:
      ACCESS_DENIED, API_CONFIGURATION_ERROR, AUTHORIZER_CONFIGURATION_ERROR,
      AUTHORIZER_FAILURE, BAD_REQUEST_BODY, BAD_REQUEST_PARAMETERS, DEFAULT_4XX,
      DEFAULT_5XX, EXPIRED_TOKEN, INTEGRATION_FAILURE, INTEGRATION_TIMEOUT,
      INVALID_API_KEY, INVALID_SIGNATURE, MISSING_AUTHENTICATION_TOKEN,
      QUOTA_EXCEEDED, REQUEST_TOO_LARGE, RESOURCE_NOT_FOUND, THROTTLED,
      UNAUTHORIZED, UNSUPPORTED_MEDIA_TYPE, WAF_FILTERED

    response_parameters keys: "gatewayresponse.header.<HeaderName>"
    response_templates keys: content-type strings (e.g. "application/json")

    Example (CORS on all errors):
      gateway_responses = {
        "default_4xx_cors" = {
          response_type = "DEFAULT_4XX"
          response_parameters = {
            "gatewayresponse.header.Access-Control-Allow-Origin"  = "'*'"
            "gatewayresponse.header.Access-Control-Allow-Headers" = "'Content-Type,Authorization'"
          }
        }
        "default_5xx_cors" = {
          response_type = "DEFAULT_5XX"
          response_parameters = {
            "gatewayresponse.header.Access-Control-Allow-Origin" = "'*'"
          }
        }
      }
  EOT
  type = map(object({
    response_type       = string
    status_code         = optional(string)          # null = use AWS default for response_type
    response_templates  = optional(map(string), {}) # content-type → Velocity template
    response_parameters = optional(map(string), {}) # header overrides
  }))
  default = {}
}

################################################################################
# STAGE CONFIGURATION
################################################################################

variable "environment" {
  description = <<-EOT
    Deployment environment name (e.g. "dev", "uat", "staging", "prod").
    Used as the default stage name when var.stage_name is not set.
    Also used as a fallback in resource naming and tagging.
  EOT
  type        = string
  default     = null
}

variable "stage_name" {
  description = <<-EOT
    Name of the API deployment stage. Defaults to var.environment when not set,
    so the stage name automatically mirrors the deployment environment.
    The stage name becomes part of the invoke URL:
      https://{api-id}.execute-api.{region}.amazonaws.com/{stage_name}/...
    At least one of stage_name or environment must be provided.
  EOT
  type        = string
  default     = null
}

variable "stage_description" {
  description = "Human-readable description for this deployment stage."
  type        = string
  default     = ""
}

variable "stage_variables" {
  description = <<-EOT
    Map of stage variables (key-value string pairs) available to integrations
    as $${stageVariables.name}. Useful for routing to different backends per stage.

    Example:
      stage_variables = {
        lambda_alias = "prod"
        backend_host = "api.internal.example.com"
      }
  EOT
  type        = map(string)
  default     = {}
}

variable "xray_tracing_enabled" {
  description = <<-EOT
    Enable AWS X-Ray distributed tracing on this stage. When enabled, API GW
    samples and records request traces that propagate to downstream Lambda functions
    and other AWS services that support X-Ray.
  EOT
  type        = bool
  default     = false
}

variable "cache_cluster_enabled" {
  description = <<-EOT
    Enable the response cache cluster for this stage. Required for any method-level
    caching configured in var.method_settings. Incurs an additional hourly cost.
  EOT
  type        = bool
  default     = false
}

variable "cache_cluster_size" {
  description = <<-EOT
    Cache cluster size in GB. Only relevant when cache_cluster_enabled = true.
    Valid values: "0.5", "1.6", "6.1", "13.5", "28.4", "58.2", "118", "237".
  EOT
  type        = string
  default     = "0.5"

  validation {
    condition     = contains(["0.5", "1.6", "6.1", "13.5", "28.4", "58.2", "118", "237"], var.cache_cluster_size)
    error_message = "'cache_cluster_size' must be one of: 0.5, 1.6, 6.1, 13.5, 28.4, 58.2, 118, 237."
  }
}

variable "client_certificate_id" {
  description = <<-EOT
    ID of a client certificate for mutual TLS between API GW and your backend.
    API GW presents this certificate when calling the integration endpoint.
    Use aws_api_gateway_client_certificate to create one.
  EOT
  type        = string
  default     = null
}

################################################################################
# METHOD SETTINGS — per-method throttle, logging, and cache overrides
################################################################################

variable "method_settings" {
  description = <<-EOT
    Per-method throttling, logging, and cache configuration for this stage.
    The map key is the method path in the format "{resource_path}/{HTTP_METHOD}".
    Use "*/*" to apply defaults to all methods.

    Key examples:
      "*/*"              — all methods (catch-all default)
      "v1/users/GET"     — GET /v1/users
      "/GET"             — GET on the root resource

    throttling_burst_limit : max concurrent requests (-1 = disabled, inherits account limit)
    throttling_rate_limit  : steady-state requests per second (-1 = disabled)
    metrics_enabled        : emit CloudWatch metrics for this method
    logging_level          : OFF | ERROR | INFO  (ERROR is recommended for production)
    data_trace_enabled     : log full request/response data (CAUTION: may log sensitive data)
    caching_enabled        : cache responses (requires cache_cluster_enabled = true)
    cache_ttl_in_seconds   : TTL for cached responses (0 = no cache, max 3600)
    cache_data_encrypted   : encrypt cached responses at rest

    Example:
      method_settings = {
        "*/*" = {
          metrics_enabled        = true
          logging_level          = "ERROR"
          throttling_burst_limit = 500
          throttling_rate_limit  = 100
        }
        "v1/users/POST" = {
          throttling_burst_limit = 50
          throttling_rate_limit  = 10
        }
      }
  EOT
  type = map(object({
    throttling_burst_limit                       = optional(number, -1)
    throttling_rate_limit                        = optional(number, -1)
    metrics_enabled                              = optional(bool, true)
    logging_level                                = optional(string, "ERROR")
    data_trace_enabled                           = optional(bool, false)
    caching_enabled                              = optional(bool, false)
    cache_ttl_in_seconds                         = optional(number, 300)
    cache_data_encrypted                         = optional(bool, false)
    require_authorization_for_cache_invalidation = optional(bool, true)
    unauthorized_cache_control_header_strategy   = optional(string, "SUCCEED_WITH_RESPONSE_HEADER")
  }))
  default = {}
}

################################################################################
# CLOUDWATCH ACCESS LOGGING
################################################################################

variable "access_log_settings" {
  description = <<-EOT
    Enable CloudWatch access logging for this stage.

    destination_arn:  ARN of an existing CloudWatch Logs log group or Kinesis Data
                      Firehose delivery stream. Set to null to have this module
                      create a new log group automatically.
    retention_in_days: Log retention period when the module creates the log group.
                       Only used when destination_arn = null.

    Common retention values: 1, 3, 5, 7, 14, 30, 60, 90, 120, 150, 180, 365

    Set to null entirely; a module-managed log group is always auto-created
    unless you supply an explicit destination_arn.

    Example (module creates log group with custom retention):
      access_log_settings = { destination_arn = null, retention_in_days = 30 }

    Example (use existing log group):
      access_log_settings = { destination_arn = aws_cloudwatch_log_group.existing.arn }
  EOT
  type = object({
    destination_arn   = optional(string)     # null = create new log group
    retention_in_days = optional(number, 90) # used only when destination_arn = null
  })
  default = null
}

variable "access_log_format" {
  description = <<-EOT
    CLF / structured log format string written to the access log group.
    Uses API Gateway context variables ($context.*) and supports any mix of
    plain text and variable references.

    The default format captures the most operationally useful fields:
      RequestId, source IP, HTTP method, resource path, response status,
      error message, authorizer error, caller identity, user identity,
      and the Authorization header value (for tracing auth issues).

    Override with a JSON-formatted string for structured log ingestion:
      format = jsonencode({
        requestId = "$context.requestId"
        status    = "$context.status"
        ...
      })
  EOT
  type        = string
  default     = "RequestId: $context.requestId | IP: $context.identity.sourceIp | Method: $context.httpMethod | Path: $context.resourcePath | Status: $context.status | Error: $context.error.message | AuthError: $context.authorizer.error | Caller: $context.identity.caller | User: $context.identity.user | Headers: $context.requestOverride.header.Authorization"
}

variable "access_log_retention_in_days" {
  description = <<-EOT
    Retention period (days) for the module-managed access log group.
    Only used when access_log_settings.destination_arn is null (module creates the log group).
    Common values: 7, 14, 30, 60, 90, 120, 180, 365.
  EOT
  type        = number
  default     = 90
}

variable "log_kms_key_id" {
  description = <<-EOT
    ARN of a KMS key to encrypt the module-created CloudWatch log groups
    (both access logs and execution logs).
    Leave null to use the default CloudWatch encryption (AWS-managed key).
    Only applies to log groups created by this module.
  EOT
  type        = string
  default     = null
}

################################################################################
# CLOUDWATCH EXECUTION LOGGING
################################################################################

variable "execution_logging_level" {
  description = <<-EOT
    Execution log level written to CloudWatch for all methods (catch-all */* setting).
      "OFF"   — disable execution logging
      "ERROR" — log only 4xx/5xx requests (recommended for production)
      "INFO"  — log every request regardless of outcome (verbose; for debugging)
    Override for individual methods or paths via var.method_settings.
  EOT
  type        = string
  default     = "ERROR"

  validation {
    condition     = contains(["OFF", "ERROR", "INFO"], var.execution_logging_level)
    error_message = "'execution_logging_level' must be \"OFF\", \"ERROR\", or \"INFO\"."
  }
}

variable "execution_data_trace_enabled" {
  description = <<-EOT
    Log full request and response bodies in CloudWatch execution logs.
    CAUTION: enabling this in production may log sensitive request payloads
    (tokens, PII, secrets). Set to true only for short-term debugging.
    This applies to the default */* catch-all method settings.
    Override for individual methods via var.method_settings.
  EOT
  type        = bool
  default     = false
}

variable "execution_log_retention_in_days" {
  description = <<-EOT
    Retention period (days) for the module-managed execution log group.
    Applies to the module-managed execution log group (always created).
    Common values: 7, 14, 30, 60, 90, 120, 180, 365.
  EOT
  type        = number
  default     = 90
}

################################################################################
# IAM — CloudWatch Logs role for API Gateway account
################################################################################

variable "create_cloudwatch_role" {
  description = <<-EOT
    Create an IAM role and configure aws_api_gateway_account so API Gateway can
    write execution logs and metrics to CloudWatch Logs (default: true).

    IMPORTANT: aws_api_gateway_account is a singleton per AWS account/region.
    Set create_cloudwatch_role = true in ONLY ONE module call per account/region.
    For every other API Gateway module in the same account/region pass the shared
    role ARN via var.cloudwatch_role_arn and set this to false.
  EOT
  type        = bool
  default     = true
}

variable "cloudwatch_role_arn" {
  description = <<-EOT
    ARN of a pre-existing IAM role that API Gateway can assume to write CloudWatch Logs.
    Use this when create_cloudwatch_role = false but you still want to set/update the
    account-level CloudWatch role (e.g. the role was created by another module).
    Leave null to skip updating the account-level setting entirely.
  EOT
  type        = string
  default     = null
}

variable "cloudwatch_role_name" {
  description = <<-EOT
    Name for the IAM role created when create_cloudwatch_role = true.
    Defaults to "<api_name>-apigw-cloudwatch-role".
  EOT
  type        = string
  default     = null
}

variable "iam_role_path" {
  description = <<-EOT
    IAM path for the CloudWatch Logs role. Must begin and end with '/'.
    Example: "/sales-automation/api-gateway/"
  EOT
  type        = string
  default     = "/"

  validation {
    condition     = startswith(var.iam_role_path, "/") && endswith(var.iam_role_path, "/")
    error_message = "'iam_role_path' must begin and end with a forward slash."
  }
}

################################################################################
# API KEYS
################################################################################

variable "api_keys" {
  description = <<-EOT
    Map of API keys to create. Each key is associated with usage plans via
    var.usage_plans[*].api_key_names.

    name        : display name for the key
    description : human-readable purpose
    enabled     : set false to disable the key without deleting it
    value       : explicit key value; null = API GW auto-generates a secure random value.
                  Never store explicit values in plaintext tfvars — use a Secrets Manager
                  reference or leave null for auto-generation.

    Example:
      api_keys = {
        "mobile_app" = {
          name        = "my-api-mobile-key"
          description = "API key for mobile application"
          enabled     = true
          value       = null   # auto-generated
        }
        "partner_A" = {
          name    = "my-api-partner-a-key"
          enabled = true
        }
      }
  EOT
  type = map(object({
    name        = string
    description = optional(string, "")
    enabled     = optional(bool, true)
    value       = optional(string) # null = API GW auto-generates
  }))
  default = {}
}

################################################################################
# USAGE PLANS
################################################################################

variable "usage_plans" {
  description = <<-EOT
    Map of usage plans. Each plan is automatically associated with this module's stage.
    Assign API keys to plans via api_key_names (references keys in var.api_keys).

    api_key_names      : list of key names from var.api_keys to attach to this plan
    per_method_throttle: per-method throttle overrides within this plan.
                         Key format: "{resource_path}/{HTTP_METHOD}" or "*/*"
    quota              : maximum requests per time period
      limit  — total request count allowed
      offset — number of requests to subtract from the limit at the start of the period
      period — DAY | WEEK | MONTH
    throttle           : plan-level default throttle (applies unless overridden per-method)
      burst_limit — max concurrent requests (token bucket size)
      rate_limit  — steady-state requests per second

    Example:
      usage_plans = {
        "standard" = {
          name         = "standard-plan"
          description  = "Standard rate limits for regular API consumers"
          api_key_names = ["mobile_app"]
          quota    = { limit = 10000, period = "DAY" }
          throttle = { burst_limit = 200, rate_limit = 100 }
          per_method_throttle = {
            "v1/users/POST" = { burst_limit = 20, rate_limit = 10 }
          }
        }
        "premium" = {
          name         = "premium-plan"
          description  = "Elevated limits for premium partners"
          api_key_names = ["partner_A"]
          quota    = { limit = 100000, period = "DAY" }
          throttle = { burst_limit = 1000, rate_limit = 500 }
        }
      }
  EOT
  type = map(object({
    name          = string
    description   = optional(string, "")
    api_key_names = optional(list(string), []) # keys from var.api_keys

    per_method_throttle = optional(map(object({
      burst_limit = number
      rate_limit  = number
    })), {})

    quota = optional(object({
      limit  = optional(number, 50000) # default: 50 000 requests
      offset = optional(number, 0)
      period = optional(string, "MONTH") # DAY | WEEK | MONTH
    }), { limit = 50000, offset = 0, period = "MONTH" })

    throttle = optional(object({
      burst_limit = optional(number, 5000)  # token-bucket size (concurrent req)
      rate_limit  = optional(number, 10000) # steady-state req/sec
    }), { burst_limit = 5000, rate_limit = 10000 })
  }))
  default = {}
}

################################################################################
# LAMBDA INVOKE PERMISSIONS
#
# Creates aws_lambda_permission resources granting this API GW stage the right
# to invoke the specified Lambda functions. See the DESIGN NOTE in main.tf.
#
# source_arn scope options (from least to most permissive):
#   Most restrictive: "$${module.api_gateway.stage_execution_arn}/GET/v1/users"
#   Stage-wide (default): "$${module.api_gateway.stage_execution_arn}/*/*"
################################################################################

variable "lambda_invoke_permissions" {
  description = <<-EOT
    Map of Lambda invoke permissions to create. Grants this API Gateway stage
    permission to invoke each Lambda function via a resource-based policy statement.

    function_name: Name or ARN of the Lambda function.
    qualifier    : Optional alias or version qualifier (e.g. "prod", "$LATEST").
    statement_id : Optional SID for the policy statement; auto-generated if null.
    source_arn   : Optional explicit source ARN for tighter scoping. Defaults to
                   allow all methods on this stage: {execution_arn}/*/*
                   Override to scope to a specific method:
                   "$${module.api_gateway.stage_execution_arn}/GET/v1/users"

    Example:
      lambda_invoke_permissions = {
        "users_lambda" = {
          function_name = module.users_lambda.function_name
          qualifier     = "prod"
        }
        "orders_lambda" = {
          function_name = "my-orders-lambda"
          source_arn    = "$${module.api_gateway.stage_execution_arn}/POST/v1/orders"
        }
      }
  EOT
  type = map(object({
    function_name = string
    qualifier     = optional(string)
    statement_id  = optional(string)
    source_arn    = optional(string) # null = scoped to entire stage (/{stage}/*/*)
  }))
  default = {}
}

################################################################################
# CUSTOM DOMAIN
################################################################################

variable "custom_domain" {
  description = <<-EOT
    Optional custom domain name configuration for this API.

    domain_name    : custom hostname (e.g. "api.example.com")
    certificate_arn: ACM certificate ARN. For REGIONAL, must be in the same region.
                     For EDGE, must be in us-east-1.
    endpoint_type  : REGIONAL (recommended) | EDGE
    security_policy: TLS_1_2 (recommended, required for PCI/HIPAA) | TLS_1_0
    base_path      : URL base path mapped to this stage; "" = root, "v1" = /v1
    ownership_verification_certificate_arn: ACM cert ARN for domain ownership verification
                     (required for some mutual-TLS configurations; leave null if not needed)

    Example:
      custom_domain = {
        domain_name     = "api.example.com"
        certificate_arn = aws_acm_certificate.api.arn
        endpoint_type   = "REGIONAL"
        security_policy = "TLS_1_2"
        base_path       = ""
      }

    After apply, create a DNS CNAME or ALIAS record pointing your domain to:
      module.api_gateway.custom_domain_regional_domain_name  (for REGIONAL)
      module.api_gateway.custom_domain_cloudfront_domain_name (for EDGE)
  EOT
  type = object({
    domain_name                            = string
    certificate_arn                        = string
    endpoint_type                          = optional(string, "REGIONAL")
    security_policy                        = optional(string, "TLS_1_2")
    base_path                              = optional(string, "")
    ownership_verification_certificate_arn = optional(string)
  })
  default = null

  validation {
    condition     = var.custom_domain == null || contains(["REGIONAL", "EDGE"], var.custom_domain.endpoint_type)
    error_message = "'custom_domain.endpoint_type' must be \"REGIONAL\" or \"EDGE\"."
  }

  validation {
    condition     = var.custom_domain == null || contains(["TLS_1_2", "TLS_1_0"], var.custom_domain.security_policy)
    error_message = "'custom_domain.security_policy' must be \"TLS_1_2\" (recommended) or \"TLS_1_0\"."
  }
}

################################################################################
# TAGS
################################################################################

variable "tags" {
  description = <<-EOT
    Map of tags applied to all taggable resources (REST API, stage, API keys,
    usage plans, VPC links, CloudWatch log group, IAM roles, custom domain).
    Merge with common_tags in the caller:

      tags = merge(local.common_tags, { Component = "api-gateway" })
  EOT
  type        = map(string)
  default     = {}
}
