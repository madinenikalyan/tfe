################################################################################
# API Gateway REST API Module
#
# This module provisions a production-ready AWS API Gateway REST API including:
#   - REST API with configurable endpoint type (REGIONAL / EDGE / PRIVATE)
#   - Path resources up to 3 levels deep, auto-detected from parent_key references
#   - HTTP methods with request validation, authorizers, and API-key enforcement
#   - Integrations: AWS_PROXY (Lambda), HTTP_PROXY, HTTP, AWS service, MOCK
#   - Method responses and integration responses (for non-proxy integrations)
#   - Custom gateway responses (for CORS headers, custom error formats, etc.)
#   - VPC Links for private NLB-backed integrations
#   - Automatic stage redeployment on ANY resource / method / integration change
#     via a sha1-hash trigger — no manual taint or forced replace required.
#   - Stage with execution logging, X-Ray tracing, caching, and CloudWatch access logs
#   - Per-method throttling, logging levels, and cache settings
#   - API Keys (auto-generated or custom) with Usage Plans and quota/throttle control
#   - Lambda resource-based invoke permissions scoped to this stage (see design note)
#   - IAM CloudWatch Logs role for the API GW account (optional, via ../iam module)
#   - Custom domain name mapping with TLS policy (REGIONAL or EDGE)
#   - Request validators (body, parameters, or both)
#   - Lambda and Cognito authorizers
#   - OpenAPI/Swagger body import as an alternative to Terraform-defined resources
#
# DESIGN NOTE — Lambda invoke permissions:
#   Permissions are created in the API Gateway module (not in the Lambda module)
#   because the `source_arn` includes the stage execution ARN, which is only
#   available after this module's `aws_api_gateway_stage` is created. This
#   removes the need for the caller to wire the ARN back into the Lambda module.
#   The Lambda module's `api_gateway_invoke_permissions` variable remains available
#   as an alternative if you prefer permission management from the Lambda side.
#
# DESIGN NOTE — aws_api_gateway_account:
#   `aws_api_gateway_account` is account- and region-scoped (one per region).
#   Set `create_cloudwatch_role = true` in ONLY ONE module call per account/region.
#   For all other API GW modules in the same account/region, leave this false and
#   supply the shared role ARN via `cloudwatch_role_arn`.
#
# Minimum Terraform version: 1.4 (uses optional() defaults, for_each on sets)
################################################################################



################################################################################
# LOCALS
################################################################################

locals {
  # ─── Resource nesting detection ─────────────────────────────────────────────
  # Resources at level 1: direct children of the API root (parent_key = null)
  level1_resource_keys = toset([
    for k, v in var.resources : k if v.parent_key == null
  ])

  # Resources at level 2: children of level-1 resources
  level2_resource_keys = toset([
    for k, v in var.resources : k
    if v.parent_key != null && contains(local.level1_resource_keys, v.parent_key)
  ])

  # Resources at level 3: children of level-2 resources
  level3_resource_keys = toset([
    for k, v in var.resources : k
    if v.parent_key != null && contains(local.level2_resource_keys, v.parent_key)
  ])

  # Merged lookup of ALL resource IDs across all nesting levels.
  # Used by method and integration resources to resolve resource_key → resource_id.
  all_resource_ids = merge(
    { for k, r in aws_api_gateway_resource.level1 : k => r.id },
    { for k, r in aws_api_gateway_resource.level2 : k => r.id },
    { for k, r in aws_api_gateway_resource.level3 : k => r.id },
  )

  # ─── Flattened method responses (one entry per method × response code) ───────
  method_responses = {
    for entry in flatten([
      for method_key, method in var.methods : [
        for resp_code, resp in method.responses : {
          key                 = "${method_key}__${resp_code}"
          method_key          = method_key
          resource_key        = method.resource_key
          http_method         = method.http_method
          status_code         = resp_code
          response_models     = resp.response_models
          response_parameters = resp.response_parameters
        }
      ]
    ]) : entry.key => entry
  }

  # ─── Flattened integration responses (one entry per method × response code) ─
  # Note: leave integration_responses = {} for AWS_PROXY and HTTP_PROXY methods;
  # proxy integrations return Lambda/backend responses directly.
  integration_responses = {
    for entry in flatten([
      for method_key, method in var.methods : [
        for resp_code, resp in method.integration_responses : {
          key                 = "${method_key}__${resp_code}"
          method_key          = method_key
          resource_key        = method.resource_key
          http_method         = method.http_method
          status_code         = resp_code
          selection_pattern   = resp.selection_pattern
          response_templates  = resp.response_templates
          response_parameters = resp.response_parameters
          content_handling    = resp.content_handling
        }
      ]
    ]) : entry.key => entry
  }

  # ─── Usage plan ↔ API key associations ──────────────────────────────────────
  usage_plan_key_pairs = {
    for pair in flatten([
      for plan_key, plan in var.usage_plans : [
        for api_key_name in plan.api_key_names : {
          unique_key   = "${plan_key}__${api_key_name}"
          plan_key     = plan_key
          api_key_name = api_key_name
        }
      ]
    ]) : pair.unique_key => pair
  }

  # ─── Effective stage name ─────────────────────────────────────────────────────
  # Falls back to var.environment when stage_name is not explicitly set,
  # so the stage name mirrors the deployment environment by default.
  effective_stage_name = coalesce(var.stage_name, var.environment)

  # ─── Access log destination ARN ─────────────────────────────────────────────
  # Uses an external ARN when supplied via access_log_settings.destination_arn;
  # otherwise resolves to the module-managed log group (always created).
  access_log_destination_arn = (
    var.access_log_settings != null && var.access_log_settings.destination_arn != null
    ? var.access_log_settings.destination_arn
    : try(aws_cloudwatch_log_group.access_logs[0].arn, null)
  )
}

################################################################################
# REST API
################################################################################

resource "aws_api_gateway_rest_api" "api" {
  name        = var.api_name
  description = var.description

  # Optional: import API definition from an OpenAPI / Swagger spec.
  # When api_body is set, leave var.resources and var.methods empty — the spec
  # owns all resource and method definitions.
  body = var.api_body

  # API key lookup source: "HEADER" (x-api-key) or "AUTHORIZER" (from a Lambda
  # authorizer's context). Defaults to HEADER for standard key-based auth.
  api_key_source = var.api_key_source

  # Compress responses larger than this byte threshold (0 = disable compression).
  minimum_compression_size = var.minimum_compression_size

  # Binary MIME types whose request/response bodies should be treated as raw bytes
  # (base64-encoded). Common values: "image/png", "application/pdf", "*/*".
  binary_media_types = var.binary_media_types

  # Set to true when using a custom domain to hide the default execute-api URL.
  disable_execute_api_endpoint = var.disable_execute_api_endpoint

  endpoint_configuration {
    types            = var.endpoint_configuration.types
    vpc_endpoint_ids = length(var.endpoint_configuration.vpc_endpoint_ids) > 0 ? var.endpoint_configuration.vpc_endpoint_ids : null
  }

  tags = var.tags

  lifecycle {
    create_before_destroy = true
  }
}

################################################################################
# API RESOURCES — path segments, up to 3 levels of nesting
#
# Supported nesting hierarchy:
#   Root (/)
#   └─ Level 1  (e.g. /v1, /health)                  parent_key = null
#      └─ Level 2  (e.g. /v1/users)                  parent_key = <level-1 key>
#         └─ Level 3  (e.g. /v1/users/{id})          parent_key = <level-2 key>
#
# For paths deeper than 3 levels, pass the pre-existing resource IDs via
# method.resource_id (using the outputs from another module call or data source).
################################################################################

resource "aws_api_gateway_resource" "level1" {
  for_each    = { for k, v in var.resources : k => v if v.parent_key == null }
  rest_api_id = aws_api_gateway_rest_api.api.id
  parent_id   = aws_api_gateway_rest_api.api.root_resource_id
  path_part   = each.value.path_part
}

resource "aws_api_gateway_resource" "level2" {
  for_each    = { for k, v in var.resources : k => v if contains(local.level2_resource_keys, k) }
  rest_api_id = aws_api_gateway_rest_api.api.id
  parent_id   = aws_api_gateway_resource.level1[each.value.parent_key].id
  path_part   = each.value.path_part
}

resource "aws_api_gateway_resource" "level3" {
  for_each    = { for k, v in var.resources : k => v if contains(local.level3_resource_keys, k) }
  rest_api_id = aws_api_gateway_rest_api.api.id
  parent_id   = aws_api_gateway_resource.level2[each.value.parent_key].id
  path_part   = each.value.path_part
}

################################################################################
# REQUEST VALIDATORS
################################################################################

resource "aws_api_gateway_request_validator" "validators" {
  for_each    = var.request_validators
  rest_api_id = aws_api_gateway_rest_api.api.id

  name                        = each.value.name
  validate_request_body       = each.value.validate_request_body
  validate_request_parameters = each.value.validate_request_parameters
}

################################################################################
# AUTHORIZERS — Lambda (TOKEN / REQUEST) and Cognito User Pool
################################################################################

resource "aws_api_gateway_authorizer" "authorizers" {
  for_each    = var.authorizers
  rest_api_id = aws_api_gateway_rest_api.api.id

  name = each.value.name
  type = each.value.type # TOKEN | REQUEST | COGNITO_USER_POOLS

  # Lambda authorizer settings
  authorizer_uri                   = each.value.authorizer_uri
  authorizer_credentials           = each.value.authorizer_credentials
  authorizer_result_ttl_in_seconds = each.value.authorizer_result_ttl_in_seconds
  identity_source                  = each.value.identity_source
  identity_validation_expression   = each.value.identity_validation_expression

  # Cognito user pool authorizer
  provider_arns = each.value.provider_arns
}

################################################################################
# MODELS — request / response body schemas (JSON Schema draft 4)
################################################################################

resource "aws_api_gateway_model" "models" {
  for_each    = var.models
  rest_api_id = aws_api_gateway_rest_api.api.id

  name         = each.value.name
  description  = each.value.description
  content_type = each.value.content_type
  schema       = each.value.schema
}

################################################################################
# VPC LINKS — private integrations via Network Load Balancer
################################################################################

resource "aws_api_gateway_vpc_link" "vpc_links" {
  for_each = var.vpc_links

  name        = each.value.name
  description = each.value.description
  target_arns = each.value.target_arns # NLB ARN(s)

  tags = var.tags
}

################################################################################
# METHODS
#
# resource_key = "ROOT" targets the API root resource directly  (/).
# resource_key = <any key from var.resources> targets that path segment.
#
# authorizer_id and request_validator_id reference keys from var.authorizers
# and var.request_validators respectively — the module resolves the IDs.
################################################################################

resource "aws_api_gateway_method" "methods" {
  for_each    = var.methods
  rest_api_id = aws_api_gateway_rest_api.api.id

  # Resolve resource ID: "ROOT" → root resource, otherwise look up in the merged map
  resource_id = (
    each.value.resource_key == "ROOT"
    ? aws_api_gateway_rest_api.api.root_resource_id
    : local.all_resource_ids[each.value.resource_key]
  )

  http_method = each.value.http_method

  # Authorization: NONE | AWS_IAM | COGNITO_USER_POOLS | CUSTOM
  authorization        = each.value.authorization
  authorizer_id        = each.value.authorizer_id != null ? aws_api_gateway_authorizer.authorizers[each.value.authorizer_id].id : null
  authorization_scopes = each.value.authorization_scopes

  api_key_required = each.value.api_key_required

  # Query-string and header parameter requirements.
  # Keys: "method.request.querystring.name" or "method.request.header.name"
  # Value: true = required, false = optional
  request_parameters = each.value.request_parameters

  # Reference a request_validator key; null skips validation
  request_validator_id = (
    each.value.request_validator_id != null
    ? aws_api_gateway_request_validator.validators[each.value.request_validator_id].id
    : null
  )

  # Map of content-type → model name for request body validation
  request_models = each.value.request_models

  # Human-readable operation name shown in API GW console and Swagger exports.
  # Useful for tagging routes (e.g. "ListUsers", "CreateOrder").
  operation_name = each.value.operation_name


}

################################################################################
# INTEGRATIONS
#
# Integration types:
#   AWS_PROXY   — Lambda proxy (recommended for Lambda backends)
#   HTTP_PROXY  — HTTP pass-through (no response mapping required)
#   AWS         — AWS service action (requires method/integration responses)
#   HTTP        — HTTP with explicit response mapping
#   MOCK        — Returns a static response (no backend call)
#
# For MOCK integrations, integration_http_method is ignored (set to null).
# For AWS_PROXY (Lambda), the uri must be the Lambda function's invoke_arn.
################################################################################

resource "aws_api_gateway_integration" "integrations" {
  for_each    = var.methods
  rest_api_id = aws_api_gateway_rest_api.api.id

  resource_id = aws_api_gateway_method.methods[each.key].resource_id
  http_method = aws_api_gateway_method.methods[each.key].http_method

  type = each.value.integration.type

  # Backend URI:
  #   AWS_PROXY / AWS  → Lambda invoke ARN  (arn:aws:apigateway:…:lambda:path/…/invocations)
  #   HTTP / HTTP_PROXY → full https:// backend URL
  #   MOCK            → null
  uri = each.value.integration.uri

  # HTTP method used when calling the backend (always POST for Lambda invoctions)
  # MOCK integrations must leave this null.
  integration_http_method = each.value.integration.type == "MOCK" ? null : each.value.integration.http_method

  # IAM role ARN — grants API GW permission to invoke the backend (alternative to
  # resource-based Lambda permissions when using IAM_ROLE credentials strategy)
  credentials = each.value.integration.credentials

  # Velocity templates for transforming request body before forwarding to backend
  # Only applicable for AWS and HTTP (non-proxy) integration types.
  request_templates = each.value.integration.request_templates

  # Map integration request parameters from method request:
  # "integration.request.header.X-Foo" = "method.request.header.X-Foo"
  request_parameters = each.value.integration.request_parameters

  # WHEN_NO_MATCH | WHEN_NO_TEMPLATES | NEVER
  passthrough_behavior = each.value.integration.passthrough_behavior

  # CONVERT_TO_BINARY | CONVERT_TO_TEXT (for binary payloads)
  content_handling = each.value.integration.content_handling

  # Integration timeout in milliseconds. Max: 29000 (29 s) for synchronous calls.
  timeout_milliseconds = each.value.integration.timeout_milliseconds

  # INTERNET (default) or VPC_LINK (for private integrations via NLB)
  connection_type = each.value.integration.connection_type

  # Resolve VPC Link ID: key from var.vpc_links takes precedence over a literal ID
  connection_id = (
    each.value.integration.vpc_link_key != null
    ? aws_api_gateway_vpc_link.vpc_links[each.value.integration.vpc_link_key].id
    : each.value.integration.connection_id
  )

  cache_key_parameters = each.value.integration.cache_key_parameters
  cache_namespace      = each.value.integration.cache_namespace

  depends_on = [aws_api_gateway_method.methods]
}

################################################################################
# METHOD RESPONSES
#
# Define the HTTP status codes and response headers/models the API can return.
# Responses map key format:  "<method_key>__<status_code>"  (double underscore)
#
# For AWS_PROXY and HTTP_PROXY integrations, a single "200" response is
# typically sufficient — the backend controls the actual status code.
# For non-proxy integrations, add entries for each status code you map.
################################################################################

resource "aws_api_gateway_method_response" "responses" {
  for_each    = local.method_responses
  rest_api_id = aws_api_gateway_rest_api.api.id

  resource_id = aws_api_gateway_method.methods[each.value.method_key].resource_id
  http_method = aws_api_gateway_method.methods[each.value.method_key].http_method
  status_code = each.value.status_code

  # Map of content-type → model name (e.g. {"application/json" = "Empty"})
  response_models = each.value.response_models

  # Allowed response headers; true = required, false = optional
  # Keys: "method.response.header.Access-Control-Allow-Origin"
  response_parameters = each.value.response_parameters

  depends_on = [aws_api_gateway_method.methods]
}

################################################################################
# INTEGRATION RESPONSES
#
# Maps backend responses to method responses using selection patterns (regex).
# Leave integration_responses = {} for AWS_PROXY and HTTP_PROXY integrations —
# those pass-through backend responses directly without mapping.
#
# For non-proxy integrations (AWS, HTTP), you must configure an integration
# response for each status code to transform and forward the backend's output.
################################################################################

resource "aws_api_gateway_integration_response" "integration_responses" {
  for_each    = local.integration_responses
  rest_api_id = aws_api_gateway_rest_api.api.id

  resource_id = aws_api_gateway_method.methods[each.value.method_key].resource_id
  http_method = aws_api_gateway_method.methods[each.value.method_key].http_method
  status_code = each.value.status_code

  # Regex matched against the backend status code or Lambda error message.
  # Leave null for the default (catch-all) integration response.
  selection_pattern = each.value.selection_pattern

  # Velocity templates to transform backend response body per content-type
  response_templates = each.value.response_templates

  # Map backend response headers to method response headers:
  # "method.response.header.X-Custom" = "integration.response.header.x-amz-custom"
  response_parameters = each.value.response_parameters

  # CONVERT_TO_BINARY | CONVERT_TO_TEXT
  content_handling = each.value.content_handling

  depends_on = [
    aws_api_gateway_method.methods,
    aws_api_gateway_integration.integrations,
    aws_api_gateway_method_response.responses,
  ]
}

################################################################################
# GATEWAY RESPONSES — custom responses for API-level errors (4xx/5xx)
#
# Common use cases:
#   • DEFAULT_4XX / DEFAULT_5XX  — add CORS headers to all error responses
#   • UNAUTHORIZED               — customize 401 error format
#   • MISSING_AUTHENTICATION_TOKEN — 403 when auth header is absent
#
# response_parameters keys use "gatewayresponse.header.<name>" format.
################################################################################

resource "aws_api_gateway_gateway_response" "responses" {
  for_each    = var.gateway_responses
  rest_api_id = aws_api_gateway_rest_api.api.id

  response_type = each.value.response_type

  # null uses the default HTTP status code for the response type
  status_code = each.value.status_code

  # Velocity templates keyed by content-type
  response_templates = each.value.response_templates

  # Override response headers, e.g.:
  # "gatewayresponse.header.Access-Control-Allow-Origin" = "'*'"
  response_parameters = each.value.response_parameters
}

################################################################################
# DEPLOYMENT
#
# A NEW DEPLOYMENT is automatically triggered whenever any of the following
# inputs change (via sha1 content hash):
#   • var.resources       – path segment definitions
#   • var.methods         – method, integration, response definitions
#   • var.gateway_responses – custom gateway error responses
#   • var.api_body        – OpenAPI / Swagger spec body
#   • var.request_validators
#   • var.authorizers     – authorizer definitions
#
# create_before_destroy ensures zero-downtime re-deployment:
# the new deployment is staged before the stage pointer is updated.
################################################################################

resource "aws_api_gateway_deployment" "deployment" {
  rest_api_id = aws_api_gateway_rest_api.api.id

  triggers = {
    redeployment = sha1(jsonencode({
      resources         = var.resources
      methods           = var.methods
      gateway_responses = var.gateway_responses
      api_body          = var.api_body
      validators        = var.request_validators
      authorizers_cfg   = var.authorizers
    }))
  }

  lifecycle {
    create_before_destroy = true
  }

  depends_on = [
    aws_api_gateway_method.methods,
    aws_api_gateway_integration.integrations,
    aws_api_gateway_method_response.responses,
    aws_api_gateway_integration_response.integration_responses,
    aws_api_gateway_gateway_response.responses,
  ]
}

################################################################################
# CLOUDWATCH LOG GROUP — access logs
#
# Created only when var.access_log_settings is set AND no destination_arn is
# supplied (i.e. the module manages the log group rather than the caller).
################################################################################

resource "aws_cloudwatch_log_group" "access_logs" {
  # Always created unless the caller supplies an explicit external destination ARN.
  # Supplying access_log_settings.destination_arn = "<existing ARN>" skips creation.
  count = (
    var.access_log_settings == null || var.access_log_settings.destination_arn == null
    ? 1 : 0
  )

  name = "/aws/apigateway/${var.api_name}/${local.effective_stage_name}"

  # access_log_settings.retention_in_days takes precedence when explicitly set;
  # otherwise fall back to the standalone access_log_retention_in_days variable.
  retention_in_days = (
    var.access_log_settings != null
    ? var.access_log_settings.retention_in_days
    : var.access_log_retention_in_days
  )
  kms_key_id = var.log_kms_key_id

  tags = var.tags
}

################################################################################
# CLOUDWATCH LOG GROUP — execution logs
#
# API Gateway writes execution logs to a fixed-name group:
#   API-Gateway-Execution-Logs_{rest-api-id}/{stage-name}
#
# Pre-creating this group lets Terraform control retention and encryption
# before the stage is deployed. Execution logging is activated by the
# aws_api_gateway_method_settings.default_settings resource below.
################################################################################

resource "aws_cloudwatch_log_group" "execution_logs" {
  # Always created. Pre-creating this group lets Terraform own retention and
  # KMS encryption before the stage is deployed, preventing API Gateway from
  # auto-creating an unmanaged group with unlimited retention.
  name              = "API-Gateway-Execution-Logs_${aws_api_gateway_rest_api.api.id}/${local.effective_stage_name}"
  retention_in_days = var.execution_log_retention_in_days
  kms_key_id        = var.log_kms_key_id

  tags = var.tags
}

################################################################################
# IAM — API Gateway CloudWatch Logs execution role
#
# Delegates to the shared ../iam module, consistent with the lambda module pattern.
# Set create_cloudwatch_role = true in ONE module call per AWS account/region.
################################################################################

data "aws_iam_policy_document" "apigw_assume_role" {
  count = var.create_cloudwatch_role ? 1 : 0

  statement {
    sid     = "APIGatewayCloudWatchAssumeRole"
    effect  = "Allow"
    actions = ["sts:AssumeRole"]

    principals {
      type        = "Service"
      identifiers = ["apigateway.amazonaws.com"]
    }
  }
}

module "cloudwatch_role" {
  source = "../iam"
  count  = var.create_cloudwatch_role ? 1 : 0

  role_name          = coalesce(var.cloudwatch_role_name, "${var.api_name}-apigw-cloudwatch-role")
  description        = "Allows API Gateway to push logs to CloudWatch for ${var.api_name}"
  path               = var.iam_role_path
  assume_role_policy = data.aws_iam_policy_document.apigw_assume_role[0].json

  # AWS managed policy grants CreateLogGroup, CreateLogStream, PutLogEvents,
  # DescribeLogGroups, DescribeLogStreams, GetLogEvents, FilterLogEvents
  aws_managed_policy_arns = [
    "arn:aws:iam::aws:policy/service-role/AmazonAPIGatewayPushToCloudWatchLogs",
  ]

  tags = var.tags
}

# Account-level setting: tells API Gateway which IAM role to use for CloudWatch logging.
# This is a singleton resource per account/region — manage it in ONE module call.
resource "aws_api_gateway_account" "account" {
  count = var.create_cloudwatch_role || var.cloudwatch_role_arn != null ? 1 : 0

  cloudwatch_role_arn = (
    var.create_cloudwatch_role
    ? module.cloudwatch_role[0].role_arn
    : var.cloudwatch_role_arn
  )
}

################################################################################
# STAGE
################################################################################

resource "aws_api_gateway_stage" "stage" {
  deployment_id = aws_api_gateway_deployment.deployment.id
  rest_api_id   = aws_api_gateway_rest_api.api.id
  stage_name    = local.effective_stage_name
  description   = var.stage_description

  # Enable AWS X-Ray tracing for each request
  xray_tracing_enabled = var.xray_tracing_enabled

  # Access log destination (CloudWatch Logs or Kinesis Firehose ARN) with
  # structured log format that captures request ID, IP, method, path, status,
  # error details, and auth context — overridable via var.access_log_format.
  dynamic "access_log_settings" {
    for_each = local.access_log_destination_arn != null ? [local.access_log_destination_arn] : []
    content {
      destination_arn = access_log_settings.value
      format          = var.access_log_format
    }
  }

  # Response cache cluster (must be enabled to use caching in method settings)
  cache_cluster_enabled = var.cache_cluster_enabled
  cache_cluster_size    = var.cache_cluster_enabled ? var.cache_cluster_size : null

  # Mutual TLS client certificate (optional)
  client_certificate_id = var.client_certificate_id

  # Stage variables available to integrations as ${stageVariables.name}
  variables = var.stage_variables

  tags = var.tags

  lifecycle {
    precondition {
      condition     = var.create_cloudwatch_role || var.cloudwatch_role_arn != null
      error_message = "CloudWatch logging is always enabled. Set create_cloudwatch_role = true (once per AWS account/region) OR supply cloudwatch_role_arn pointing to an existing role. Without a CloudWatch Logs IAM role API Gateway cannot write logs or metrics."
    }
  }

  depends_on = [
    aws_api_gateway_account.account,
    aws_cloudwatch_log_group.access_logs,
    aws_cloudwatch_log_group.execution_logs,
  ]
}

################################################################################
# DEFAULT METHOD SETTINGS — catch-all */* (metrics + execution logging always on)
#
# Always applied unless the caller supplies their own "*/*" entry in var.method_settings.
# Turns on CloudWatch metrics and execution log writes for all methods/resources
# on this stage without requiring any caller configuration.
#
# Conflict prevention: this resource is skipped when the caller already defines
# "*/*" in var.method_settings, so both resources never target the same path.
# Override: add per-method entries in var.method_settings to override specific
# routes (method-level settings override the catch-all */* default).
################################################################################

resource "aws_api_gateway_method_settings" "default_settings" {
  # Always applied unless the caller supplies their own "*/*" entry in var.method_settings.
  # That entry takes full control; this default is then skipped to avoid a conflict.
  count = !contains(keys(var.method_settings), "*/*") ? 1 : 0

  rest_api_id = aws_api_gateway_rest_api.api.id
  stage_name  = aws_api_gateway_stage.stage.stage_name
  method_path = "*/*"

  settings {
    # Metrics and execution logging are always on by default.
    metrics_enabled    = true
    logging_level      = var.execution_logging_level # OFF | ERROR | INFO
    data_trace_enabled = var.execution_data_trace_enabled

    # Throttle and cache left at -1/false so they inherit stage-level defaults.
    throttling_burst_limit = -1
    throttling_rate_limit  = -1
    caching_enabled        = false
  }

  depends_on = [
    aws_api_gateway_stage.stage,
    aws_cloudwatch_log_group.execution_logs,
  ]
}

################################################################################
# METHOD SETTINGS — per-method throttling, logging, and cache configuration
#
# method_path key format: "{resource_path}/{HTTP_METHOD}"
#   "*/*"            → applies to ALL methods on ALL resources (catch-all)
#   "v1/users/GET"   → only GET /v1/users
#   "~1v1~1users/GET"→ URL-encoded path with slashes (API GW escaping convention)
#
# Note: caching_enabled only takes effect when var.cache_cluster_enabled = true.
# Note: data_trace_enabled logs full request/response — avoid in production to
#       prevent accidental logging of sensitive payloads.
# Note: if you define "*/*" here, the default_settings resource is automatically
#       suppressed (skipped) to avoid a conflict.
################################################################################

resource "aws_api_gateway_method_settings" "settings" {
  for_each    = var.method_settings
  rest_api_id = aws_api_gateway_rest_api.api.id
  stage_name  = aws_api_gateway_stage.stage.stage_name
  method_path = each.key

  settings {
    throttling_burst_limit = each.value.throttling_burst_limit
    throttling_rate_limit  = each.value.throttling_rate_limit

    metrics_enabled    = each.value.metrics_enabled
    logging_level      = each.value.logging_level # OFF | ERROR | INFO
    data_trace_enabled = each.value.data_trace_enabled

    caching_enabled      = each.value.caching_enabled
    cache_ttl_in_seconds = each.value.cache_ttl_in_seconds
    cache_data_encrypted = each.value.cache_data_encrypted

    #require_authorization_for_cache_invalidation = each.value.require_authorization_for_cache_invalidation
    unauthorized_cache_control_header_strategy   = each.value.unauthorized_cache_control_header_strategy
  }
}

################################################################################
# API KEYS
#
# Pass value = null to let API Gateway auto-generate a secure key.
# Pass an explicit value only for migration scenarios where the key must match
# an existing value — store it in AWS Secrets Manager, not in plain tfvars.
################################################################################

resource "aws_api_gateway_api_key" "keys" {
  for_each = var.api_keys

  name        = each.value.name
  description = each.value.description
  enabled     = each.value.enabled
  value       = each.value.value # null → auto-generated by API GW

  tags = var.tags
}

################################################################################
# USAGE PLANS
#
# Each plan is linked to this API's stage automatically. Use api_key_names to
# associate keys created above. Use per_method_throttle for fine-grained
# per-endpoint overrides within the plan.
#
# per_method_throttle key format: "{resource_path}/{HTTP_METHOD}"
#   e.g. "v1/users/GET", "*/*"
################################################################################

resource "aws_api_gateway_usage_plan" "plans" {
  for_each = var.usage_plans

  name        = each.value.name
  description = each.value.description

  # Associate this plan with the managed stage (always this module's stage)
  api_stages {
    api_id = aws_api_gateway_rest_api.api.id
    stage  = aws_api_gateway_stage.stage.stage_name

    # Optional per-method throttle overrides within this usage plan
    dynamic "throttle" {
      for_each = each.value.per_method_throttle
      content {
        path        = throttle.key
        burst_limit = throttle.value.burst_limit
        rate_limit  = throttle.value.rate_limit
      }
    }
  }

  # Request per period quota (e.g. 10000 requests per day)
  dynamic "quota_settings" {
    for_each = each.value.quota != null ? [each.value.quota] : []
    content {
      limit  = quota_settings.value.limit
      offset = quota_settings.value.offset
      period = quota_settings.value.period # DAY | WEEK | MONTH
    }
  }

  # Default throttle for all methods in this plan (overridden by per_method_throttle)
  dynamic "throttle_settings" {
    for_each = each.value.throttle != null ? [each.value.throttle] : []
    content {
      burst_limit = throttle_settings.value.burst_limit
      rate_limit  = throttle_settings.value.rate_limit
    }
  }

  tags = var.tags

  depends_on = [aws_api_gateway_stage.stage]
}

################################################################################
# USAGE PLAN KEY ASSOCIATIONS — link API keys to usage plans
################################################################################

resource "aws_api_gateway_usage_plan_key" "plan_keys" {
  for_each = local.usage_plan_key_pairs

  key_id        = aws_api_gateway_api_key.keys[each.value.api_key_name].id
  key_type      = "API_KEY"
  usage_plan_id = aws_api_gateway_usage_plan.plans[each.value.plan_key].id
}

################################################################################
# LAMBDA INVOKE PERMISSIONS
#
# Creates aws_lambda_permission resources allowing this API Gateway STAGE to
# invoke each specified Lambda function.
#
# WHY HERE (not in the Lambda module):
#   The `source_arn` must include the stage execution ARN
#   (arn:aws:execute-api:{region}:{account}:{api-id}/{stage}/*/*),
#   which is only available after `aws_api_gateway_stage` is created.
#   Creating permissions here avoids requiring the caller to wire the ARN back
#   into a separate Lambda module call.
#
# SCOPING:
#   By default, source_arn is scoped to all methods on this stage (/{stage}/*/*)
#   For tighter security, supply a method-specific ARN via the source_arn field:
#     source_arn = "${module.api_gateway.stage_execution_arn}/GET/v1/users"
################################################################################

resource "aws_lambda_permission" "invoke_permissions" {
  for_each = var.lambda_invoke_permissions

  statement_id  = coalesce(each.value.statement_id, "allow-apigw-${replace(each.key, "_", "-")}")
  action        = "lambda:InvokeFunction"
  function_name = each.value.function_name
  qualifier     = each.value.qualifier
  principal     = "apigateway.amazonaws.com"

  # Scope to this stage's execution ARN; override per-method for least-privilege
  source_arn = coalesce(
    each.value.source_arn,
    "${aws_api_gateway_rest_api.api.execution_arn}/*/*"
  )

}

################################################################################
# CUSTOM DOMAIN NAME (optional)
#
# endpoint_type = "REGIONAL" → uses regional_certificate_arn (ACM in same region)
# endpoint_type = "EDGE"     → uses certificate_arn (ACM in us-east-1 required)
################################################################################

resource "aws_api_gateway_domain_name" "custom_domain" {
  count = var.custom_domain != null ? 1 : 0

  domain_name     = var.custom_domain.domain_name
  security_policy = var.custom_domain.security_policy # TLS_1_2 (recommended)

  # REGIONAL certificate (ACM cert in the same region as the API)
  regional_certificate_arn = (
    var.custom_domain.endpoint_type == "REGIONAL"
    ? var.custom_domain.certificate_arn
    : null
  )

  # EDGE certificate (ACM cert must be in us-east-1 for CloudFront distribution)
  certificate_arn = (
    var.custom_domain.endpoint_type == "EDGE"
    ? var.custom_domain.certificate_arn
    : null
  )

  endpoint_configuration {
    types = [var.custom_domain.endpoint_type]
  }

  # ACM cert for proving domain ownership (required for some mutual-TLS setups)
  ownership_verification_certificate_arn = var.custom_domain.ownership_verification_certificate_arn

  tags = var.tags
}

# Maps the API stage to the custom domain name
resource "aws_api_gateway_base_path_mapping" "mapping" {
  count = var.custom_domain != null ? 1 : 0

  api_id      = aws_api_gateway_rest_api.api.id
  stage_name  = aws_api_gateway_stage.stage.stage_name
  domain_name = aws_api_gateway_domain_name.custom_domain[0].domain_name

  # Base path for this API under the domain; "" = root (no prefix)
  base_path = var.custom_domain.base_path

  depends_on = [aws_api_gateway_domain_name.custom_domain]
}
