################################################################################
# STATE MACHINE
################################################################################

output "state_machine_arn" {
  description = "ARN of the Step Functions state machine."
  value       = aws_sfn_state_machine.state_machine.arn
}

output "state_machine_id" {
  description = "ID of the Step Functions state machine."
  value       = aws_sfn_state_machine.state_machine.id
}

output "state_machine_name" {
  description = "Name of the Step Functions state machine."
  value       = aws_sfn_state_machine.state_machine.name
}

output "state_machine_status" {
  description = "Current status of the state machine (ACTIVE or DELETING)."
  value       = aws_sfn_state_machine.state_machine.status
}

output "state_machine_creation_date" {
  description = "Date the state machine was created."
  value       = aws_sfn_state_machine.state_machine.creation_date
}

output "state_machine_version_arn" {
  description = "ARN of the published version. Null when publish = false."
  value       = aws_sfn_state_machine.state_machine.state_machine_version_arn
}

################################################################################
# IAM — EXECUTION ROLE
################################################################################

output "execution_role_arn" {
  description = "ARN of the IAM execution role assumed by the state machine."
  value       = module.sfn_execution_role.role_arn
}

output "execution_role_name" {
  description = "Name of the IAM execution role."
  value       = module.sfn_execution_role.role_name
}

################################################################################
# CLOUDWATCH LOGS
################################################################################

output "log_group_arn" {
  description = "ARN of the CloudWatch Logs log group for execution logs."
  value       = aws_cloudwatch_log_group.state_machine_logs.arn
}

output "log_group_name" {
  description = "Name of the CloudWatch Logs log group for execution logs."
  value       = aws_cloudwatch_log_group.state_machine_logs.name
}
