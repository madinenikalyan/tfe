################################################################################
# AWS ACCOUNT & REGION — passed from root module
################################################################################

variable "account_id" {
  description = <<-EOT
    AWS account ID. Passed from the root module's data.aws_caller_identity.current.account_id.
    Used in IAM trust policy conditions.
  EOT
  type        = string

  validation {
    condition     = can(regex("^[0-9]{12}$", var.account_id))
    error_message = "'account_id' must be a 12-digit AWS account ID."
  }
}

variable "aws_region" {
  description = <<-EOT
    AWS region name (e.g. "us-east-1"). Passed from the root module's data.aws_region.current.name.
  EOT
  type        = string

  validation {
    condition     = can(regex("^[a-z]{2}-[a-z]+-[0-9]{1}$", var.aws_region))
    error_message = "'aws_region' must be a valid AWS region name (e.g. 'us-east-1')."
  }
}

variable "aws_partition" {
  description = "AWS partition for ARN construction (e.g. 'aws', 'aws-cn', 'aws-us-gov')."
  type        = string
  default     = "aws"
}

################################################################################
# STATE MACHINE IDENTITY
################################################################################

variable "name" {
  description = "Name of the Step Functions state machine. Must be unique within the account and region."
  type        = string

  validation {
    condition     = length(var.name) >= 1 && length(var.name) <= 80
    error_message = "'name' must be between 1 and 80 characters."
  }
}

variable "definition" {
  description = "JSON-encoded Amazon States Language (ASL) definition for the state machine."
  type        = string
}

variable "type" {
  description = <<-EOT
    Type of state machine workflow.
    STANDARD  — long-running (up to 1 year), exactly-once execution, billed per state transition.
    EXPRESS   — high-volume, short-duration (up to 5 min), at-least-once, billed per execution and duration.
  EOT
  type        = string
  default     = "STANDARD"

  validation {
    condition     = contains(["STANDARD", "EXPRESS"], var.type)
    error_message = "'type' must be either 'STANDARD' or 'EXPRESS'."
  }
}

variable "publish" {
  description = "Whether to publish a version of the state machine during creation. Enables versioning and aliases."
  type        = bool
  default     = false
}

################################################################################
# ENCRYPTION
################################################################################

variable "kms_key_arn" {
  description = <<-EOT
    ARN of a KMS CMK to encrypt activity inputs/outputs at rest.
    When null, AWS-owned encryption is used (default).
    Pass the ARN from a secrets-manager or standalone KMS module.
  EOT
  type        = string
  default     = null
}

variable "kms_data_key_reuse_period_in_seconds" {
  description = <<-EOT
    Duration (in seconds) for which the data encryption key is reused before
    a new one is generated. Valid range: 60–900. Only applies when kms_key_arn is set.
  EOT
  type        = number
  default     = 300

  validation {
    condition     = var.kms_data_key_reuse_period_in_seconds >= 60 && var.kms_data_key_reuse_period_in_seconds <= 900
    error_message = "'kms_data_key_reuse_period_in_seconds' must be between 60 and 900."
  }
}

################################################################################
# LOGGING
################################################################################

variable "log_retention_in_days" {
  description = <<-EOT
    Number of days to retain execution logs in CloudWatch Logs.
    Common values: 30, 60, 90, 180, 365, 0 (never expire).
  EOT
  type        = number
  default     = 90

  validation {
    condition = contains(
      [0, 1, 3, 5, 7, 14, 30, 60, 90, 120, 150, 180, 365, 400, 545, 731, 1096, 1827, 2192, 2557, 2922, 3288, 3653],
      var.log_retention_in_days
    )
    error_message = "'log_retention_in_days' must be a valid CloudWatch Logs retention value."
  }
}

variable "log_level" {
  description = <<-EOT
    Level of detail recorded in execution logs.
    ALL   — all event types logged (recommended for production).
    ERROR — only error events logged.
    FATAL — only fatal errors logged.
    OFF   — logging disabled (not recommended).
  EOT
  type        = string
  default     = "ALL"

  validation {
    condition     = contains(["ALL", "ERROR", "FATAL", "OFF"], var.log_level)
    error_message = "'log_level' must be one of: ALL, ERROR, FATAL, OFF."
  }
}

variable "include_execution_data" {
  description = "Whether to include input/output data in execution logs. Set false for sensitive payloads."
  type        = bool
  default     = true
}

################################################################################
# TRACING
################################################################################

variable "xray_tracing_enabled" {
  description = "Enable AWS X-Ray tracing for distributed trace correlation."
  type        = bool
  default     = true
}

################################################################################
# IAM — EXECUTION ROLE
################################################################################

variable "iam_role_path" {
  description = "IAM path for the execution role (e.g. '/' or '/sales-automation/')."
  type        = string
  default     = "/"

  validation {
    condition     = startswith(var.iam_role_path, "/") && endswith(var.iam_role_path, "/")
    error_message = "'iam_role_path' must begin and end with '/'."
  }
}

variable "inline_policies" {
  description = <<-EOT
    Map of inline IAM policy documents to attach to the execution role.
    Each key becomes the policy name; each value is the JSON policy document.
    Use for state machine-specific permissions (Lambda invoke, SQS send, etc.).
  EOT
  type        = map(string)
  default     = {}
}

variable "customer_managed_policies" {
  description = <<-EOT
    Map of customer-managed IAM policies to create and attach to the execution role.
    Each key is an arbitrary label; value contains name, description, path, and policy JSON.
  EOT
  type = map(object({
    name        = string
    description = optional(string, "")
    path        = optional(string, "/")
    policy      = string
    tags        = optional(map(string), {})
  }))
  default = {}
}

variable "customer_managed_policy_arns" {
  description = "List of pre-existing customer-managed IAM policy ARNs to attach to the execution role."
  type        = list(string)
  default     = []
}

variable "aws_managed_policy_arns" {
  description = "List of AWS-managed IAM policy ARNs to attach to the execution role."
  type        = list(string)
  default     = []
}

variable "permission_boundary_arn" {
  description = "ARN of an IAM managed policy to use as the permission boundary for the execution role."
  type        = string
  default     = null
}

################################################################################
# TAGS
################################################################################

variable "tags" {
  description = "Map of tags applied to all resources created by this module."
  type        = map(string)
  default     = {}
}
