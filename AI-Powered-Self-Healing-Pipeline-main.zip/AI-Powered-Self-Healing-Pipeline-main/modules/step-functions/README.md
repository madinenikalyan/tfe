# `modules/step-functions` — Production-Ready Step Functions Module

A Terraform module for provisioning an AWS Step Functions **state machine** with
a managed IAM execution role, CloudWatch Logs execution logging, X-Ray tracing,
and optional KMS encryption.

---

## Features

| Feature | Details |
|---|---|
| **Workflow types** | Standard (long-running, exactly-once) or Express (high-volume, short-duration) |
| **IAM execution role** | Auto-created via `../iam` with built-in CloudWatch Logs + X-Ray permissions |
| **CloudWatch logging** | Always enabled; configurable log level (ALL, ERROR, FATAL) and retention (default 90 days) |
| **X-Ray tracing** | Enabled by default for distributed trace correlation |
| **KMS encryption** | Optional CMK encryption for activity inputs/outputs |
| **Versioning** | Optional publish flag for version/alias support |
| **IAM flexibility** | Caller passes inline, customer-managed, or AWS-managed policies for service permissions |

---

## Design Decisions

### IAM Execution Role via `../iam`

The execution role is delegated to the `../iam` module following the same pattern as
aurora, api-gateway, and lambda modules. The `states.amazonaws.com` service principal
assumes the role with an `aws:SourceAccount` condition for confused-deputy protection.

Base permissions (CloudWatch Logs write + X-Ray trace) are always included as an
inline policy. Callers add service-specific permissions (Lambda invoke, SQS send,
SNS publish, etc.) via `inline_policies`, `customer_managed_policies`, or
`aws_managed_policy_arns`.

### CloudWatch Logging Always On

Logging is unconditionally enabled. Express workflows require logging for any
production observability. Standard workflows benefit from execution event history
beyond the 90-day console retention. The log group is managed by this module.

### No Data Blocks

`account_id` and `aws_region` are passed as variables rather than looked up via
`data "aws_caller_identity"` / `data "aws_region"`. This avoids duplicate data-source
calls when the root module already has them.

---

## Usage

### Minimal — Standard workflow

```hcl
module "data_pipeline" {
  source = "./modules/step-functions"

  name       = "sales-automation-data-pipeline"
  definition = file("${path.module}/config/data-pipeline.asl.json")

  account_id = data.aws_caller_identity.current.account_id
  aws_region = data.aws_region.current.name

  tags = local.common_tags
}
```

### With Lambda invoke permissions

```hcl
module "order_workflow" {
  source = "./modules/step-functions"

  name       = "order-processing-workflow"
  definition = file("${path.module}/config/order-workflow.asl.json")

  inline_policies = {
    lambda_invoke = data.aws_iam_policy_document.sfn_lambda_invoke.json
  }

  account_id = data.aws_caller_identity.current.account_id
  aws_region = data.aws_region.current.name

  tags = local.common_tags
}
```

### Express workflow with KMS encryption

```hcl
module "high_volume_processor" {
  source = "./modules/step-functions"

  name       = "event-processor"
  definition = file("${path.module}/config/event-processor.asl.json")
  type       = "EXPRESS"

  kms_key_arn          = module.shared_kms.key_arn
  log_retention_in_days = 30

  account_id = data.aws_caller_identity.current.account_id
  aws_region = data.aws_region.current.name

  tags = local.common_tags
}
```

---

## Inputs

| Variable | Type | Default | Description |
|---|---|---|---|
| `account_id` | `string` | required | AWS account ID (12-digit) |
| `aws_region` | `string` | required | AWS region name (e.g. `us-east-1`) |
| `aws_partition` | `string` | `"aws"` | AWS partition for ARN construction |
| `name` | `string` | required | State machine name (1–80 chars) |
| `definition` | `string` | required | JSON-encoded ASL definition |
| `type` | `string` | `"STANDARD"` | Workflow type: `STANDARD` or `EXPRESS` |
| `publish` | `bool` | `false` | Publish a version on creation |
| `kms_key_arn` | `string` | `null` | KMS CMK ARN for encryption; null uses AWS-owned key |
| `kms_data_key_reuse_period_in_seconds` | `number` | `300` | Data key reuse period (60–900s) |
| `log_retention_in_days` | `number` | `90` | CloudWatch log retention |
| `log_level` | `string` | `"ALL"` | Log level: `ALL`, `ERROR`, `FATAL`, `OFF` |
| `include_execution_data` | `bool` | `true` | Include input/output data in logs |
| `xray_tracing_enabled` | `bool` | `true` | Enable X-Ray tracing |
| `iam_role_path` | `string` | `"/"` | IAM path for the execution role |
| `inline_policies` | `map(string)` | `{}` | Inline IAM policies for the execution role |
| `customer_managed_policies` | `map(object)` | `{}` | Customer-managed policies to create and attach |
| `customer_managed_policy_arns` | `list(string)` | `[]` | Pre-existing policy ARNs to attach |
| `aws_managed_policy_arns` | `list(string)` | `[]` | AWS-managed policy ARNs to attach |
| `permission_boundary_arn` | `string` | `null` | Permission boundary for the execution role |
| `tags` | `map(string)` | `{}` | Tags applied to all resources |

---

## Outputs

| Output | Description |
|---|---|
| `state_machine_arn` | ARN of the Step Functions state machine |
| `state_machine_id` | ID of the state machine |
| `state_machine_name` | Name of the state machine |
| `state_machine_status` | Status (ACTIVE or DELETING) |
| `state_machine_creation_date` | Creation date |
| `state_machine_version_arn` | Published version ARN (null when publish = false) |
| `execution_role_arn` | ARN of the IAM execution role |
| `execution_role_name` | Name of the IAM execution role |
| `log_group_arn` | ARN of the CloudWatch log group |
| `log_group_name` | Name of the CloudWatch log group |

---

## Notes

- **Execution role name**: Automatically set to `{name}-sfn-execution-role`.
- **Log group path**: `/aws/vendedlogs/states/{name}` — follows AWS recommended naming.
- **Sensitive payloads**: Set `include_execution_data = false` when the state machine
  processes sensitive data (PII, credentials) to avoid logging it.
- **Express workflow costs**: Express workflows are billed per execution and duration,
  not per state transition. Choose the right type based on workload characteristics.
