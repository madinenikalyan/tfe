################################################################################
# Step Functions — Production-Ready State Machine Module
#
# Creates a production-ready AWS Step Functions state machine with:
#   - Standard or Express workflow type (configurable)
#   - Dedicated IAM execution role via ../iam module with least-privilege
#     permissions for the services the state machine invokes
#   - CloudWatch Logs execution logging always enabled:
#       Standard  → ALL events at log level ALL
#       Express   → ALL events at log level ALL
#   - X-Ray tracing always enabled for distributed trace correlation
#   - KMS encryption for activity inputs/outputs (optional, via kms_key_arn)
#   - CloudWatch log group with configurable retention (default 90 days)
#   - Publish flag for versioning support (default false)
#
# DESIGN NOTE — IAM execution role:
#   Delegated to the ../iam module following the same pattern as aurora,
#   api-gateway, and lambda modules. The states.amazonaws.com service
#   principal assumes the role. Callers pass additional policies via
#   customer_managed_policies, inline_policies, or aws_managed_policy_arns
#   to grant the state machine permission to invoke Lambda, SNS, SQS, etc.
#
# DESIGN NOTE — CloudWatch logging:
#   Logging is unconditionally enabled. Express workflows require logging
#   for any production observability. Standard workflows benefit from
#   execution event history beyond the 90-day console retention.
#   The log group is managed by this module and encrypted if a KMS key
#   is supplied.
#
# DESIGN NOTE — Express vs Standard:
#   Express workflows (type = "EXPRESS") are for high-volume, short-duration
#   workloads (up to 5 minutes). Standard workflows (default) support
#   long-running orchestrations up to 1 year with exactly-once execution.
################################################################################

################################################################################
# LOCALS
################################################################################

locals {
  log_group_name = "/aws/vendedlogs/states/${var.name}"
}

################################################################################
# CLOUDWATCH LOG GROUP — execution logs destination
#
# Managed by this module so that retention, encryption, and lifecycle are
# controlled consistently. Log group is always created.
################################################################################

resource "aws_cloudwatch_log_group" "state_machine_logs" {
  name              = local.log_group_name
  retention_in_days = var.log_retention_in_days
  kms_key_id        = var.kms_key_arn

  tags = merge({ Name = "${var.name}-sfn-logs" }, var.tags)
}

################################################################################
# IAM EXECUTION ROLE
#
# The states.amazonaws.com service assumes this role during execution.
# Base permissions include CloudWatch Logs write access for execution logging
# and X-Ray write access for tracing. Additional permissions (Lambda invoke,
# SNS publish, SQS send, etc.) are supplied by the caller via policy variables.
################################################################################

data "aws_iam_policy_document" "sfn_assume_role" {
  statement {
    sid     = "StepFunctionsAssumeRole"
    effect  = "Allow"
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["states.amazonaws.com"]
    }
    condition {
      test     = "StringEquals"
      variable = "aws:SourceAccount"
      values   = [var.account_id]
    }
  }
}

data "aws_iam_policy_document" "sfn_logging_policy" {
  statement {
    sid    = "CloudWatchLogsWrite"
    effect = "Allow"
    actions = [
      "logs:CreateLogDelivery",
      "logs:DeleteLogDelivery",
      "logs:DescribeLogGroups",
      "logs:DescribeResourcePolicies",
      "logs:GetLogDelivery",
      "logs:ListLogDeliveries",
      "logs:PutResourcePolicy",
      "logs:UpdateLogDelivery",
    ]
    resources = ["*"]
  }

  statement {
    sid    = "CloudWatchLogGroupWrite"
    effect = "Allow"
    actions = [
      "logs:CreateLogStream",
      "logs:PutLogEvents",
    ]
    resources = ["${aws_cloudwatch_log_group.state_machine_logs.arn}:*"]
  }

  statement {
    sid    = "XRayTracing"
    effect = "Allow"
    actions = [
      "xray:PutTraceSegments",
      "xray:PutTelemetryRecords",
      "xray:GetSamplingRules",
      "xray:GetSamplingTargets",
    ]
    resources = ["*"]
  }
}

module "sfn_execution_role" {
  source = "../iam"

  role_name          = "${var.name}-sfn-execution-role"
  description        = "Execution role for Step Functions state machine: ${var.name}"
  path               = var.iam_role_path
  assume_role_policy = data.aws_iam_policy_document.sfn_assume_role.json

  inline_policies = merge(
    { sfn-logging = data.aws_iam_policy_document.sfn_logging_policy.json },
    var.inline_policies,
  )

  customer_managed_policies    = var.customer_managed_policies
  customer_managed_policy_arns = var.customer_managed_policy_arns
  aws_managed_policy_arns      = var.aws_managed_policy_arns
  permission_boundary_arn      = var.permission_boundary_arn

  tags = var.tags
}

################################################################################
# STEP FUNCTIONS STATE MACHINE
################################################################################

resource "aws_sfn_state_machine" "state_machine" {
  name       = var.name
  role_arn   = module.sfn_execution_role.role_arn
  type       = var.type
  definition = var.definition
  publish    = var.publish

  encryption_configuration {
    type       = var.kms_key_arn != null ? "CUSTOMER_MANAGED_KMS_KEY" : "AWS_OWNED_KEY"
    kms_key_id = var.kms_key_arn
    #kms_data_key_reuse_period_in_seconds = var.kms_key_arn != null ? var.kms_data_key_reuse_period_in_seconds : null
  }

  logging_configuration {
    log_destination        = "${aws_cloudwatch_log_group.state_machine_logs.arn}:*"
    include_execution_data = var.include_execution_data
    level                  = var.log_level
  }

  tracing_configuration {
    enabled = var.xray_tracing_enabled
  }

  tags = merge({ Name = var.name }, var.tags)

  depends_on = [module.sfn_execution_role]
}
