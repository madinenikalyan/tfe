################################################################################
# GLUE JOB
################################################################################

output "job_name" {
  description = "Name of the Glue job."
  value       = aws_glue_job.glue_etl_job.name
}

output "job_arn" {
  description = "ARN of the Glue job."
  value       = aws_glue_job.glue_etl_job.arn
}

output "job_id" {
  description = "ID of the Glue job."
  value       = aws_glue_job.glue_etl_job.id
}

################################################################################
# S3 LOCATIONS
################################################################################

output "job_source_dir" {
  description = "Normalised S3 prefix (job source directory) anchoring all job artefacts."
  value       = local.job_dir_clean
}

output "script_s3_uri" {
  description = "S3 URI of the uploaded Glue script."
  value       = local.script_s3_uri
}

output "script_s3_key" {
  description = "S3 key of the uploaded Glue script."
  value       = local.script_s3_key
}

output "temp_dir_s3_uri" {
  description = "S3 URI used as the Glue job TempDir (--TempDir argument)."
  value       = local.temp_dir_s3_uri
}

output "spark_logs_s3_uri" {
  description = "S3 URI used for Spark UI event logs (--spark-event-logs-path argument)."
  value       = local.spark_logs_s3_uri
}

output "packages_s3_keys" {
  description = "S3 keys of all files uploaded from packages/. Empty list when folder does not exist."
  value = [
    for f in sort(tolist(local.packages_files)) :
    "${local.job_dir_clean}/packages/${f}"
  ]
}

output "extra_py_files_s3_keys" {
  description = "S3 keys of all files uploaded from extra-py-files/. Empty list when folder does not exist."
  value = [
    for f in sort(tolist(local.extra_py_files)) :
    "${local.job_dir_clean}/extra-py-files/${f}"
  ]
}

output "extra_py_files_argument" {
  description = "The --extra-py-files argument value (comma-separated S3 URIs). Empty string when no qualifying files found."
  value       = local.extra_py_arg
}

################################################################################
# IAM ROLE
################################################################################

output "role_arn" {
  description = "ARN of the Glue execution role (module-created or caller-supplied)."
  value       = local.effective_role_arn
}

output "role_name" {
  description = "Name of the module-created Glue execution role. Null when create_iam_role = false."
  value       = var.create_iam_role ? module.glue_role[0].role_name : null
}

output "role_id" {
  description = "Unique ID of the module-created Glue execution role. Null when create_iam_role = false."
  value       = var.create_iam_role ? module.glue_role[0].role_id : null
}

################################################################################
# CLOUDWATCH LOG GROUP
################################################################################

output "log_group_name" {
  description = "Name of the CloudWatch log group for Glue job output."
  value       = aws_cloudwatch_log_group.glue_job_logs.name
}

output "log_group_arn" {
  description = "ARN of the CloudWatch log group."
  value       = aws_cloudwatch_log_group.glue_job_logs.arn
}

################################################################################
# SECURITY CONFIGURATION
################################################################################

output "security_configuration_name" {
  description = "Name of the Glue security configuration attached to the job. Null when none is used."
  value       = local.effective_security_config
}

################################################################################
# CATALOG DATABASE
################################################################################

output "catalog_database_name" {
  description = "Name of the Glue Catalog database. Null when create_catalog_database = false."
  value       = var.create_catalog_database ? aws_glue_catalog_database.glue_catalog_db[0].name : null
}

output "catalog_database_arn" {
  description = "ARN of the Glue Catalog database. Null when create_catalog_database = false."
  value       = var.create_catalog_database ? aws_glue_catalog_database.glue_catalog_db[0].arn : null
}

################################################################################
# CRAWLER
################################################################################

output "crawler_name" {
  description = "Name of the Glue crawler. Null when create_crawler = false."
  value       = var.create_crawler ? aws_glue_crawler.glue_data_crawler[0].name : null
}

output "crawler_arn" {
  description = "ARN of the Glue crawler. Null when create_crawler = false."
  value       = var.create_crawler ? aws_glue_crawler.glue_data_crawler[0].arn : null
}

################################################################################
# TRIGGER
################################################################################

output "trigger_name" {
  description = "Name of the Glue trigger. Null when create_trigger = false."
  value       = var.create_trigger ? aws_glue_trigger.glue_schedule[0].name : null
}

output "trigger_arn" {
  description = "ARN of the Glue trigger. Null when create_trigger = false."
  value       = var.create_trigger ? aws_glue_trigger.glue_schedule[0].arn : null
}

################################################################################
# WORKFLOW
################################################################################

output "workflow_name" {
  description = "Name of the Glue workflow. Null when create_workflow = false."
  value       = var.create_workflow ? aws_glue_workflow.glue_pipeline[0].name : null
}

output "workflow_arn" {
  description = "ARN of the Glue workflow. Null when create_workflow = false."
  value       = var.create_workflow ? aws_glue_workflow.glue_pipeline[0].arn : null
}
