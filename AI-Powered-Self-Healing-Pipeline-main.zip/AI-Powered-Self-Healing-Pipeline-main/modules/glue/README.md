# modules/glue

A production-ready Terraform module for AWS Glue ETL jobs.

## SUMMARY:
Terraform reads the crawler configuration you define in tfvars (enabled via create_crawler = true), loops through each job using for_each, and creates or updates a crawler in AWS Glue with the specified data sources (S3 paths or JDBC connections), database, table prefix, and optional schedule; it also provisions the required IAM roles and permissions, and links the crawler to the Glue Data Catalog so that when the pipeline runs Terraform, your crawler is automatically set up to scan data, infer schema, and create or update tables without any manual intervention.

## Features

- **Folder-based artefact upload** — point the module at a local job directory; it discovers and uploads every file inside `job/`, `packages/`, and `extra-py-files/` to S3, preserving the folder structure. Change-detection uses MD5 so re-uploads only happen when content changes.
- **Auto-wired job arguments** — `--TempDir`, `--spark-event-logs-path`, `--extra-py-files`, and all observability flags are injected automatically. Caller-supplied `default_arguments` are merged on top.
- **Least-privilege IAM** — a dedicated execution role is created with a scoped baseline policy (CloudWatch Logs, Glue Catalog reads, S3 script access, and optional KMS). Extra policies are merged cleanly.
- **Security configuration** — optional at-rest encryption for S3 artefacts, CloudWatch Logs, and job bookmarks.
- **CloudWatch log group** — pre-created with configurable retention so Glue never auto-creates one with unlimited retention.
- **Optional crawler, trigger, workflow** — all managed within the same module call.

---

## Local Folder Structure

The dev team creates the following structure under the Terraform root before running `terraform apply`. Folders that don't exist are silently skipped — only `job/` is required.

```
<job_source_dir>/
├── job/
│   └── <script_filename>       ← required: main Glue ETL script
├── packages/                   ← optional: pre-built wheels / zips / py files
│   ├── my_library.whl
│   └── requirements.txt        ← uploaded to S3 but excluded from --extra-py-files
└── extra-py-files/             ← optional: helper Python modules
    └── utils.py
```

### S3 Mirror

The module uploads everything to the same relative path inside the scripts bucket:

```
s3://<script_bucket_name>/
└── <job_source_dir>/
    ├── job/<script_filename>
    ├── packages/               ← mirrored from local packages/ (if folder exists)
    ├── extra-py-files/         ← mirrored from local extra-py-files/ (if folder exists)
    ├── temporary/              ← --TempDir  (auto-derived, no files uploaded)
    └── sparkHistoryLogs/       ← --spark-event-logs-path  (auto-derived, no files uploaded)
```

### `--extra-py-files` Auto-injection

Files with extensions `.py`, `.zip`, `.whl`, `.egg` found in `packages/` **and** `extra-py-files/` are collected and passed as a comma-separated list to `--extra-py-files`. All other files (e.g. `requirements.txt`) are uploaded to S3 for reference but excluded from the argument.

The argument is omitted entirely when neither folder contains qualifying files.

---

## Auto-Injected Job Arguments

The following arguments are always added by the module. Caller-supplied `default_arguments` are merged after and take precedence.

| Argument | Value | Condition |
|---|---|---|
| `--enable-continuous-cloudwatch-log` | `"true"` | always |
| `--enable-continuous-log-filter` | `"true"` | always |
| `--continuous-log-logGroup` | CloudWatch log group name | always |
| `--enable-metrics` | `""` | always |
| `--enable-job-insights` | `"true"` | always |
| `--enable-observability-metrics` | `"true"` | always |
| `--TempDir` | `s3://<bucket>/<job_dir>/temporary/` | always |
| `--enable-spark-ui` | `"true"` | ETL / streaming only |
| `--spark-event-logs-path` | `s3://<bucket>/<job_dir>/sparkHistoryLogs/` | ETL / streaming only |
| `--extra-py-files` | comma-separated S3 URIs | when qualifying files found |

---

## Usage

### Minimal — single job

```hcl
module "glue_my_job" {
  source = "./modules/glue"

  job_name           = "dev-sales-ai-filter-leads"
  description        = "Filters SDR lead records from the raw S3 dataset"
  job_source_dir     = "glue-jobs/filter-leads"
  script_filename    = "filter_leads.py"
  script_bucket_name = module.glue_scripts_bucket.bucket_id

  tags = merge(local.common_tags, {
    Component = "glue-etl"
  })
}
```

### Multiple jobs via `for_each` (recommended)

Job definitions live in `tfvars/<env>.tfvars` so each environment deploys only the jobs it needs.

**`variables.tf` (root)**

```hcl
variable "glue_jobs" {
  type = map(object({
    description           = optional(string, "")
    job_source_dir        = string
    script_filename       = string
    default_arguments     = optional(map(string), {})
    log_retention_in_days = optional(number, 30)
    create_trigger        = optional(bool, false)
    trigger_schedule      = optional(string, null)
    trigger_description   = optional(string, null)
  }))
  default = {}
}
```

**`glue-job.tf` (root)**

```hcl
module "glue_jobs" {
  for_each = var.glue_jobs
  source   = "./modules/glue"

  job_name           = "${local.name_prefix}-${each.key}"
  description        = each.value.description
  job_source_dir     = each.value.job_source_dir
  script_filename    = each.value.script_filename
  script_bucket_name = module.glue_scripts_bucket.bucket_id

  default_arguments     = each.value.default_arguments
  log_retention_in_days = each.value.log_retention_in_days

  create_trigger      = each.value.create_trigger
  trigger_schedule    = each.value.trigger_schedule
  trigger_description = each.value.trigger_description

  tags = merge(local.common_tags, {
    Name      = "${local.name_prefix}-${each.key}"
    Component = "glue-etl"
  })
}
```

**`tfvars/dev.tfvars`** — both jobs deployed in dev

```hcl
glue_jobs = {
  "etl-job-1" = {
    description    = "Glue ETL job — etl-job-1"
    job_source_dir = "glue-jobs/etl-job-1"
    script_filename = "etl_job_1.py"
    default_arguments = {
      "--job-bookmark-option" = "job-bookmark-enable"
    }
  }

  "etl-job-2" = {
    description    = "Glue ETL job — etl-job-2"
    job_source_dir = "glue-jobs/etl-job-2"
    script_filename = "etl_job_2.py"
    default_arguments = {
      "--job-bookmark-option" = "job-bookmark-enable"
    }
    create_trigger      = true
    trigger_schedule    = "cron(0 2 * * ? *)"
    trigger_description = "Daily trigger for etl-job-2 at 02:00 UTC"
  }
}
```

**`tfvars/prod.tfvars`** — omit the variable entirely; defaults to `{}` so no Glue jobs are deployed.

### With extra IAM policies (e.g. S3 data bucket access)

```hcl
data "aws_iam_policy_document" "glue_s3_data_read" {
  statement {
    sid     = "S3DataRead"
    actions = ["s3:GetObject", "s3:ListBucket"]
    resources = [
      "arn:aws:s3:::my-raw-data-bucket",
      "arn:aws:s3:::my-raw-data-bucket/*",
    ]
  }
}

module "glue_my_job" {
  source = "./modules/glue"

  job_name           = "dev-sales-ai-filter-leads"
  job_source_dir     = "glue-jobs/filter-leads"
  script_filename    = "filter_leads.py"
  script_bucket_name = module.glue_scripts_bucket.bucket_id

  extra_customer_managed_policies = {
    s3_data_read = {
      name   = "dev-sales-ai-filter-leads-s3-data-read"
      policy = data.aws_iam_policy_document.glue_s3_data_read.json
    }
  }

  tags = merge(local.common_tags, { Component = "glue-etl" })
}
```

### With a scheduled trigger and workflow

```hcl
module "glue_my_job" {
  source = "./modules/glue"

  job_name           = "dev-sales-ai-daily-ingest"
  job_source_dir     = "glue-jobs/daily-ingest"
  script_filename    = "daily_ingest.py"
  script_bucket_name = module.glue_scripts_bucket.bucket_id

  create_trigger      = true
  trigger_type        = "SCHEDULED"
  trigger_schedule    = "cron(0 3 * * ? *)"
  trigger_description = "Runs the daily ingest job at 03:00 UTC"

  create_workflow = true

  tags = merge(local.common_tags, { Component = "glue-etl" })
}
```

---

## IAM Baseline Permissions

The module-created role always includes these permissions:

| Permission | Scope |
|---|---|
| `logs:CreateLogStream`, `logs:PutLogEvents`, `logs:CreateLogGroup` | Scoped to `/aws-glue/jobs/<job_name>` log group only |
| `glue:GetDatabase/Table/Partition*` | `*` (Catalog reads require wildcard) |
| `glue:GetJob/JobRun*` | `*` |
| `s3:GetBucketLocation`, `s3:ListBucket` | Scripts bucket only |
| `s3:GetObject`, `s3:GetObjectVersion` | `<bucket>/<job_source_dir>/*` (all job files) |
| `s3:PutObject`, `s3:DeleteObject` | `<job_source_dir>/temporary/*` and `<job_source_dir>/sparkHistoryLogs/*` only |
| `kms:Decrypt`, `kms:GenerateDataKey`, `kms:DescribeKey` | Only the KMS keys configured via variables |

Add data-bucket access, Secrets Manager reads, or other job-specific permissions via `extra_customer_managed_policies`.

---

## Inputs

### Required

| Name | Type | Description |
|---|---|---|
| `job_name` | `string` | Unique name for the Glue job. Used as the base name for the role, log group, and trigger. |
| `job_source_dir` | `string` | Path to the job's local root directory, relative to Terraform root. e.g. `"glue-jobs/my-job"` |
| `script_filename` | `string` | Name of the main script file inside the `job/` subfolder. e.g. `"my_job.py"` |
| `script_bucket_name` | `string` | Name of the existing S3 bucket where all job artefacts are uploaded. |

### Runtime

| Name | Type | Default | Description |
|---|---|---|---|
| `description` | `string` | `""` | Human-readable job description. |
| `command_name` | `string` | `"glueetl"` | `glueetl`, `pythonshell`, or `gluestreaming`. |
| `python_version` | `string` | `"3"` | Python version for the Glue command. |
| `glue_version` | `string` | `"5.0"` | Glue version. `5.0` = Spark 3.5 / Python 3.11. |
| `worker_type` | `string` | `"Standard"` | Worker type for ETL/streaming jobs. See variable for all valid values. |
| `number_of_workers` | `number` | `2` | Number of workers. Must be ≥ 2 for ETL jobs. |
| `max_capacity` | `number` | `null` | DPU capacity for Python shell jobs. Mutually exclusive with `worker_type`. |
| `max_retries` | `number` | `0` | Retry count on failure (0–10). |
| `timeout` | `number` | `2800` | Job timeout in minutes (1–10080). |
| `max_concurrent_runs` | `number` | `2` | Max concurrent job runs (1–999). |
| `execution_class` | `string` | `"STANDARD"` | `STANDARD` or `FLEX` (lower-priority, cheaper). |
| `job_run_queuing_enabled` | `bool` | `false` | Queue runs instead of failing at the concurrency limit. |
| `default_arguments` | `map(string)` | `{}` | Extra job arguments. Keys must be prefixed with `--`. Merged after built-in args. |
| `non_overridable_arguments` | `map(string)` | `{}` | Job arguments that cannot be overridden at run time. |
| `connections` | `list(string)` | `[]` | Existing Glue connection names to attach. |

### IAM

| Name | Type | Default | Description |
|---|---|---|---|
| `create_iam_role` | `bool` | `true` | Create a dedicated execution role. |
| `iam_role_arn` | `string` | `null` | Bring-your-own role ARN (requires `create_iam_role = false`). |
| `iam_role_path` | `string` | `"/"` | IAM path for the execution role. |
| `permission_boundary_arn` | `string` | `null` | Permission boundary ARN to attach to the role. |
| `extra_customer_managed_policies` | `map(object)` | `{}` | Extra IAM policies to create and attach. |
| `extra_customer_managed_policy_arns` | `list(string)` | `[]` | Pre-existing policy ARNs to attach. |
| `extra_aws_managed_policy_arns` | `list(string)` | `[]` | AWS-managed policy ARNs to attach. |
| `extra_inline_policies` | `map(string)` | `{}` | Inline policies to embed in the role. |

### Security & Encryption

| Name | Type | Default | Description |
|---|---|---|---|
| `create_security_configuration` | `bool` | `false` | Create a Glue security configuration for at-rest encryption. |
| `security_configuration_name` | `string` | `null` | Use an existing security configuration instead of creating one. |
| `s3_kms_key_arn` | `string` | `null` | KMS key for S3 encryption in the security config. Defaults to SSE-S3 when null. |
| `cloudwatch_kms_key_arn` | `string` | `null` | KMS key for CloudWatch log encryption. |
| `job_bookmarks_kms_key_arn` | `string` | `null` | KMS key for job bookmark encryption. |
| `log_retention_in_days` | `number` | `30` | CloudWatch log retention in days. |
| `log_kms_key_id` | `string` | `null` | KMS key for the CloudWatch log group. |

### Catalog Database

| Name | Type | Default | Description |
|---|---|---|---|
| `create_catalog_database` | `bool` | `false` | Create a Glue Catalog database. |
| `catalog_database_name` | `string` | `null` | Database name. Required when `create_catalog_database = true`. |
| `catalog_database_description` | `string` | `""` | Database description. |
| `catalog_id` | `string` | `null` | Catalog ID (AWS account ID). Defaults to current account. |

### Crawler

| Name | Type | Default | Description |
|---|---|---|---|
| `create_crawler` | `bool` | `false` | Create a Glue crawler. |
| `crawler_name` | `string` | `null` | Crawler name. Defaults to `<job_name>-crawler`. |
| `crawler_description` | `string` | `""` | Crawler description. |
| `crawler_role_arn` | `string` | `null` | IAM role for the crawler. Defaults to the job's execution role. |
| `crawler_database_name` | `string` | `null` | Catalog database the crawler populates. |
| `crawler_schedule` | `string` | `null` | Cron schedule for the crawler. On-demand when null. |
| `crawler_s3_targets` | `list(object)` | `[]` | S3 paths for the crawler to scan. |
| `crawler_jdbc_targets` | `list(object)` | `[]` | JDBC targets for the crawler. |
| `crawler_classifiers` | `list(string)` | `[]` | Custom classifier names. |
| `crawler_table_prefix` | `string` | `null` | Prefix added to all table names created by the crawler. |
| `crawler_configuration` | `string` | `null` | JSON string for crawler configuration overrides. |
| `crawler_recrawl_policy` | `object` | `null` | Recrawl behaviour: `CRAWL_EVERYTHING`, `CRAWL_NEW_FOLDERS_ONLY`, or `CRAWL_EVENT_MODE`. |
| `crawler_schema_change_policy` | `object` | `null` | How the crawler handles schema changes (update and delete behaviour). |
| `crawler_lineage_configuration` | `object` | `null` | Data lineage settings (`ENABLE` or `DISABLE`). |
| `crawler_lake_formation_configuration` | `object` | `null` | Lake Formation credentials configuration for the crawler. |

### Trigger

| Name | Type | Default | Description |
|---|---|---|---|
| `create_trigger` | `bool` | `false` | Create a Glue trigger. |
| `trigger_name` | `string` | `null` | Trigger name. Defaults to `<job_name>-trigger`. |
| `trigger_type` | `string` | `"SCHEDULED"` | `SCHEDULED`, `CONDITIONAL`, `ON_DEMAND`, or `EVENT`. |
| `trigger_description` | `string` | `""` | Trigger description. |
| `trigger_schedule` | `string` | `null` | Cron expression. Required when `trigger_type = "SCHEDULED"`. |
| `trigger_enabled` | `bool` | `true` | Whether the trigger is active on creation. |
| `trigger_workflow_name` | `string` | `null` | Workflow to associate the trigger with (when not using `create_workflow`). |
| `trigger_actions` | `list(object)` | `[]` | Additional actions beyond the job itself. The job is always the first action. |
| `trigger_predicate` | `object` | `null` | Predicate for `CONDITIONAL` triggers. |

### Workflow

| Name | Type | Default | Description |
|---|---|---|---|
| `create_workflow` | `bool` | `false` | Create a Glue workflow and associate the trigger with it. |
| `workflow_name` | `string` | `null` | Workflow name. Defaults to `<job_name>-workflow`. |
| `workflow_description` | `string` | `""` | Workflow description. |
| `workflow_max_concurrent_runs` | `number` | `null` | Max concurrent runs for the workflow. Unlimited when null. |
| `workflow_default_run_properties` | `map(string)` | `{}` | Default run properties passed to all jobs in the workflow. |

### Tags

| Name | Type | Default | Description |
|---|---|---|---|
| `tags` | `map(string)` | `{}` | Tags applied to all resources created by this module. |

---

## Outputs

| Name | Description |
|---|---|
| `job_name` | Name of the Glue job. |
| `job_arn` | ARN of the Glue job. |
| `job_id` | ID of the Glue job. |
| `job_source_dir` | Normalised S3 prefix anchoring all job artefacts. |
| `script_s3_uri` | Full S3 URI of the uploaded script. |
| `script_s3_key` | S3 key of the uploaded script. |
| `temp_dir_s3_uri` | S3 URI used as `--TempDir`. |
| `spark_logs_s3_uri` | S3 URI used for Spark UI event logs. |
| `packages_s3_keys` | List of S3 keys uploaded from `packages/`. Empty when folder absent. |
| `extra_py_files_s3_keys` | List of S3 keys uploaded from `extra-py-files/`. Empty when folder absent. |
| `extra_py_files_argument` | The `--extra-py-files` argument value (comma-separated S3 URIs). Empty string when no qualifying files found. |
| `role_arn` | ARN of the Glue execution role (module-created or caller-supplied). |
| `role_name` | Name of the module-created execution role. Null when `create_iam_role = false`. |
| `role_id` | Unique ID of the module-created execution role. Null when `create_iam_role = false`. |
| `log_group_name` | CloudWatch log group name for Glue job output. |
| `log_group_arn` | ARN of the CloudWatch log group. |
| `security_configuration_name` | Security configuration name. Null when none is used. |
| `catalog_database_name` | Glue Catalog database name. Null when `create_catalog_database = false`. |
| `catalog_database_arn` | Glue Catalog database ARN. Null when `create_catalog_database = false`. |
| `crawler_name` | Crawler name. Null when `create_crawler = false`. |
| `crawler_arn` | Crawler ARN. Null when `create_crawler = false`. |
| `trigger_name` | Trigger name. Null when `create_trigger = false`. |
| `trigger_arn` | Trigger ARN. Null when `create_trigger = false`. |
| `workflow_name` | Workflow name. Null when `create_workflow = false`. |
| `workflow_arn` | Workflow ARN. Null when `create_workflow = false`. |

---

## Requirements

| Requirement | Version |
|---|---|
| Terraform | >= 1.4.0 |
| AWS provider | >= 5.0 |

> **Note:** Terraform 1.4+ is required for `optional()` attribute support in object variables and the `terraform_data` resource used internally.
