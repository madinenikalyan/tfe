
################################################################################
# LOCALS — derived values resolved once
################################################################################

locals {
  # Effective role ARN: module-created or caller-supplied
  effective_role_arn = var.create_iam_role ? module.glue_role[0].role_arn : var.iam_role_arn

  # Security configuration: prefer an existing one, then module-created, else null
  effective_security_config = (
    var.security_configuration_name != null ? var.security_configuration_name :
    var.create_security_configuration ? aws_glue_security_configuration.glue_encryption[0].name :
    null
  )

  # Crawler defaults
  effective_crawler_name = coalesce(var.crawler_name, "${var.job_name}-crawler")
  effective_crawler_database = (
    var.crawler_database_name != null ? var.crawler_database_name :
    var.create_catalog_database ? var.catalog_database_name :
    null
  )
  effective_crawler_role_arn = coalesce(var.crawler_role_arn, local.effective_role_arn)

  # Trigger & workflow name defaults
  effective_trigger_name  = coalesce(var.trigger_name, "${var.job_name}-trigger")
  effective_workflow_name = coalesce(var.workflow_name, "${var.job_name}-workflow")

  # Base trigger actions list: always include the job itself first
  base_trigger_action = [{
    job_name  = aws_glue_job.glue_etl_job.name
    arguments = {}
    timeout   = null
  }]
  all_trigger_actions = concat(local.base_trigger_action, var.trigger_actions)

  # S3 encryption mode: KMS when key provided, else SSE-S3
  s3_encryption_mode = var.s3_kms_key_arn != null ? "SSE-KMS" : "SSE-S3"

  # ── Job source directory (strip ./ or leading /) ───────────────────────────
  job_dir_clean = trimsuffix(trimprefix(trimprefix(var.job_source_dir, "./"), "/"), "/")

  # ── Script ─────────────────────────────────────────────────────────────────
  # Local:  <job_dir>/job/<script_filename>
  # S3:     s3://<bucket>/<job_dir>/job/<script_filename>
  script_local_path = "${path.root}/${local.job_dir_clean}/job/${var.script_filename}"
  script_s3_key     = "${local.job_dir_clean}/job/${var.script_filename}"
  script_s3_uri     = "s3://${var.script_bucket_name}/${local.script_s3_key}"

  # ── S3 working directories (always derived, no user input required) ─────────
  temp_dir_s3_uri   = "s3://${var.script_bucket_name}/${local.job_dir_clean}/temporary/"
  spark_logs_s3_uri = "s3://${var.script_bucket_name}/${local.job_dir_clean}/sparkHistoryLogs/"

  # ── packages/ folder ────────────────────────────────────────────────────────
  # fileset() errors when the directory does not exist; try() returns an empty
  # set in that case so the folder is simply skipped without any error.
  packages_files = toset(
    try(fileset("${path.root}/${local.job_dir_clean}/packages", "**"), toset([]))
  )
  has_packages_dir = length(local.packages_files) > 0

  # ── extra-py-files/ folder ─────────────────────────────────────────────────
  extra_py_files = toset(
    try(fileset("${path.root}/${local.job_dir_clean}/extra-py-files", "**"), toset([]))
  )
  has_extra_py_files_dir = length(local.extra_py_files) > 0

  # ── --extra-py-files argument ───────────────────────────────────────────────
  # Only .py / .zip / .whl / .egg files are supported by Glue's --extra-py-files.
  # Other files (e.g. requirements.txt, README.md) are uploaded to S3 for
  # reference but are excluded from the argument to avoid Glue errors.
  packages_glue_files = [for f in sort(tolist(local.packages_files)) : f
    if endswith(f, ".py") || endswith(f, ".zip") || endswith(f, ".whl") || endswith(f, ".egg")
  ]
  extra_py_glue_files = [for f in sort(tolist(local.extra_py_files)) : f
    if endswith(f, ".py") || endswith(f, ".zip") || endswith(f, ".whl") || endswith(f, ".egg")
  ]

  all_extra_py_s3_uris = concat(
    [for f in local.packages_glue_files : "s3://${var.script_bucket_name}/${local.job_dir_clean}/packages/${f}"],
    [for f in local.extra_py_glue_files : "s3://${var.script_bucket_name}/${local.job_dir_clean}/extra-py-files/${f}"]
  )
  has_extra_py_arg = length(local.all_extra_py_s3_uris) > 0
  extra_py_arg     = join(",", local.all_extra_py_s3_uris)
}

################################################################################
# CLOUDWATCH LOG GROUP
#
# Pre-created before the job so retention and KMS are controlled by Terraform
# rather than auto-created by Glue with unlimited retention.
################################################################################

resource "aws_cloudwatch_log_group" "glue_job_logs" {
  name              = "/aws-glue/jobs/${var.job_name}"
  retention_in_days = var.log_retention_in_days
  kms_key_id        = var.log_kms_key_id

  tags = var.tags
}

################################################################################
# SCRIPT UPLOAD
#
# Uploads  <job_source_dir>/job/<script_filename>  to S3 at the same relative
# path, preserving the local folder structure.
# etag (file MD5) replaces the object whenever the script changes.
################################################################################

resource "aws_s3_object" "glue_script" {
  bucket = var.script_bucket_name
  key    = local.script_s3_key
  source = local.script_local_path
  # try() prevents plan failure when the file is missing; apply will still fail
  # with a clear provider error — create <job_source_dir>/job/<script_filename> locally.
  etag = try(filemd5(local.script_local_path), null)

  tags = var.tags
}

################################################################################
# PACKAGES UPLOAD (conditional)
#
# If <job_source_dir>/packages/ exists locally, every file in it is uploaded
# to s3://<bucket>/<job_source_dir>/packages/<file> preserving structure.
# Files with Glue-compatible extensions (.py .zip .whl .egg) are collected
# into the --extra-py-files job argument automatically.
# If the folder is absent the for_each is empty and nothing is uploaded.
################################################################################

resource "aws_s3_object" "glue_packages" {
  for_each = local.packages_files

  bucket = var.script_bucket_name
  key    = "${local.job_dir_clean}/packages/${each.value}"
  source = "${path.root}/${local.job_dir_clean}/packages/${each.value}"
  etag   = filemd5("${path.root}/${local.job_dir_clean}/packages/${each.value}")

  tags = var.tags
}

################################################################################
# EXTRA-PY-FILES UPLOAD (conditional)
#
# If <job_source_dir>/extra-py-files/ exists locally, every file in it is
# uploaded to s3://<bucket>/<job_source_dir>/extra-py-files/<file>.
# .py/.zip/.whl/.egg files are collected into --extra-py-files automatically.
# If the folder is absent the for_each is empty and nothing is uploaded.
################################################################################

resource "aws_s3_object" "glue_extra_py_files" {
  for_each = local.extra_py_files

  bucket = var.script_bucket_name
  key    = "${local.job_dir_clean}/extra-py-files/${each.value}"
  source = "${path.root}/${local.job_dir_clean}/extra-py-files/${each.value}"
  etag   = filemd5("${path.root}/${local.job_dir_clean}/extra-py-files/${each.value}")

  tags = var.tags
}

################################################################################
# IAM — trust policy (Glue service principal)
################################################################################

data "aws_iam_policy_document" "glue_assume_role" {
  count = var.create_iam_role ? 1 : 0

  statement {
    sid     = "GlueAssumeRole"
    effect  = "Allow"
    actions = ["sts:AssumeRole"]

    principals {
      type        = "Service"
      identifiers = ["glue.amazonaws.com"]
    }
  }
}

################################################################################
# IAM — baseline policy
#
# Least-privilege permissions every Glue job needs:
#   • CloudWatch Logs  — write to the job's dedicated log group
#   • Glue Catalog     — read databases/tables at runtime
#   • S3 scripts bucket
#       – ListBucket on the bucket
#       – GetObject on all files under <job_source_dir>/*
#         (covers job/, packages/, extra-py-files/)
#       – PutObject/DeleteObject on temporary/ and sparkHistoryLogs/
#   • KMS              — decrypt when keys are configured
################################################################################

data "aws_iam_policy_document" "glue_baseline" {
  count = var.create_iam_role ? 1 : 0


  statement { # CloudWatch Logs — job log group + default Glue log groups
    sid    = "CloudWatchLogs"
    effect = "Allow"
    actions = [
      "logs:CreateLogStream",
      "logs:PutLogEvents",
      "logs:CreateLogGroup",
      "logs:GetLogEvents",
      "logs:DescribeLogGroups",
      "logs:DescribeLogStreams",
    ]
    resources = [
      aws_cloudwatch_log_group.glue_job_logs.arn,
      "${aws_cloudwatch_log_group.glue_job_logs.arn}:*",
      "arn:aws:logs:*:*:log-group:/aws-glue/jobs/*",
    ]
  }


  statement { # Glue Data Catalog — read-only (jobs resolve schema at runtime)
    sid    = "GlueCatalogRead"
    effect = "Allow"
    actions = [
      "glue:GetDatabase",
      "glue:GetDatabases",
      "glue:GetTable",
      "glue:GetTables",
      "glue:GetPartition",
      "glue:GetPartitions",
      "glue:BatchGetPartition",
      "glue:GetConnection",
    ]
    resources = ["*"]
  }


  statement { # Glue job self-reference — required so a job can read its own run details
    sid    = "GlueJobSelf"
    effect = "Allow"
    actions = [
      "glue:GetJob",
      "glue:GetJobRun",
      "glue:GetJobRuns",
    ]
    resources = ["*"]
  }


  statement { # EC2 — required for Glue connections that use a VPC (ENI management)
    sid    = "EC2NetworkAccess"
    effect = "Allow"
    actions = [
      "ec2:DescribeSubnets",
      "ec2:DescribeSecurityGroups",
      "ec2:DescribeVpcs",
      "ec2:DescribeVpcEndpoints",
      "ec2:DescribeRouteTables",
      "ec2:DescribeAvailabilityZones",
      "ec2:DescribeNetworkInterfaces",
      "ec2:CreateNetworkInterface",
      "ec2:DeleteNetworkInterface",
      "ec2:CreateTags",
      "ec2:DeleteTags",
    ]
    resources = ["*"]
  }


  statement { # S3 — list the scripts bucket to find the job script and dependencies
    sid     = "S3ScriptBucketList"
    effect  = "Allow"
    actions = ["s3:GetBucketLocation", "s3:ListBucket"]
    resources = [
      "arn:aws:s3:::${var.script_bucket_name}",
    ]
  }


  statement { # S3 — read all job artefacts (script, packages, extra-py-files)
    sid     = "S3JobFilesRead"
    effect  = "Allow"
    actions = ["s3:GetObject", "s3:GetObjectVersion"]
    resources = [
      "arn:aws:s3:::${var.script_bucket_name}/${local.job_dir_clean}/*",
    ]
  }


  statement { # S3 — read/write the working directories (TempDir + Spark UI event logs)
    sid    = "S3JobWorkingDirs"
    effect = "Allow"
    actions = [
      "s3:PutObject",
      "s3:DeleteObject",
    ]
    resources = [
      "arn:aws:s3:::${var.script_bucket_name}/${local.job_dir_clean}/temporary/*",
      "arn:aws:s3:::${var.script_bucket_name}/${local.job_dir_clean}/sparkHistoryLogs/*",
    ]
  }


  dynamic "statement" { # KMS — decrypt log group and/or S3 when keys are configured
    for_each = (var.log_kms_key_id != null || var.s3_kms_key_arn != null || var.cloudwatch_kms_key_arn != null || var.job_bookmarks_kms_key_arn != null) ? [1] : []
    content {
      sid    = "KMSDecrypt"
      effect = "Allow"
      actions = [
        "kms:Decrypt",
        "kms:GenerateDataKey",
        "kms:DescribeKey",
      ]
      resources = compact([
        var.log_kms_key_id,
        var.s3_kms_key_arn,
        var.cloudwatch_kms_key_arn,
        var.job_bookmarks_kms_key_arn,
      ])
    }
  }
}

################################################################################
# IAM ROLE — delegated to the shared IAM module
################################################################################

module "glue_role" {
  count  = var.create_iam_role ? 1 : 0
  source = "../iam"

  role_name               = "${var.job_name}-glue-role"
  description             = "Execution role for Glue job: ${var.job_name}"
  path                    = var.iam_role_path
  assume_role_policy      = data.aws_iam_policy_document.glue_assume_role[0].json
  permission_boundary_arn = var.permission_boundary_arn
  force_detach_policies   = true


  customer_managed_policies = merge( # Merge the mandatory baseline policy with any caller-supplied policies.
    {
      glue_baseline = { # The key "glue_baseline" is reserved by this module.
        name        = "${var.job_name}-glue-baseline-policy"
        description = "Baseline CloudWatch + Catalog + S3 access for ${var.job_name}"
        path        = var.iam_role_path
        policy      = data.aws_iam_policy_document.glue_baseline[0].json
      }
    },
    var.extra_customer_managed_policies
  )

  customer_managed_policy_arns = var.extra_customer_managed_policy_arns
  aws_managed_policy_arns      = var.extra_aws_managed_policy_arns
  inline_policies              = var.extra_inline_policies

  tags = var.tags
}

################################################################################
# SECURITY CONFIGURATION (optional)
################################################################################

resource "aws_glue_security_configuration" "glue_encryption" {
  count = var.create_security_configuration && var.security_configuration_name == null ? 1 : 0

  name = "${var.job_name}-sec-config"

  encryption_configuration {
    s3_encryption {
      s3_encryption_mode = local.s3_encryption_mode
      kms_key_arn        = var.s3_kms_key_arn
    }

    cloudwatch_encryption {
      cloudwatch_encryption_mode = var.cloudwatch_kms_key_arn != null ? "SSE-KMS" : "DISABLED"
      kms_key_arn                = var.cloudwatch_kms_key_arn
    }

    job_bookmarks_encryption {
      job_bookmarks_encryption_mode = var.job_bookmarks_kms_key_arn != null ? "CSE-KMS" : "DISABLED"
      kms_key_arn                   = var.job_bookmarks_kms_key_arn
    }
  }
}

################################################################################
# GLUE CATALOG DATABASE (optional)
################################################################################

resource "aws_glue_catalog_database" "glue_catalog_db" {
  count = var.create_catalog_database ? 1 : 0

  name        = var.catalog_database_name
  description = var.catalog_database_description
  catalog_id  = var.catalog_id

  tags = var.tags


}

################################################################################
# GLUE JOB
#
# All monitoring/observability arguments are injected automatically:
#   --enable-continuous-cloudwatch-log  continuous logs → job log group
#   --enable-continuous-log-filter      suppresses driver log noise
#   --enable-metrics                    CloudWatch metrics per run
#   --enable-job-insights               anomaly detection / insights panel
#   --enable-observability-metrics      enhanced observability (Glue 4.0+)
#   --TempDir                           <job_source_dir>/temporary/
#   --enable-spark-ui                   Spark history server (ETL/streaming)
#   --spark-event-logs-path             <job_source_dir>/sparkHistoryLogs/
#   --extra-py-files                    auto-built from packages/ + extra-py-files/
#                                       (omitted when both folders are absent)
################################################################################

resource "aws_glue_job" "glue_etl_job" {
  name        = var.job_name
  description = var.description
  role_arn    = local.effective_role_arn

  command {
    name            = var.command_name
    script_location = local.script_s3_uri
    python_version  = var.python_version
  }

  glue_version      = var.glue_version
  execution_class   = var.execution_class
  worker_type       = var.command_name != "pythonshell" ? var.worker_type : null # Worker configuration (Spark ETL / streaming only)
  number_of_workers = var.command_name != "pythonshell" ? var.number_of_workers : null
  max_capacity      = var.command_name == "pythonshell" ? var.max_capacity : null # DPU capacity (Python shell only)
  timeout           = var.timeout
  max_retries       = var.max_retries

  execution_property {
    max_concurrent_runs = var.max_concurrent_runs
  }

  job_run_queuing_enabled = var.job_run_queuing_enabled
  connections             = length(var.connections) > 0 ? var.connections : null # User-supplied connections only

  default_arguments = merge(
    {
      # Continuous CloudWatch logging
      "--enable-continuous-cloudwatch-log" = "true"
      "--enable-continuous-log-filter"     = "true"
      "--continuous-log-logGroup"          = aws_cloudwatch_log_group.glue_job_logs.name

      # Metrics & insights
      "--enable-metrics"               = ""
      "--enable-job-insights"          = "true"
      "--enable-observability-metrics" = "true"

      # Temp directory
      "--TempDir" = local.temp_dir_s3_uri
    },
    # Spark UI — ETL and streaming only, not Python shell
    var.command_name != "pythonshell" ? {
      "--enable-spark-ui"       = "true"
      "--spark-event-logs-path" = local.spark_logs_s3_uri
    } : {},
    # Extra py files — only injected when at least one supported file is found
    local.has_extra_py_arg ? {
      "--extra-py-files" = local.extra_py_arg
    } : {},
    # Caller-supplied arguments override anything above
    var.default_arguments
  )

  non_overridable_arguments = var.non_overridable_arguments

  security_configuration = local.effective_security_config

  tags = var.tags

  depends_on = [
    module.glue_role,
    aws_cloudwatch_log_group.glue_job_logs,
    aws_glue_security_configuration.glue_encryption,
    aws_s3_object.glue_script,
    aws_s3_object.glue_packages,
    aws_s3_object.glue_extra_py_files,
  ]

}

################################################################################
# GLUE CRAWLER (optional)
################################################################################

resource "aws_glue_crawler" "glue_data_crawler" {
  count = var.create_crawler ? 1 : 0

  name          = local.effective_crawler_name
  role          = local.effective_crawler_role_arn
  database_name = local.effective_crawler_database
  description   = var.crawler_description
  classifiers   = var.crawler_classifiers
  table_prefix  = var.crawler_table_prefix
  configuration = var.crawler_configuration
  schedule      = var.crawler_schedule

  security_configuration = local.effective_security_config

  dynamic "s3_target" {
    for_each = var.crawler_s3_targets
    content {
      path            = s3_target.value.path
      exclusions      = s3_target.value.exclusions
      connection_name = s3_target.value.connection_name
    }
  }

  dynamic "jdbc_target" {
    for_each = var.crawler_jdbc_targets
    content {
      connection_name = jdbc_target.value.connection_name
      path            = jdbc_target.value.path
      exclusions      = jdbc_target.value.exclusions
    }
  }

  dynamic "recrawl_policy" {
    for_each = var.crawler_recrawl_policy != null ? [var.crawler_recrawl_policy] : []
    content {
      recrawl_behavior = recrawl_policy.value.recrawl_behavior
    }
  }

  dynamic "schema_change_policy" {
    for_each = var.crawler_schema_change_policy != null ? [var.crawler_schema_change_policy] : []
    content {
      update_behavior = schema_change_policy.value.update_behavior
      delete_behavior = schema_change_policy.value.delete_behavior
    }
  }

  dynamic "lineage_configuration" {
    for_each = var.crawler_lineage_configuration != null ? [var.crawler_lineage_configuration] : []
    content {
      crawler_lineage_settings = lineage_configuration.value.crawler_lineage_settings
    }
  }

  dynamic "lake_formation_configuration" {
    for_each = var.crawler_lake_formation_configuration != null ? [var.crawler_lake_formation_configuration] : []
    content {
      use_lake_formation_credentials = lake_formation_configuration.value.use_lake_formation_credentials
      account_id                     = lake_formation_configuration.value.account_id
    }
  }

  tags = var.tags

  depends_on = [
    aws_glue_catalog_database.glue_catalog_db,
    module.glue_role,
  ]


}

################################################################################
# GLUE WORKFLOW (optional)
################################################################################

resource "aws_glue_workflow" "glue_pipeline" {
  count = var.create_workflow ? 1 : 0

  name        = local.effective_workflow_name
  description = var.workflow_description

  max_concurrent_runs    = var.workflow_max_concurrent_runs
  default_run_properties = var.workflow_default_run_properties

  tags = var.tags


}

################################################################################
# GLUE TRIGGER (optional)
################################################################################

resource "aws_glue_trigger" "glue_schedule" {
  count = var.create_trigger ? 1 : 0

  name          = local.effective_trigger_name
  type          = var.trigger_type
  description   = var.trigger_description
  schedule      = var.trigger_type == "SCHEDULED" ? var.trigger_schedule : null
  workflow_name = var.create_workflow ? aws_glue_workflow.glue_pipeline[0].name : var.trigger_workflow_name
  enabled       = var.trigger_enabled

  dynamic "actions" {
    for_each = local.all_trigger_actions
    content {
      job_name  = actions.value.job_name
      arguments = actions.value.arguments
      timeout   = actions.value.timeout
    }
  }

  dynamic "predicate" {
    for_each = var.trigger_type == "CONDITIONAL" && var.trigger_predicate != null ? [var.trigger_predicate] : []
    content {
      logical = predicate.value.logical

      dynamic "conditions" {
        for_each = predicate.value.conditions
        content {
          logical_operator = conditions.value.logical_operator
          job_name         = conditions.value.job_name
          state            = conditions.value.state
          crawler_name     = conditions.value.crawler_name
          crawl_state      = conditions.value.crawl_state
        }
      }
    }
  }

  tags = var.tags

  depends_on = [
    aws_glue_job.glue_etl_job,
    aws_glue_workflow.glue_pipeline,
  ]

}
