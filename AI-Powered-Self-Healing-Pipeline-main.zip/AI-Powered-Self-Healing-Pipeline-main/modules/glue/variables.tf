################################################################################
# GLUE JOB — IDENTITY
################################################################################

variable "job_name" {
  description = <<-EOT
    Name of the AWS Glue ETL job. Must be unique within the AWS account and region.
    Used as the base name for the execution role, security configuration, and
    CloudWatch log group.
  EOT
  type        = string

  validation {
    condition     = length(trimspace(var.job_name)) > 0
    error_message = "'job_name' must not be empty."
  }
}

variable "description" {
  description = "Human-readable description of what this Glue job does."
  type        = string
  default     = ""
}

################################################################################
# JOB SOURCE DIRECTORY & S3 UPLOAD
#
# The module reads the job folder that the dev team creates locally and uploads
# its contents to S3, mirroring the exact folder structure.
#
# Expected local layout inside job_source_dir:
#   job/              – main Glue ETL script  (required)
#   packages/         – pre-built packages (.zip .whl .py .egg)  (optional)
#   extra-py-files/   – helper Python modules (.py files)        (optional)
#
# Corresponding S3 layout under script_bucket_name:
#   <job_source_dir>/job/                  ← script uploaded here
#   <job_source_dir>/packages/             ← all packages/ files (if folder exists)
#   <job_source_dir>/extra-py-files/       ← all extra-py-files/ files (if folder exists)
#   <job_source_dir>/temporary/            ← --TempDir (auto)
#   <job_source_dir>/sparkHistoryLogs/     ← --spark-event-logs-path (auto)
#
# --extra-py-files is built automatically from .py/.zip/.whl/.egg files found
# in packages/ and extra-py-files/. Other files (e.g. requirements.txt) are
# uploaded to S3 for reference but excluded from --extra-py-files.
# If neither folder exists, --extra-py-files is omitted entirely.
################################################################################

variable "job_source_dir" {
  description = <<-EOT
    Path to the job's root source directory, relative to the Terraform root.

    Example: "glue-jobs/bala-test-2"

    The module expects this structure inside:
      job/            – Glue ETL script
      packages/       – pre-built packages (optional; upload + --extra-py-files)
      extra-py-files/ – helper Python modules (optional; upload + --extra-py-files)
  EOT
  type        = string

  validation {
    condition     = length(trimspace(var.job_source_dir)) > 0
    error_message = "'job_source_dir' must not be empty."
  }
}

variable "script_filename" {
  description = <<-EOT
    Name of the main Glue ETL script file inside the job/ subfolder.

    Example: "test_glue_job.py"
  EOT
  type        = string

  validation {
    condition     = length(trimspace(var.script_filename)) > 0
    error_message = "'script_filename' must not be empty."
  }
}

variable "script_bucket_name" {
  description = <<-EOT
    Name of the S3 bucket where all job artefacts are uploaded.
    The bucket must already exist. The execution role is automatically granted
    scoped access to all paths under <job_source_dir>/ in this bucket.
  EOT
  type        = string

  validation {
    condition     = length(trimspace(var.script_bucket_name)) > 0
    error_message = "'script_bucket_name' must not be empty."
  }
}

################################################################################
# COMMAND / RUNTIME
################################################################################

variable "command_name" {
  description = <<-EOT
    Glue job command name.
      "glueetl"       – Spark ETL job  (Glue 2.0+)
      "pythonshell"   – Python shell job (no Spark)
      "gluestreaming" – Spark streaming job
  EOT
  type        = string
  default     = "glueetl"

  validation {
    condition     = contains(["glueetl", "pythonshell", "gluestreaming"], var.command_name)
    error_message = "'command_name' must be one of: glueetl, pythonshell, gluestreaming."
  }
}

variable "python_version" {
  description = <<-EOT
    Python version for the Glue job.
      "3"   – Python 3 (Glue 2.0 / 3.0 ETL and Python shell)
      "3.9" – Python 3.9 (Python shell only)
  EOT
  type        = string
  default     = "3"
}

variable "glue_version" {
  description = <<-EOT
    AWS Glue version string. Controls the Spark and Python versions available.
      "5.0" – Spark 3.5, Python 3.11 (latest, recommended)
      "4.0" – Spark 3.3, Python 3.10
      "3.0" – Spark 3.1, Python 3.7
      "2.0" – Spark 2.4, Python 3.7
    Python shell jobs always use "1.0" or "2.0".
  EOT
  type        = string
  default     = "5.0"
}

################################################################################
# WORKER CONFIG
################################################################################

variable "worker_type" {
  description = "Worker type for Spark ETL and streaming jobs. Ignored for Python shell jobsUse G-series for general-purpose ETL workloads and R-series for memory-intensive workloads like machine learning or graph processing."
  type        = string
  default     = "G.1X"

  validation {
    condition = var.worker_type == null || contains(
      ["G.025X", "G.1X", "G.2X", "G.4X", "G.8X", "G.12X", "G.16X", "R.1X", "R.2X", "R.4X", "R.8X", "Z.2X"],
      var.worker_type
    )
    error_message = "'worker_type' must be one of: G.025X, G.1X, G.2X, G.4X, G.8X, G.12X, G.16X, R.1X, R.2X, R.4X, R.8X, Z.2X, or null."
  }
}

variable "number_of_workers" {
  description = <<-EOT
    Number of workers instantiated when the job runs. Must be >= 2 for ETL jobs.
    Not applicable to Python shell jobs (use max_capacity instead).
  EOT
  type        = number
  default     = 2

  validation {
    condition     = var.number_of_workers == null || var.number_of_workers >= 1
    error_message = "'number_of_workers' must be >= 1."
  }
}

variable "max_capacity" {
  description = <<-EOT
    DPU capacity for Python shell jobs or legacy ETL jobs that use DPUs instead of
    workers. Standard Python shell values: 0.0625 (1/16 DPU) or 1.0 (1 DPU).
    Mutually exclusive with worker_type / number_of_workers.
    Leave null for Spark ETL/streaming jobs.
  EOT
  type        = number
  default     = null
}

################################################################################
# EXECUTION CONTROLS
################################################################################

variable "max_retries" {
  description = "Maximum number of times Glue retries the job if it fails. Range: 0–10."
  type        = number
  default     = 0

  validation {
    condition     = var.max_retries >= 0 && var.max_retries <= 10
    error_message = "'max_retries' must be between 0 and 10."
  }
}

variable "timeout" {
  description = <<-EOT
    Job timeout in minutes. The job is interrupted and marked as TIMEOUT when
    this limit is exceeded. Range: 1–10080 (7 days).
    Leave null to use the Glue default (2880 minutes / 48 hours).
  EOT
  type        = number
  default     = 2800

  validation {
    condition     = var.timeout == null || (var.timeout >= 1 && var.timeout <= 10080)
    error_message = "'timeout' must be between 1 and 10080 minutes, or null."
  }
}

variable "max_concurrent_runs" {
  description = "Maximum number of concurrent runs allowed for the job. Range: 1–999."
  type        = number
  default     = 2

  validation {
    condition     = var.max_concurrent_runs >= 1 && var.max_concurrent_runs <= 999
    error_message = "'max_concurrent_runs' must be between 1 and 999."
  }
}

variable "execution_class" {
  description = <<-EOT
    Execution class for the job.
      "STANDARD" – standard job priority (default)
      "FLEX"     – lower-priority / spot-backed; cheaper but may be delayed.
    Use FLEX for non-time-critical batch jobs to reduce cost.
  EOT
  type        = string
  default     = "STANDARD"

  validation {
    condition     = contains(["STANDARD", "FLEX"], var.execution_class)
    error_message = "'execution_class' must be 'STANDARD' or 'FLEX'."
  }
}

variable "job_run_queuing_enabled" {
  description = <<-EOT
    When true, job runs that exceed max_concurrent_runs are queued rather than
    immediately failing. Recommended for high-throughput pipelines.
  EOT
  type        = bool
  default     = false
}

################################################################################
# RUNTIME ARGUMENTS
################################################################################

variable "default_arguments" {
  description = <<-EOT
    Map of default job arguments passed to every run. Keys must be prefixed
    with "--". These are merged with the module's built-in arguments
    (--enable-metrics, --continuous-log-logGroup, --extra-py-files, etc.)
    and can be overridden per-run by the caller.

    Example:
      default_arguments = {
        "--job-bookmark-option" = "job-bookmark-enable"
        "--MY_PARAM"            = "my-value"
      }
  EOT
  type        = map(string)
  default     = {}
}

variable "non_overridable_arguments" {
  description = <<-EOT
    Map of job arguments that cannot be overridden by the caller at runtime.
    Same key format as default_arguments.
  EOT
  type        = map(string)
  default     = {}
}

################################################################################
# CONNECTIONS
################################################################################

variable "connections" {
  description = <<-EOT
    List of existing Glue connection names to attach to the job (e.g. JDBC,
    Kafka, or custom network connections). These must already exist in the
    same catalog. Leave empty when no connections are needed.
  EOT
  type        = list(string)
  default     = []
}

################################################################################
# SECURITY & ENCRYPTION
################################################################################

variable "security_configuration_name" {
  description = <<-EOT
    Name of an existing Glue security configuration to attach to the job.
    Provides at-rest encryption for CloudWatch logs, job bookmarks, and S3
    job artifacts. Leave null to skip (not recommended for production).
  EOT
  type        = string
  default     = null
}

variable "create_security_configuration" {
  description = <<-EOT
    When true, the module creates a Glue security configuration named
    "<job_name>-sec-config" and attaches it to the job.
    If var.security_configuration_name is also set, that pre-existing config
    is used instead and this flag is ignored.
  EOT
  type        = bool
  default     = false
}

variable "s3_kms_key_arn" {
  description = <<-EOT
    ARN of the KMS key used to encrypt S3-backed Glue artefacts (job bookmarks,
    temp files) when create_security_configuration = true.
    Leave null to use SSE-S3 (AES-256) for S3 encryption.
  EOT
  type        = string
  default     = null
}

variable "cloudwatch_kms_key_arn" {
  description = <<-EOT
    ARN of the KMS key used to encrypt Glue CloudWatch log streams when
    create_security_configuration = true. Leave null to use default CWL encryption.
  EOT
  type        = string
  default     = null
}

variable "job_bookmarks_kms_key_arn" {
  description = <<-EOT
    ARN of the KMS key used to encrypt Glue job bookmark state when
    create_security_configuration = true. Leave null to skip bookmark encryption.
  EOT
  type        = string
  default     = null
}

################################################################################
# IAM
################################################################################

variable "create_iam_role" {
  description = <<-EOT
    When true, the module creates a dedicated IAM execution role for the Glue job
    and attaches it. Set to false and supply var.iam_role_arn to bring your own role.
  EOT
  type        = bool
  default     = true
}

variable "iam_role_arn" {
  description = <<-EOT
    ARN of an existing IAM role to use as the Glue execution role.
    Only used when var.create_iam_role = false.
    The role must have a trust policy that allows "glue.amazonaws.com" to assume it.
  EOT
  type        = string
  default     = null
}

variable "iam_role_path" {
  description = "IAM path for the Glue execution role. Must begin and end with '/'."
  type        = string
  default     = "/"

  validation {
    condition     = startswith(var.iam_role_path, "/") && endswith(var.iam_role_path, "/")
    error_message = "'iam_role_path' must begin and end with a forward slash."
  }
}

variable "permission_boundary_arn" {
  description = <<-EOT
    ARN of an IAM permission boundary policy to attach to the Glue execution role.
    Enforces maximum permissions (AWS best practice for delegated administration).
    Leave null to skip.
  EOT
  type        = string
  default     = null
}

variable "extra_customer_managed_policies" {
  description = <<-EOT
    Map of additional customer-managed IAM policies to create and attach to the
    Glue execution role. Merged with the module's built-in baseline policy.

    The key "glue_baseline" is reserved by this module.

    Example:
      extra_customer_managed_policies = {
        s3_read = {
          name   = "my-glue-job-s3-input-read"
          policy = data.aws_iam_policy_document.s3_input_read.json
        }
      }
  EOT
  type = map(object({
    name        = string
    description = optional(string, "")
    path        = optional(string, "/")
    policy      = string
  }))
  default = {}
}

variable "extra_customer_managed_policy_arns" {
  description = "List of pre-existing customer-managed policy ARNs to attach to the Glue execution role."
  type        = list(string)
  default     = []
}

variable "extra_aws_managed_policy_arns" {
  description = <<-EOT
    List of AWS-managed policy ARNs to attach to the Glue execution role.
    Prefer narrow customer-managed policies over broad AWS-managed ones.
  EOT
  type        = list(string)
  default     = []
}

variable "extra_inline_policies" {
  description = "Map of inline policy JSON documents to embed in the Glue execution role."
  type        = map(string)
  default     = {}
}

################################################################################
# CLOUDWATCH LOGGING
################################################################################

variable "log_retention_in_days" {
  description = <<-EOT
    Number of days to retain Glue job CloudWatch logs.
    Common values: 7, 14, 30, 60, 90, 180, 365. 0 = never expire (not recommended).
  EOT
  type        = number
  default     = 30

  validation {
    condition = contains(
      [0, 1, 3, 5, 7, 14, 30, 60, 90, 120, 150, 180, 365, 400, 545, 731, 1096, 1827, 2192, 2557, 2922, 3288, 3653],
      var.log_retention_in_days
    )
    error_message = "'log_retention_in_days' must be a valid CloudWatch Logs retention value."
  }
}

variable "log_kms_key_id" {
  description = "ARN or ID of the KMS key used to encrypt the Glue CloudWatch log group. Leave null for default encryption."
  type        = string
  default     = null
}

################################################################################
# CATALOG DATABASE
################################################################################

variable "create_catalog_database" {
  description = "When true, creates a Glue Catalog database associated with this job."
  type        = bool
  default     = false
}

variable "catalog_database_name" {
  description = <<-EOT
    Name of the Glue Catalog database to create. Required when
    create_catalog_database = true. Ignored otherwise.
  EOT
  type        = string
  default     = null
}

variable "catalog_database_description" {
  description = "Description for the Glue Catalog database."
  type        = string
  default     = ""
}

variable "catalog_id" {
  description = "Catalog ID (AWS account ID). Defaults to the current account when null."
  type        = string
  default     = null
}

################################################################################
# CRAWLER
################################################################################

variable "create_crawler" {
  description = "When true, creates a Glue crawler alongside the job."
  type        = bool
  default     = false
}

variable "crawler_name" {
  description = "Name of the Glue crawler. Defaults to '<job_name>-crawler' when null."
  type        = string
  default     = null
}

variable "crawler_description" {
  description = "Description of the Glue crawler."
  type        = string
  default     = ""
}

variable "crawler_role_arn" {
  description = <<-EOT
    IAM role ARN for the crawler. Defaults to the module-created Glue execution
    role when null. Supply a different ARN if the crawler needs distinct permissions.
  EOT
  type        = string
  default     = null
}

variable "crawler_database_name" {
  description = <<-EOT
    Glue Catalog database name the crawler populates.
    Defaults to var.catalog_database_name when null and create_catalog_database = true.
    Required when create_crawler = true and create_catalog_database = false.
  EOT
  type        = string
  default     = null
}

variable "crawler_classifiers" {
  description = "List of custom Glue classifier names to use during crawling."
  type        = list(string)
  default     = []
}

variable "crawler_table_prefix" {
  description = "String prefix added to all table names created by this crawler."
  type        = string
  default     = null
}

variable "crawler_configuration" {
  description = "JSON string containing crawler configuration overrides."
  type        = string
  default     = null
}

variable "crawler_schedule" {
  description = <<-EOT
    Cron expression for the crawler schedule, e.g. "cron(0 12 * * ? *)".
    Leave null to disable automatic scheduling (on-demand only).
  EOT
  type        = string
  default     = null
}

variable "crawler_s3_targets" {
  description = <<-EOT
    List of S3 paths for the crawler to scan.

    Example:
      crawler_s3_targets = [
        { path = "s3://my-bucket/raw/", exclusions = ["**/_temporary/**"] }
      ]
  EOT
  type = list(object({
    path            = string
    exclusions      = optional(list(string), [])
    connection_name = optional(string)
  }))
  default = []
}

variable "crawler_jdbc_targets" {
  description = <<-EOT
    List of JDBC targets for the crawler.

    Example:
      crawler_jdbc_targets = [
        { connection_name = "my-rds-conn", path = "my_db/public/%", exclusions = [] }
      ]
  EOT
  type = list(object({
    connection_name = string
    path            = string
    exclusions      = optional(list(string), [])
  }))
  default = []
}

variable "crawler_recrawl_policy" {
  description = <<-EOT
    Recrawl policy for the crawler.
      "CRAWL_EVERYTHING"       – recrawl all discovered data (default)
      "CRAWL_NEW_FOLDERS_ONLY" – only crawl newly added S3 partitions
      "CRAWL_EVENT_MODE"       – event-driven crawl using S3 notifications
  EOT
  type = object({
    recrawl_behavior = string
  })
  default = null
}

variable "crawler_schema_change_policy" {
  description = <<-EOT
    Defines how the crawler handles schema changes.
    update_behavior: "UPDATE_IN_DATABASE" | "LOG"
    delete_behavior: "DEPRECATE_IN_DATABASE" | "DELETE_FROM_DATABASE" | "LOG"
  EOT
  type = object({
    update_behavior = optional(string, "UPDATE_IN_DATABASE")
    delete_behavior = optional(string, "DEPRECATE_IN_DATABASE")
  })
  default = null
}

variable "crawler_lineage_configuration" {
  description = "Lineage settings for the crawler. crawler_lineage_settings: 'ENABLE' | 'DISABLE'."
  type = object({
    crawler_lineage_settings = string
  })
  default = null
}

variable "crawler_lake_formation_configuration" {
  description = "Lake Formation configuration for the crawler."
  type = object({
    use_lake_formation_credentials = optional(bool, false)
    account_id                     = optional(string)
  })
  default = null
}

################################################################################
# TRIGGER
################################################################################

variable "create_trigger" {
  description = "When true, creates a Glue trigger for the job."
  type        = bool
  default     = false
}

variable "trigger_name" {
  description = "Name of the Glue trigger. Defaults to '<job_name>-trigger' when null."
  type        = string
  default     = null
}

variable "trigger_type" {
  description = <<-EOT
    Trigger type.
      "SCHEDULED"   – run on a cron schedule
      "CONDITIONAL" – run when upstream jobs/crawlers meet conditions
      "ON_DEMAND"   – manually triggered
      "EVENT"       – triggered by EventBridge events
  EOT
  type        = string
  default     = "SCHEDULED"

  validation {
    condition     = contains(["SCHEDULED", "CONDITIONAL", "ON_DEMAND", "EVENT"], var.trigger_type)
    error_message = "'trigger_type' must be one of: SCHEDULED, CONDITIONAL, ON_DEMAND, EVENT."
  }
}

variable "trigger_description" {
  description = "Description of the Glue trigger."
  type        = string
  default     = ""
}

variable "trigger_schedule" {
  description = <<-EOT
    Cron expression for SCHEDULED triggers, e.g. "cron(0 2 * * ? *)".
    Required when trigger_type = 'SCHEDULED'.
  EOT
  type        = string
  default     = null
}

variable "trigger_enabled" {
  description = "Whether the trigger is enabled on creation."
  type        = bool
  default     = true
}

variable "trigger_workflow_name" {
  description = "Glue workflow name to associate the trigger with."
  type        = string
  default     = null
}

variable "trigger_actions" {
  description = <<-EOT
    List of additional actions the trigger fires beyond the job itself.
    The module always adds the Glue job as the first action automatically.

    Example:
      trigger_actions = [
        { job_name = "downstream-job", arguments = { "--extra-param" = "value" } }
      ]
  EOT
  type = list(object({
    job_name  = optional(string)
    arguments = optional(map(string), {})
    timeout   = optional(number)
  }))
  default = []
}

variable "trigger_predicate" {
  description = <<-EOT
    Predicate for CONDITIONAL triggers. Defines which job states trigger execution.

    Example:
      trigger_predicate = {
        logical = "AND"
        conditions = [
          { job_name = "upstream-job", state = "SUCCEEDED", logical_operator = "EQUALS" }
        ]
      }
  EOT
  type = object({
    logical = optional(string, "AND")
    conditions = list(object({
      logical_operator = optional(string, "EQUALS")
      job_name         = optional(string)
      state            = optional(string)
      crawler_name     = optional(string)
      crawl_state      = optional(string)
    }))
  })
  default = null
}

################################################################################
# WORKFLOW
################################################################################

variable "create_workflow" {
  description = "When true, creates a Glue workflow and associates the trigger with it."
  type        = bool
  default     = false
}

variable "workflow_name" {
  description = "Name of the Glue workflow. Defaults to '<job_name>-workflow' when null."
  type        = string
  default     = null
}

variable "workflow_description" {
  description = "Description of the Glue workflow."
  type        = string
  default     = ""
}

variable "workflow_max_concurrent_runs" {
  description = "Maximum concurrent runs for the workflow. Leave null for unlimited."
  type        = number
  default     = null
}

variable "workflow_default_run_properties" {
  description = "Default run properties passed to all jobs in the workflow."
  type        = map(string)
  default     = {}
}

################################################################################
# TAGS
################################################################################

variable "tags" {
  description = <<-EOT
    Map of tags applied to all resources created by this module.
    Merge with your common_tags in the caller:

      tags = merge(local.common_tags, { Component = "data-pipeline" })
  EOT
  type        = map(string)
  default     = {}
}
