################################################################################
# MAIN QUEUE
################################################################################

output "queue_arn" {
  description = "ARN of the SQS queue."
  value       = aws_sqs_queue.sqs_queue.arn
}

output "queue_id" {
  description = "URL of the SQS queue (same as queue_url)."
  value       = aws_sqs_queue.sqs_queue.id
}

output "queue_url" {
  description = "URL of the SQS queue."
  value       = aws_sqs_queue.sqs_queue.url
}

output "queue_name" {
  description = "Name of the SQS queue as created in AWS."
  value       = aws_sqs_queue.sqs_queue.name
}

################################################################################
# DEAD-LETTER QUEUE
################################################################################

output "dlq_arn" {
  description = "ARN of the dead-letter queue. Null when create_dlq = false."
  value       = var.create_dlq ? aws_sqs_queue.sqs_dlq[0].arn : null
}

output "dlq_id" {
  description = "URL of the dead-letter queue. Null when create_dlq = false."
  value       = var.create_dlq ? aws_sqs_queue.sqs_dlq[0].id : null
}

output "dlq_url" {
  description = "URL of the dead-letter queue. Null when create_dlq = false."
  value       = var.create_dlq ? aws_sqs_queue.sqs_dlq[0].url : null
}

output "dlq_name" {
  description = "Name of the dead-letter queue. Null when create_dlq = false."
  value       = var.create_dlq ? aws_sqs_queue.sqs_dlq[0].name : null
}

################################################################################
# KMS KEY
################################################################################

output "kms_key_arn" {
  description = <<-EOT
    ARN of the KMS key used to encrypt this queue.
    Either the module-managed CMK or the caller-supplied key.
  EOT
  value       = local.kms_key_arn
}

output "kms_key_id" {
  description = "ID of the module-managed KMS CMK. Null when kms_key_arn is supplied."
  value       = length(aws_kms_key.sqs_encryption) > 0 ? aws_kms_key.sqs_encryption[0].key_id : null
}

output "kms_alias_name" {
  description = "KMS alias name for the module-managed CMK. Null when kms_key_arn is supplied."
  value       = length(aws_kms_alias.sqs_encryption) > 0 ? aws_kms_alias.sqs_encryption[0].name : null
}
