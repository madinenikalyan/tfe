# `modules/sqs` — Production-Ready SQS Queue Module

A Terraform module for provisioning an AWS SQS **single queue** with KMS CMK
encryption, optional dead-letter queue (DLQ), FIFO support, and resource-based policies.

---

## Features

| Feature | Details |
|---|---|
| **KMS encryption** | Dedicated CMK auto-created per queue (annual rotation always on); or reuse a caller-supplied key |
| **Dead-letter queue** | Companion DLQ created by default with same encryption and redrive allow policy |
| **FIFO queues** | Optional strict ordering, exactly-once processing, deduplication scope, and high-throughput mode |
| **Long polling** | Enabled by default (`receive_wait_time_seconds = 20`) to reduce cost |
| **Queue policy** | Optional IAM resource policy for cross-account/cross-service access |
| **DLQ policy** | Separate optional policy for the dead-letter queue |
| **SNS integration** | KMS key policy includes SNS service permissions for SNS → SQS message flow |

---

## Design Decisions

### One Queue per Module Call

Each module invocation creates exactly one queue (plus an optional DLQ). This keeps
the interface simple, limits the blast radius, and allows per-queue KMS/IAM scoping.
For multiple queues, invoke the module once per queue.

### Dead-Letter Queue by Default

A companion DLQ is created by default (`create_dlq = true`) with 14-day message
retention (maximum) and a redrive allow policy that restricts source queues to only
the main queue. Messages that fail processing after `max_receive_count` (default 5)
attempts are automatically moved to the DLQ.

### KMS Encryption Always On

Server-side encryption is enforced — plaintext queues are never created. When
`kms_key_arn` is null the module provisions a dedicated CMK with annual key
rotation enabled. The key policy grants `sqs.amazonaws.com` and `sns.amazonaws.com`
the minimum required permissions so that SNS → SQS message routing works with
encrypted queues out of the box.

### Long Polling by Default

`receive_wait_time_seconds` defaults to 20 (maximum) to eliminate empty receives
and reduce SQS API costs. Set to 0 for short polling if your consumer requires it.

### No Data Blocks

`account_id` and `aws_region` are passed as variables rather than looked up via
`data "aws_caller_identity"` / `data "aws_region"`. This avoids duplicate data-source
calls when the root module already has them.

---

## Usage

### Minimal — queue with DLQ

```hcl
module "processing_queue" {
  source = "./modules/sqs"

  name = "sales-automation-processing"

  account_id = data.aws_caller_identity.current.account_id
  aws_region = data.aws_region.current.name

  tags = local.common_tags
}
```

### Queue without DLQ (using external DLQ)

```hcl
module "lightweight_queue" {
  source = "./modules/sqs"

  name       = "event-ingestion"
  create_dlq = false

  redrive_policy = jsonencode({
    deadLetterTargetArn = module.shared_dlq.queue_arn
    maxReceiveCount     = 3
  })

  account_id = data.aws_caller_identity.current.account_id
  aws_region = data.aws_region.current.name

  tags = local.common_tags
}
```

### FIFO queue with external KMS key

```hcl
module "ordered_queue" {
  source = "./modules/sqs"

  name                        = "transaction-events"
  fifo_queue                  = true
  content_based_deduplication = true
  fifo_throughput_limit       = "perMessageGroupId"
  kms_key_arn                 = module.shared_kms.key_arn

  account_id = data.aws_caller_identity.current.account_id
  aws_region = data.aws_region.current.name

  tags = local.common_tags
}
```

### Queue with SNS subscription policy

```hcl
module "sns_target_queue" {
  source = "./modules/sqs"

  name         = "notification-processor"
  queue_policy = data.aws_iam_policy_document.allow_sns_publish.json

  visibility_timeout_seconds = 300
  max_receive_count          = 10

  account_id = data.aws_caller_identity.current.account_id
  aws_region = data.aws_region.current.name

  tags = local.common_tags
}
```

---

## Inputs

| Variable | Type | Default | Description |
|---|---|---|---|
| `account_id` | `string` | required | AWS account ID (12-digit) |
| `aws_region` | `string` | required | AWS region name (e.g. `us-east-1`) |
| `aws_partition` | `string` | `"aws"` | AWS partition for ARN construction |
| `name` | `string` | required | Queue name (1–80 chars) |
| `fifo_queue` | `bool` | `false` | Create a FIFO queue |
| `content_based_deduplication` | `bool` | `false` | Content-based deduplication (FIFO only) |
| `deduplication_scope` | `string` | `"queue"` | Deduplication scope: `messageGroup` or `queue` |
| `fifo_throughput_limit` | `string` | `"perQueue"` | FIFO throughput limit: `perQueue` or `perMessageGroupId` |
| `visibility_timeout_seconds` | `number` | `30` | Message visibility timeout (0–43200s) |
| `message_retention_seconds` | `number` | `345600` | Message retention (60–1209600s, default 4 days) |
| `delay_seconds` | `number` | `0` | Delivery delay (0–900s) |
| `max_message_size` | `number` | `262144` | Max message size in bytes (1024–262144) |
| `receive_wait_time_seconds` | `number` | `20` | Long polling duration (0–20s) |
| `kms_key_arn` | `string` | `null` | Existing KMS CMK ARN; null creates a dedicated CMK |
| `kms_key_deletion_window_in_days` | `number` | `30` | KMS key deletion wait (7–30 days) |
| `kms_data_key_reuse_period_seconds` | `number` | `300` | Data key reuse period (60–86400s) |
| `create_dlq` | `bool` | `true` | Create a companion dead-letter queue |
| `max_receive_count` | `number` | `5` | Max receives before DLQ redrive (1–1000) |
| `dlq_message_retention_seconds` | `number` | `1209600` | DLQ message retention (default 14 days max) |
| `dlq_visibility_timeout_seconds` | `number` | `30` | DLQ visibility timeout |
| `redrive_policy` | `string` | `null` | JSON redrive policy for external DLQ (when `create_dlq = false`) |
| `queue_policy` | `string` | `null` | JSON IAM resource policy for the main queue |
| `dlq_queue_policy` | `string` | `null` | JSON IAM resource policy for the DLQ |
| `tags` | `map(string)` | `{}` | Tags applied to all resources |

---

## Outputs

| Output | Description |
|---|---|
| `queue_arn` | ARN of the SQS queue |
| `queue_id` | URL of the SQS queue |
| `queue_url` | URL of the SQS queue |
| `queue_name` | Name of the SQS queue |
| `dlq_arn` | ARN of the DLQ (null when `create_dlq = false`) |
| `dlq_id` | URL of the DLQ (null when `create_dlq = false`) |
| `dlq_url` | URL of the DLQ (null when `create_dlq = false`) |
| `dlq_name` | Name of the DLQ (null when `create_dlq = false`) |
| `kms_key_arn` | ARN of the KMS key (module-managed or caller-supplied) |
| `kms_key_id` | ID of the module-managed KMS CMK (null when caller supplies key) |
| `kms_alias_name` | KMS alias name (null when caller supplies key) |

---

## Notes

- **FIFO suffix**: When `fifo_queue = true`, the module appends `.fifo` to both the
  queue and DLQ names automatically if not already present.
- **Caller-managed KMS**: When `kms_key_arn` is supplied, no CMK is created. The
  caller is responsible for KMS key policy and lifecycle. Ensure the key policy
  allows `sqs.amazonaws.com` and `sns.amazonaws.com` if SNS integration is needed.
- **Visibility timeout**: Should be at least as long as the consumer's processing time.
  For Lambda consumers, set it to 6x the Lambda timeout as recommended by AWS.
- **DLQ monitoring**: Always set up a CloudWatch alarm on `ApproximateNumberOfMessagesVisible`
  for the DLQ to catch processing failures early.
