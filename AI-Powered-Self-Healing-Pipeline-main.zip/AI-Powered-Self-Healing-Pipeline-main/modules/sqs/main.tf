################################################################################
# SQS — Production-Ready Queue Module
#
# Creates a production-ready AWS SQS queue with:
#   - KMS encryption always enabled (dedicated CMK or caller-supplied key)
#   - Optional dead-letter queue (DLQ) with configurable max receive count
#   - Optional FIFO queue support with content-based deduplication
#   - Optional queue policy for cross-account / cross-service access
#   - Server-side encryption enforced — plaintext queues are never created
#   - Configurable visibility timeout, message retention, and delay
#   - Long polling enabled by default (receive_wait_time_seconds = 20)
#
# DESIGN NOTE — single queue per invocation:
#   This module follows the same pattern as secrets-manager and SNS: one
#   resource per module call. For multiple queues, invoke the module once
#   per queue. This keeps the blast radius small and allows per-queue
#   IAM/KMS scoping.
#
# DESIGN NOTE — dead-letter queue:
#   When create_dlq = true (default), a companion DLQ is created with the
#   same encryption settings. Messages that fail processing after
#   max_receive_count attempts are moved to the DLQ automatically.
#   The DLQ retains messages for 14 days (maximum) by default.
#
# DESIGN NOTE — KMS encryption:
#   When kms_key_arn is null (default), a dedicated CMK is created with
#   annual key rotation enabled. The key policy grants sqs.amazonaws.com
#   the minimum required permissions. Pass an existing key ARN to skip
#   CMK creation and reuse a shared key.
#
# DESIGN NOTE — long polling:
#   receive_wait_time_seconds defaults to 20 (maximum) to reduce empty
#   receives and lower cost. Set to 0 for short polling if required.
################################################################################

################################################################################
# LOCALS
################################################################################

locals {
  kms_key_arn = var.kms_key_arn != null ? var.kms_key_arn : aws_kms_key.sqs_encryption[0].arn
  kms_key_id  = var.kms_key_arn != null ? var.kms_key_arn : aws_kms_key.sqs_encryption[0].key_id

  queue_name = var.fifo_queue ? (endswith(var.name, ".fifo") ? var.name : "${var.name}.fifo") : var.name
  dlq_name   = var.fifo_queue ? (endswith(var.name, ".fifo") ? "${trimsuffix(var.name, ".fifo")}-dlq.fifo" : "${var.name}-dlq.fifo") : "${var.name}-dlq"
}

################################################################################
# KMS KEY — one CMK per queue (unless caller supplies their own key)
#
# Key policy grants:
#   - Root account: full administration (AWS requirement)
#   - sqs.amazonaws.com: GenerateDataKey / Decrypt for envelope encryption
################################################################################

data "aws_iam_policy_document" "sqs_kms_policy" {
  count = var.kms_key_arn == null ? 1 : 0

  statement {
    sid    = "EnableRootAccountAdmin"
    effect = "Allow"
    principals {
      type        = "AWS"
      identifiers = ["arn:${var.aws_partition}:iam::${var.account_id}:root"]
    }
    actions   = ["kms:*"]
    resources = ["*"]
  }

  statement {
    sid    = "AllowSQSServiceEncryption"
    effect = "Allow"
    principals {
      type        = "Service"
      identifiers = ["sqs.amazonaws.com"]
    }
    actions = [
      "kms:GenerateDataKey*",
      "kms:Decrypt",
    ]
    resources = ["*"]
    condition {
      test     = "StringEquals"
      variable = "kms:CallerAccount"
      values   = [var.account_id]
    }
  }

  # Allow SNS to use this key when publishing to an encrypted SQS queue.
  statement {
    sid    = "AllowSNSServiceEncryption"
    effect = "Allow"
    principals {
      type        = "Service"
      identifiers = ["sns.amazonaws.com"]
    }
    actions = [
      "kms:GenerateDataKey*",
      "kms:Decrypt",
    ]
    resources = ["*"]
    condition {
      test     = "StringEquals"
      variable = "kms:CallerAccount"
      values   = [var.account_id]
    }
  }
}

resource "aws_kms_key" "sqs_encryption" {
  count = var.kms_key_arn == null ? 1 : 0

  description              = "KMS CMK for SQS queue: ${var.name}"
  key_usage                = "ENCRYPT_DECRYPT"
  customer_master_key_spec = "SYMMETRIC_DEFAULT"
  deletion_window_in_days  = var.kms_key_deletion_window_in_days
  enable_key_rotation      = true
  multi_region             = false
  policy                   = data.aws_iam_policy_document.sqs_kms_policy[0].json

  tags = merge({ Name = "${var.name}-sqs-cmk" }, var.tags)
}

resource "aws_kms_alias" "sqs_encryption" {
  count = var.kms_key_arn == null ? 1 : 0

  name          = "alias/${replace(var.name, "/", "-")}-sqs"
  target_key_id = aws_kms_key.sqs_encryption[0].key_id
}

################################################################################
# DEAD-LETTER QUEUE (optional)
#
# Created when create_dlq = true. Uses the same KMS key as the main queue.
# Retains messages for 14 days (maximum) by default so that failed messages
# are available for investigation.
################################################################################

resource "aws_sqs_queue" "sqs_dlq" {
  count = var.create_dlq ? 1 : 0

  name                        = local.dlq_name
  fifo_queue                  = var.fifo_queue
  content_based_deduplication = var.fifo_queue ? var.content_based_deduplication : null

  visibility_timeout_seconds = var.dlq_visibility_timeout_seconds
  message_retention_seconds  = var.dlq_message_retention_seconds
  delay_seconds              = 0
  receive_wait_time_seconds  = var.receive_wait_time_seconds

  # Encryption — same CMK as the main queue.
  kms_master_key_id                 = local.kms_key_arn
  kms_data_key_reuse_period_seconds = var.kms_data_key_reuse_period_seconds

  tags = merge({ Name = local.dlq_name }, var.tags)
}

################################################################################
# MAIN SQS QUEUE
################################################################################

resource "aws_sqs_queue" "sqs_queue" {
  name                        = local.queue_name
  fifo_queue                  = var.fifo_queue
  content_based_deduplication = var.fifo_queue ? var.content_based_deduplication : null
  deduplication_scope         = var.fifo_queue ? var.deduplication_scope : null
  fifo_throughput_limit       = var.fifo_queue ? var.fifo_throughput_limit : null

  visibility_timeout_seconds = var.visibility_timeout_seconds
  message_retention_seconds  = var.message_retention_seconds
  delay_seconds              = var.delay_seconds
  max_message_size           = var.max_message_size
  receive_wait_time_seconds  = var.receive_wait_time_seconds

  # Encryption — always enabled with CMK.
  kms_master_key_id                 = local.kms_key_arn
  kms_data_key_reuse_period_seconds = var.kms_data_key_reuse_period_seconds

  # Redrive policy — route failed messages to the DLQ.
  redrive_policy = var.create_dlq ? jsonencode({
    deadLetterTargetArn = aws_sqs_queue.sqs_dlq[0].arn
    maxReceiveCount     = var.max_receive_count
  }) : var.redrive_policy

  tags = merge({ Name = local.queue_name }, var.tags)
}

################################################################################
# DLQ REDRIVE ALLOW POLICY
#
# Restricts which source queues can use this DLQ. Only the main queue
# created by this module is allowed.
################################################################################

resource "aws_sqs_queue_redrive_allow_policy" "sqs_dlq_redrive_allow" {
  count = var.create_dlq ? 1 : 0

  queue_url = aws_sqs_queue.sqs_dlq[0].id

  redrive_allow_policy = jsonencode({
    redrivePermission = "byQueue"
    sourceQueueArns   = [aws_sqs_queue.sqs_queue.arn]
  })
}

################################################################################
# QUEUE POLICY (optional)
#
# Controls which AWS principals/services can send to or receive from the queue.
################################################################################

resource "aws_sqs_queue_policy" "sqs_queue_policy" {
  count = var.queue_policy != null ? 1 : 0

  queue_url = aws_sqs_queue.sqs_queue.id
  policy    = var.queue_policy
}

################################################################################
# DLQ POLICY (optional)
#
# Separate policy for the dead-letter queue if needed.
################################################################################

resource "aws_sqs_queue_policy" "sqs_dlq_policy" {
  count = var.create_dlq && var.dlq_queue_policy != null ? 1 : 0

  queue_url = aws_sqs_queue.sqs_dlq[0].id
  policy    = var.dlq_queue_policy
}
