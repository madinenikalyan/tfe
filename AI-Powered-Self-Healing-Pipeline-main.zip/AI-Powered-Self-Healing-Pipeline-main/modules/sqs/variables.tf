################################################################################
# AWS ACCOUNT & REGION — passed from root module
################################################################################

variable "account_id" {
  description = <<-EOT
    AWS account ID. Passed from the root module's data.aws_caller_identity.current.account_id.
    Used in KMS key policies.
  EOT
  type        = string

  validation {
    condition     = can(regex("^[0-9]{12}$", var.account_id))
    error_message = "'account_id' must be a 12-digit AWS account ID."
  }
}

variable "aws_region" {
  description = <<-EOT
    AWS region name (e.g. "us-east-1"). Passed from the root module's data.aws_region.current.name.
  EOT
  type        = string

  validation {
    condition     = can(regex("^[a-z]{2}-[a-z]+-[0-9]{1}$", var.aws_region))
    error_message = "'aws_region' must be a valid AWS region name (e.g. 'us-east-1')."
  }
}

variable "aws_partition" {
  description = "AWS partition for ARN construction (e.g. 'aws', 'aws-cn', 'aws-us-gov')."
  type        = string
  default     = "aws"
}

################################################################################
# QUEUE IDENTITY
################################################################################

variable "name" {
  description = <<-EOT
    Name of the SQS queue. For FIFO queues, ".fifo" suffix is appended
    automatically if not already present when fifo_queue = true.
  EOT
  type        = string

  validation {
    condition     = length(var.name) >= 1 && length(var.name) <= 80
    error_message = "'name' must be between 1 and 80 characters."
  }
}

################################################################################
# FIFO SETTINGS
################################################################################

variable "fifo_queue" {
  description = <<-EOT
    Whether to create a FIFO queue (strict message ordering, exactly-once processing).
    FIFO queue names must end in ".fifo" — the module appends this automatically.
  EOT
  type        = bool
  default     = false
}

variable "content_based_deduplication" {
  description = <<-EOT
    Enable content-based deduplication for FIFO queues.
    When true, SQS uses a SHA-256 hash of the message body for deduplication.
    Only applies when fifo_queue = true.
  EOT
  type        = bool
  default     = false
}

variable "deduplication_scope" {
  description = <<-EOT
    Deduplication scope for FIFO queues. Valid values: messageGroup, queue.
    Only applies when fifo_queue = true.
  EOT
  type        = string
  default     = "queue"

  validation {
    condition     = contains(["messageGroup", "queue"], var.deduplication_scope)
    error_message = "'deduplication_scope' must be 'messageGroup' or 'queue'."
  }
}

variable "fifo_throughput_limit" {
  description = <<-EOT
    FIFO throughput limit. Valid values: perQueue, perMessageGroupId.
    perMessageGroupId enables high-throughput mode for FIFO queues.
    Only applies when fifo_queue = true.
  EOT
  type        = string
  default     = "perQueue"

  validation {
    condition     = contains(["perQueue", "perMessageGroupId"], var.fifo_throughput_limit)
    error_message = "'fifo_throughput_limit' must be 'perQueue' or 'perMessageGroupId'."
  }
}

################################################################################
# QUEUE SETTINGS
################################################################################

variable "visibility_timeout_seconds" {
  description = <<-EOT
    Duration (in seconds) that a received message is hidden from subsequent
    retrieve requests. Should be at least as long as the consumer's processing time.
    Valid range: 0–43200 (12 hours).
  EOT
  type        = number
  default     = 30

  validation {
    condition     = var.visibility_timeout_seconds >= 0 && var.visibility_timeout_seconds <= 43200
    error_message = "'visibility_timeout_seconds' must be between 0 and 43200."
  }
}

variable "message_retention_seconds" {
  description = <<-EOT
    Duration (in seconds) that SQS retains a message.
    Valid range: 60 (1 minute) – 1209600 (14 days). Default: 345600 (4 days).
  EOT
  type        = number
  default     = 345600

  validation {
    condition     = var.message_retention_seconds >= 60 && var.message_retention_seconds <= 1209600
    error_message = "'message_retention_seconds' must be between 60 and 1209600."
  }
}

variable "delay_seconds" {
  description = <<-EOT
    Time (in seconds) that delivery of all messages is delayed.
    Valid range: 0–900 (15 minutes). Default: 0 (no delay).
  EOT
  type        = number
  default     = 0

  validation {
    condition     = var.delay_seconds >= 0 && var.delay_seconds <= 900
    error_message = "'delay_seconds' must be between 0 and 900."
  }
}

variable "max_message_size" {
  description = <<-EOT
    Maximum message size in bytes. Valid range: 1024–262144 (1 KB–256 KB).
    Default: 262144 (256 KB).
  EOT
  type        = number
  default     = 262144

  validation {
    condition     = var.max_message_size >= 1024 && var.max_message_size <= 262144
    error_message = "'max_message_size' must be between 1024 and 262144."
  }
}

variable "receive_wait_time_seconds" {
  description = <<-EOT
    Duration (in seconds) for long polling. Set to > 0 to enable long polling,
    which reduces cost by eliminating empty receives.
    Valid range: 0–20. Default: 20 (maximum long polling).
  EOT
  type        = number
  default     = 20

  validation {
    condition     = var.receive_wait_time_seconds >= 0 && var.receive_wait_time_seconds <= 20
    error_message = "'receive_wait_time_seconds' must be between 0 and 20."
  }
}

################################################################################
# ENCRYPTION
################################################################################

variable "kms_key_arn" {
  description = <<-EOT
    ARN of a KMS CMK for server-side encryption.
    When null (default), the module creates a dedicated CMK with annual key rotation.
    Pass an existing key ARN to reuse a shared KMS key.
  EOT
  type        = string
  default     = null
}

variable "kms_key_deletion_window_in_days" {
  description = "Waiting period (in days) before KMS key deletion. Valid range: 7–30."
  type        = number
  default     = 30

  validation {
    condition     = var.kms_key_deletion_window_in_days >= 7 && var.kms_key_deletion_window_in_days <= 30
    error_message = "'kms_key_deletion_window_in_days' must be between 7 and 30."
  }
}

variable "kms_data_key_reuse_period_seconds" {
  description = <<-EOT
    Duration (in seconds) that SQS reuses a data encryption key before calling
    KMS again. Valid range: 60–86400 (1 minute–24 hours). Default: 300 (5 minutes).
  EOT
  type        = number
  default     = 300

  validation {
    condition     = var.kms_data_key_reuse_period_seconds >= 60 && var.kms_data_key_reuse_period_seconds <= 86400
    error_message = "'kms_data_key_reuse_period_seconds' must be between 60 and 86400."
  }
}

################################################################################
# DEAD-LETTER QUEUE
################################################################################

variable "create_dlq" {
  description = <<-EOT
    Whether to create a companion dead-letter queue (DLQ).
    When true, messages that fail processing after max_receive_count attempts
    are moved to the DLQ automatically.
  EOT
  type        = bool
  default     = true
}

variable "max_receive_count" {
  description = <<-EOT
    Number of times a message can be received before being moved to the DLQ.
    Only applies when create_dlq = true. Valid range: 1–1000.
  EOT
  type        = number
  default     = 5

  validation {
    condition     = var.max_receive_count >= 1 && var.max_receive_count <= 1000
    error_message = "'max_receive_count' must be between 1 and 1000."
  }
}

variable "dlq_message_retention_seconds" {
  description = <<-EOT
    Duration (in seconds) that the DLQ retains messages.
    Default: 1209600 (14 days — maximum) to allow time for investigation.
  EOT
  type        = number
  default     = 1209600

  validation {
    condition     = var.dlq_message_retention_seconds >= 60 && var.dlq_message_retention_seconds <= 1209600
    error_message = "'dlq_message_retention_seconds' must be between 60 and 1209600."
  }
}

variable "dlq_visibility_timeout_seconds" {
  description = "Visibility timeout for the DLQ. Defaults to 30 seconds."
  type        = number
  default     = 30

  validation {
    condition     = var.dlq_visibility_timeout_seconds >= 0 && var.dlq_visibility_timeout_seconds <= 43200
    error_message = "'dlq_visibility_timeout_seconds' must be between 0 and 43200."
  }
}

variable "redrive_policy" {
  description = <<-EOT
    JSON-encoded redrive policy for an external DLQ (when create_dlq = false).
    Example: jsonencode({ deadLetterTargetArn = "arn:...", maxReceiveCount = 5 })
    Ignored when create_dlq = true.
  EOT
  type        = string
  default     = null
}

################################################################################
# QUEUE POLICY
################################################################################

variable "queue_policy" {
  description = <<-EOT
    JSON-encoded IAM resource policy to attach to the main queue.
    Controls which principals can send, receive, or manage messages.
    Null skips policy creation.
  EOT
  type        = string
  default     = null
}

variable "dlq_queue_policy" {
  description = <<-EOT
    JSON-encoded IAM resource policy to attach to the DLQ.
    Null skips policy creation.
  EOT
  type        = string
  default     = null
}

################################################################################
# TAGS
################################################################################

variable "tags" {
  description = "Map of tags applied to all resources created by this module."
  type        = map(string)
  default     = {}
}
