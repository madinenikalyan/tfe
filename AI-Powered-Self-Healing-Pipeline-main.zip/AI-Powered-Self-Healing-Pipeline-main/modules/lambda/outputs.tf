################################################################################
# LAMBDA FUNCTION
################################################################################

output "function_arn" {
  description = "ARN of the Lambda function (unqualified — no version suffix)."
  value       = aws_lambda_function.lambda_function.arn
}

output "function_name" {
  description = "Name of the Lambda function."
  value       = aws_lambda_function.lambda_function.function_name
}

output "function_invoke_arn" {
  description = <<-EOT
    ARN used by API Gateway to invoke this Lambda function.
    Format: arn:aws:apigateway:<region>:lambda:path/2015-03-31/functions/<arn>/invocations
  EOT
  value       = aws_lambda_function.lambda_function.invoke_arn
}

output "function_qualified_arn" {
  description = <<-EOT
    Qualified ARN of the Lambda function including the active version number.
    Only populated when var.publish = true; otherwise same as function_arn.
  EOT
  value       = aws_lambda_function.lambda_function.qualified_arn
}

output "function_version" {
  description = "Latest published version number. Only set when var.publish = true."
  value       = aws_lambda_function.lambda_function.version
}

output "source_code_hash" {
  description = <<-EOT
    Base64-encoded SHA-256 hash of the function deployment package.
    Useful in CI/CD pipelines to detect code changes without inspecting the zip.
  EOT
  value       = aws_lambda_function.lambda_function.source_code_hash
}

output "function_zip_path" {
  description = "Local path to the function deployment zip built by this module."
  value       = data.archive_file.function_code.output_path
}

################################################################################
# IAM ROLE
################################################################################

output "role_arn" {
  description = "ARN of the Lambda execution role."
  value       = module.lambda_role.role_arn
}

output "role_name" {
  description = "Name of the Lambda execution role."
  value       = module.lambda_role.role_name
}

output "role_id" {
  description = "Unique ID of the Lambda execution role."
  value       = module.lambda_role.role_id
}

################################################################################
# CLOUDWATCH LOG GROUP
################################################################################

output "log_group_name" {
  description = "Name of the CloudWatch log group (/aws/lambda/<function_name>)."
  value       = aws_cloudwatch_log_group.function_logs.name
}

output "log_group_arn" {
  description = "ARN of the CloudWatch log group."
  value       = aws_cloudwatch_log_group.function_logs.arn
}

################################################################################
# DEPENDENCY LAYER (only populated when requirements.txt is present)
################################################################################

output "has_layer" {
  description = <<-EOT
    True when the function source directory contains a requirements.txt file
    and the module has built and published a dependency layer.
  EOT
  value       = local.has_requirements
}

output "layer_arn" {
  description = <<-EOT
    Full ARN (including version) of the auto-generated dependency layer.
    Null when the function has no requirements.txt.
  EOT
  value       = local.has_requirements ? aws_lambda_layer_version.layer_packages[0].arn : null
}

output "layer_version_number" {
  description = <<-EOT
    Version number of the published Lambda layer.
    Null when the function has no requirements.txt.
  EOT
  value       = local.has_requirements ? aws_lambda_layer_version.layer_packages[0].version : null
}

output "layer_s3_key" {
  description = <<-EOT
    S3 key of the layer dependency zip.
    Null when the function has no requirements.txt.
  EOT
  value       = local.has_requirements ? aws_s3_object.s3_upload_layer_packages[0].key : null
}

################################################################################
# SECURITY GROUP
################################################################################

output "security_group_id" {
  description = <<-EOT
    ID of the security group created by this module.
    Null when var.create_security_group = false.
  EOT
  value       = var.create_security_group ? aws_security_group.lambda_sg[0].id : null
}

output "security_group_arn" {
  description = <<-EOT
    ARN of the security group created by this module.
    Null when var.create_security_group = false.
  EOT
  value       = var.create_security_group ? aws_security_group.lambda_sg[0].arn : null
}

output "effective_security_group_ids" {
  description = <<-EOT
    Full list of security group IDs actually attached to the Lambda VPC config.
    Includes both the module-created SG (when create_security_group = true)
    and any IDs passed via vpc_config.security_group_ids.
  EOT
  value       = local.effective_security_group_ids
}
