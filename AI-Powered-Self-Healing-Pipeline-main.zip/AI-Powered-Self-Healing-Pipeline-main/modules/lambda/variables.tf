################################################################################
# FUNCTION IDENTITY
################################################################################

variable "function_name" {
  description = <<-EOT
    Name of the Lambda function. Must be unique within the AWS account and region.
    Used as the base name for the execution role, log group, and optional layer.
  EOT
  type        = string
}

variable "description" {
  description = "Human-readable description of what this Lambda function does."
  type        = string
  default     = ""
}

################################################################################
# SOURCE CODE LOCATION
################################################################################

variable "function_source_path" {
  description = <<-EOT
    Path to the Lambda function source directory, relative to the Terraform root
    (the directory where you run terraform plan/apply).

    Example: "functions/bala-test"

    The module will:
      - Zip all files in this directory (excluding requirements.txt) and upload
        to S3 as <s3_key_prefix>/<folder-name>.zip
      - If requirements.txt is present, build a Python dependency layer and
        upload as <s3_key_prefix>/<folder-name>-layer.zip

    NOTE: The "lambda_baseline" key in extra_customer_managed_policies is reserved
    by this module for its built-in CloudWatch Logs + VPC permissions policy.
  EOT
  type        = string

  validation {
    condition     = length(trimspace(var.function_source_path)) > 0
    error_message = "'function_source_path' must not be empty."
  }
}

################################################################################
# LAMBDA ARTIFACTS — S3 STORAGE
################################################################################

variable "lambda_artifacts_bucket" {
  description = <<-EOT
    Name of the S3 bucket used to store the Python dependency layer zip.
    Only required when requirements.txt is present in the function source folder.
    Function code is deployed directly from a local zip — no S3 upload is performed for it.
  EOT
  type        = string
  default     = null
}

variable "lambda_s3_key_prefix" {
  description = <<-EOT
    Optional prefix for the layer zip S3 object key. Defaults to the value of
    var.function_source_path so the folder structure on S3 mirrors the local layout.

    Example (default):
      function_source_path = "functions/bala-test"
      → layer zip: functions/bala-test/bala-test-layer.zip

    Only relevant when requirements.txt is present.
  EOT
  type        = string
  default     = null
}

variable "lambda_s3_kms_key_id" {
  description = <<-EOT
    ARN or ID of the KMS key used to server-side-encrypt the layer zip S3 object.
    Leave null to use the bucket's default encryption.
    Only relevant when requirements.txt is present.
  EOT
  type        = string
  default     = null
}

################################################################################
# RUNTIME CONFIGURATION
################################################################################

variable "runtime" {
  description = <<-EOT
    Lambda runtime identifier.
    Examples: "python3.11", "python3.12", "python3.10", "nodejs20.x", "java21"

    Note: the automatic layer build (from requirements.txt) only works for
    Python runtimes. For non-Python runtimes, supply pre-built layers via
    var.additional_layer_arns.
  EOT
  type        = string
}

variable "handler" {
  description = <<-EOT
    Function entrypoint in the form <file>.<function>.
    Example: "lambda_function.lambda_handler" (default for Python)
  EOT
  type        = string
  default     = "lambda_function.lambda_handler"
}

variable "architectures" {
  description = <<-EOT
    Instruction set architectures for the function. Valid values: ["x86_64"] or ["arm64"].
    ARM64 (Graviton2) typically costs ~20% less and is faster for most workloads.
    The layer build script automatically targets the correct manylinux platform.
  EOT
  type        = list(string)
  default     = ["x86_64"]

  validation {
    condition     = length(var.architectures) == 1 && contains(["x86_64", "arm64"], var.architectures[0])
    error_message = "'architectures' must be exactly one of: [\"x86_64\"] or [\"arm64\"]."
  }
}

variable "publish" {
  description = <<-EOT
    Set to true to publish a new Lambda version on every deployment.
    Required when using aliases or provisioned concurrency.
  EOT
  type        = bool
  default     = false
}

################################################################################
# PERFORMANCE TUNING
################################################################################

variable "timeout" {
  description = "Maximum execution time in seconds. Valid range: 1–900."
  type        = number
  default     = 30

  validation {
    condition     = var.timeout >= 1 && var.timeout <= 900
    error_message = "'timeout' must be between 1 and 900 seconds."
  }
}

variable "memory_size" {
  description = <<-EOT
    Amount of memory allocated to the function (MB). Valid range: 128–10240.
    CPU is proportional to memory; increasing memory also increases CPU and cost.
  EOT
  type        = number
  default     = 128

  validation {
    condition     = var.memory_size >= 128 && var.memory_size <= 10240
    error_message = "'memory_size' must be between 128 and 10240 MB."
  }
}

variable "reserved_concurrent_executions" {
  description = <<-EOT
    Reserved concurrency limit. Set to a positive integer to cap the number
    of simultaneous executions. Set to 0 to throttle all invocations.
    Default (-1) means unreserved (uses account-level concurrency).
  EOT
  type        = number
  default     = -1
}

variable "ephemeral_storage_size" {
  description = <<-EOT
    Size of the /tmp ephemeral storage in MB. Valid range: 512–10240.
    Leave null to use the Lambda default (512 MB).
  EOT
  type        = number
  default     = null

  validation {
    condition     = var.ephemeral_storage_size == null || (var.ephemeral_storage_size >= 512 && var.ephemeral_storage_size <= 10240)
    error_message = "'ephemeral_storage_size' must be between 512 and 10240 MB, or null."
  }
}

################################################################################
# RUNTIME ENVIRONMENT
################################################################################

variable "environment_variables" {
  description = <<-EOT
    Map of environment variables injected into the Lambda runtime.
    Sensitive values should be stored in Secrets Manager or SSM Parameter Store
    and referenced by ARN/name here rather than inline.
  EOT
  type        = map(string)
  default     = {}
  sensitive   = false
}

################################################################################
# VPC CONFIGURATION
################################################################################

variable "vpc_config" {
  description = <<-EOT
    Attach the Lambda function to a VPC. Required for accessing private resources
    (RDS, ElastiCache, internal ALBs). When set, the execution role automatically
    receives the required EC2 network interface permissions.

    security_group_ids: IDs of pre-existing security groups to attach.
    When var.create_security_group = true, the module-created SG is
    automatically merged with this list — you do not need to pass it here.

    Example (pre-existing SGs only):
      vpc_config = {
        subnet_ids         = ["subnet-aaa", "subnet-bbb"]
        security_group_ids = ["sg-111"]
      }

    Example (module-created SG + pre-existing):
      create_security_group = true
      vpc_config = {
        subnet_ids         = ["subnet-aaa", "subnet-bbb"]
        security_group_ids = ["sg-111"]  # merged with the created SG automatically
      }
  EOT
  type = object({
    subnet_ids         = list(string)
    security_group_ids = list(string)
  })
  default = null
}

################################################################################
# SECURITY GROUP
#
# Two modes are supported and can be combined:
#
#   1. CREATE  — set create_security_group = true. The module creates a dedicated
#      security group using var.ingress_rules / var.egress_rules. Requires
#      var.vpc_id to be set. The SG is automatically added to the Lambda VPC
#      attachment alongside any IDs in vpc_config.security_group_ids.
#
#   2. PASS    — leave create_security_group = false and supply existing SG IDs
#      via vpc_config.security_group_ids. The module will not create anything.
################################################################################

variable "create_security_group" {
  description = <<-EOT
    Set to true to have this module create a dedicated security group for the
    Lambda function. The SG is automatically attached to the function alongside
    any IDs supplied in var.vpc_config.security_group_ids.
    Requires var.vpc_id and var.vpc_config to be set.
  EOT
  type        = bool
  default     = false
}

variable "vpc_id" {
  description = <<-EOT
    ID of the VPC in which the security group will be created.
    Required when var.create_security_group = true; ignored otherwise.
  EOT
  type        = string
  default     = null
}

variable "security_group_name" {
  description = <<-EOT
    Name for the module-created security group.
    Defaults to "<function_name>-sg" when null.
    Only used when var.create_security_group = true.
  EOT
  type        = string
  default     = null
}

variable "security_group_description" {
  description = <<-EOT
    Description for the module-created security group.
    Only used when var.create_security_group = true.
  EOT
  type        = string
  default     = "Managed by Lambda Terraform module"
}

variable "ingress_rules" {
  description = <<-EOT
    List of ingress rules applied to the module-created security group.
    Only used when var.create_security_group = true.

    Fields:
      description      – human-readable description for the rule
      from_port        – start of the port range (0 for all/-1 protocol)
      to_port          – end of the port range   (0 for all/-1 protocol)
      protocol         – "tcp", "udp", "icmp", or "-1" (all)
      cidr_blocks      – list of IPv4 CIDR blocks
      ipv6_cidr_blocks – list of IPv6 CIDR blocks
      security_groups  – list of source security group IDs
      self             – whether the SG itself is a source

    Example:
      ingress_rules = [
        {
          description     = "HTTPS from internal VPC"
          from_port       = 443
          to_port         = 443
          protocol        = "tcp"
          cidr_blocks     = ["10.0.0.0/8"]
          security_groups = ["sg-shared-alb"]
        }
      ]
  EOT
  type = list(object({
    description      = optional(string, "")
    from_port        = number
    to_port          = number
    protocol         = string
    cidr_blocks      = optional(list(string), [])
    ipv6_cidr_blocks = optional(list(string), [])
    security_groups  = optional(list(string), [])
    self             = optional(bool, false)
  }))
  default = []
}

variable "egress_rules" {
  description = <<-EOT
    List of egress rules applied to the module-created security group.
    Only used when var.create_security_group = true.
    Defaults to allow-all outbound (standard for Lambda).

    Fields mirror var.ingress_rules above.

    Example (restrict outbound to Aurora only):
      egress_rules = [
        {
          description     = "MySQL to Aurora SG"
          from_port       = 3306
          to_port         = 3306
          protocol        = "tcp"
          security_groups = ["sg-aurora"]
        }
      ]
  EOT
  type = list(object({
    description      = optional(string, "")
    from_port        = number
    to_port          = number
    protocol         = string
    cidr_blocks      = optional(list(string), [])
    ipv6_cidr_blocks = optional(list(string), [])
    security_groups  = optional(list(string), [])
    self             = optional(bool, false)
  }))
  default = [
    {
      description = "Allow all outbound traffic"
      from_port   = 0
      to_port     = 0
      protocol    = "-1"
      cidr_blocks = ["0.0.0.0/0"]
    }
  ]
}

################################################################################
# IAM ROLE & PERMISSIONS
################################################################################

variable "iam_role_path" {
  description = "IAM path for the execution role. Must begin and end with '/'."
  type        = string
  default     = "/"

  validation {
    condition     = startswith(var.iam_role_path, "/") && endswith(var.iam_role_path, "/")
    error_message = "'iam_role_path' must begin and end with a forward slash."
  }
}

variable "permission_boundary_arn" {
  description = <<-EOT
    ARN of an IAM managed policy to use as the permission boundary for the
    Lambda execution role. Leave null to skip (not recommended for production
    environments with delegated administration).
  EOT
  type        = string
  default     = null
}

variable "extra_customer_managed_policies" {
  description = <<-EOT
    Map of additional customer-managed IAM policies to create and attach to
    the Lambda execution role. These are merged with the module's built-in
    baseline policy (CloudWatch Logs + optional VPC/X-Ray).

    RESERVED KEY: "lambda_baseline" – do not use this key; it is already taken
    by the module's built-in baseline policy.

    Example:
      extra_customer_managed_policies = {
        s3_read = {
          name   = "my-function-s3-read"
          policy = data.aws_iam_policy_document.s3_read.json
        }
      }
  EOT
  type = map(object({
    name        = string
    description = optional(string, "")
    path        = optional(string, "/")
    policy      = string
  }))
  default = {}
}

variable "extra_customer_managed_policy_arns" {
  description = <<-EOT
    List of pre-existing customer-managed policy ARNs to attach to the Lambda
    execution role. Use for shared policies created outside this module.
  EOT
  type        = list(string)
  default     = []
}

variable "extra_aws_managed_policy_arns" {
  description = <<-EOT
    List of AWS-managed policy ARNs to attach to the Lambda execution role.
    Use sparingly – prefer narrow customer-managed policies.

    Example: ["arn:aws:iam::aws:policy/AmazonDynamoDBReadOnlyAccess"]
  EOT
  type        = list(string)
  default     = []
}

variable "extra_inline_policies" {
  description = <<-EOT
    Map of inline policies embedded directly in the Lambda execution role.
    Key = policy name, value = JSON policy document.
    Use sparingly – prefer managed policies for auditability.
  EOT
  type        = map(string)
  default     = {}
}

################################################################################
# ADDITIONAL LAMBDA LAYERS
################################################################################

variable "additional_layer_arns" {
  description = <<-EOT
    List of additional Lambda layer ARNs to attach to the function.
    The module-generated dependency layer (from requirements.txt) is always
    prepended automatically; these are appended after it.
    Maximum total layers per function: 5.
  EOT
  type        = list(string)
  default     = []
}

################################################################################
# DEAD-LETTER QUEUE
################################################################################

variable "dead_letter_target_arn" {
  description = <<-EOT
    ARN of an SQS queue or SNS topic to receive unprocessed events when the
    function fails (after exhausting retries). Leave null to disable.
    Remember to grant the execution role permission to send to this target.
  EOT
  type        = string
  default     = null
}

################################################################################
# OBSERVABILITY — TRACING & LOGGING
################################################################################

variable "tracing_mode" {
  description = <<-EOT
    X-Ray tracing mode. Valid values:
      "PassThrough" – trace only when called from an instrumented service (default)
      "Active"      – always sample and trace; adds X-Ray permissions to the role
  EOT
  type        = string
  default     = "PassThrough"

  validation {
    condition     = contains(["PassThrough", "Active"], var.tracing_mode)
    error_message = "'tracing_mode' must be \"PassThrough\" or \"Active\"."
  }
}

variable "log_retention_in_days" {
  description = <<-EOT
    CloudWatch Logs retention period in days. Common values: 1, 3, 5, 7, 14,
    30, 60, 90, 120, 150, 180, 365, 400, 545, 731, 1827, 3653.
    Set to 0 for indefinite retention (not recommended – incurs ongoing cost).
  EOT
  type        = number
  default     = 14
}

variable "log_kms_key_id" {
  description = <<-EOT
    ARN of the KMS key used to encrypt the CloudWatch log group.
    Leave null to use CloudWatch's default encryption.
    When set, the execution role automatically receives kms:Decrypt and
    kms:GenerateDataKey permissions for this key.
  EOT
  type        = string
  default     = null
}

################################################################################
# INVOKE PERMISSIONS
# One block per trigger type. All lists are empty by default (no permissions
# are created unless the caller explicitly supplies them).
#
# Each object MUST contain:
#   statement_id – unique SID within the function's resource-based policy
#   source_arn   – ARN of the invoking resource
# Optional:
#   qualifier      – function alias or version (e.g. "$LATEST", "live")
#   source_account – AWS account ID of the invoking resource (for cross-account)
################################################################################

variable "s3_invoke_permissions" {
  description = <<-EOT
    Grants S3 buckets permission to invoke this Lambda function.
    Use source_account to prevent the confused deputy problem when the bucket
    belongs to a different account.

    Example:
      s3_invoke_permissions = [
        {
          statement_id   = "AllowS3Trigger"
          source_arn     = "arn:aws:s3:::my-bucket"
          source_account = "123456789012"
        }
      ]
  EOT
  type = list(object({
    statement_id   = string
    source_arn     = string
    source_account = optional(string, null)
    qualifier      = optional(string, null)
  }))
  default = []
}

variable "api_gateway_invoke_permissions" {
  description = <<-EOT
    Grants API Gateway stages/methods permission to invoke this Lambda function.
    source_arn typically ends with "/*/*" to cover all stages and methods.

    Example:
      api_gateway_invoke_permissions = [
        {
          statement_id = "AllowAPIGateway"
          source_arn   = "$${aws_api_gateway_rest_api.example.execution_arn}/*/*"
        }
      ]
  EOT
  type = list(object({
    statement_id   = string
    source_arn     = string
    source_account = optional(string, null)
    qualifier      = optional(string, null)
  }))
  default = []
}

variable "sns_invoke_permissions" {
  description = <<-EOT
    Grants SNS topics permission to invoke this Lambda function (push model).

    Example:
      sns_invoke_permissions = [
        {
          statement_id = "AllowSNSTopic"
          source_arn   = aws_sns_topic.example.arn
        }
      ]
  EOT
  type = list(object({
    statement_id   = string
    source_arn     = string
    source_account = optional(string, null)
    qualifier      = optional(string, null)
  }))
  default = []
}

variable "sqs_invoke_permissions" {
  description = <<-EOT
    Grants SQS queues permission to invoke this Lambda function via
    resource-based policy. For the typical Event Source Mapping pattern,
    invoke permissions are not needed — ESM access is controlled by the
    execution role's SQS receive/delete permissions instead.
    Use this only when SQS directly calls Lambda via resource policy.
  EOT
  type = list(object({
    statement_id   = string
    source_arn     = string
    source_account = optional(string, null)
    qualifier      = optional(string, null)
  }))
  default = []
}

variable "eventbridge_invoke_permissions" {
  description = <<-EOT
    Grants EventBridge rules (CloudWatch Events) permission to invoke this
    Lambda function as a target.

    Example:
      eventbridge_invoke_permissions = [
        {
          statement_id = "AllowScheduledRule"
          source_arn   = aws_cloudwatch_event_rule.daily.arn
        }
      ]
  EOT
  type = list(object({
    statement_id   = string
    source_arn     = string
    source_account = optional(string, null)
    qualifier      = optional(string, null)
  }))
  default = []
}

variable "alb_invoke_permissions" {
  description = <<-EOT
    Grants Application Load Balancer target groups permission to invoke this
    Lambda function.

    Example:
      alb_invoke_permissions = [
        {
          statement_id = "AllowALB"
          source_arn   = aws_lb_target_group.lambda_tg.arn
        }
      ]
  EOT
  type = list(object({
    statement_id   = string
    source_arn     = string
    source_account = optional(string, null)
    qualifier      = optional(string, null)
  }))
  default = []
}

################################################################################
# TAGS
################################################################################

variable "tags" {
  description = <<-EOT
    Map of tags applied to all resources created by this module.
    Merge with your common_tags in the caller for consistency:
      tags = merge(local.common_tags, { Component = "my-component" })
  EOT
  type        = map(string)
  default     = {}
}
