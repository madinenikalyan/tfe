################################################################################
# Required providers for this module.
# The root module must also declare these providers; add the following to the
# root providers.tf required_providers block if not already present:
#
#   archive = { source = "hashicorp/archive", version = ">= 2.4" }
#
# Minimum Terraform version: 1.4  (uses terraform_data, built-in)
################################################################################

terraform {
  required_version = ">= 1.4.0"

  required_providers {
    archive = {
      source  = "hashicorp/archive"
      version = ">= 2.4"
    }
  }
}

################################################################################
# LOCALS — all derived values in one place
################################################################################

locals {
  # Normalise path: strip any accidental leading slash so path.root/ + path works
  source_path = trimprefix(var.function_source_path, "/")

  # Folder name at the leaf of the source path (e.g. "bala-test")
  source_folder_name = basename(local.source_path)

  # Absolute path to the function source directory, resolved from Terraform root
  source_abs_path = "${path.root}/${local.source_path}"

  # True when the function ships a requirements.txt that needs packaging
  has_requirements = fileexists("${path.root}/${local.source_path}/requirements.txt")

  # Paths to generated artefacts inside the root module's .build scratch directory.
  # path.root always points to the directory where terraform is invoked, regardless
  # of which module this file lives in — so .build/ lands next to functions.tf.
  # (.build/.gitkeep keeps the directory in VCS; *.zip is gitignored)
  function_zip_local = "${path.root}/.build/${local.source_folder_name}.zip"
  layer_zip_local    = "${path.root}/.build/${local.source_folder_name}-layer.zip"

  # S3 key prefix for the layer zip: mirrors the source path unless the caller overrides it
  s3_prefix = coalesce(var.lambda_s3_key_prefix, local.source_path)

  # S3 object key for the dependency layer zip (function code is deployed from local)
  layer_s3_key = "${local.s3_prefix}/${local.source_folder_name}-layer.zip"

  # pip manylinux platform determined by target architecture
  pip_platform = contains(var.architectures, "arm64") ? "manylinux2014_aarch64" : "manylinux2014_x86_64"

  # Python version string for pip --python-version (strips "python" prefix)
  python_version = startswith(var.runtime, "python") ? replace(var.runtime, "python", "") : ""

  # Effective security group IDs attached to the Lambda VPC config.
  # Splat expression on the conditional SG resource returns [] when not created
  # and [id] when created — both are safely concat-ed with user-supplied IDs.
  effective_security_group_ids = concat(
    aws_security_group.lambda_sg[*].id,
    var.vpc_config != null ? var.vpc_config.security_group_ids : []
  )
}

################################################################################
# FUNCTION CODE — zip locally only (deployed via filename, not S3)
#
# archive_file runs at plan time so source_code_hash is always known before
# apply, giving clean, deterministic plan output. The zip is written to the
# module's .build/ scratch directory and referenced directly by the Lambda
# function — no S3 upload is performed for function code.
################################################################################

data "archive_file" "function_code" {
  type        = "zip"
  source_dir  = local.source_abs_path
  output_path = local.function_zip_local

  # Exclude dependency file — packages live in the separate S3-backed layer.
  # Also exclude any Terraform files co-located in the source folder (e.g. lambda.tf
  # kept alongside the code for reference) so they are not bundled into the package.
  excludes = ["requirements.txt", "*.tf", "*.tfvars"]
}

################################################################################
# DEPENDENCY LAYER — build, zip, and upload when requirements.txt is present
#
# Build strategy:
#   1. Try to install Linux-compatible binary wheels (matches Lambda runtime).
#   2. Fall back to source/platform-native install if no binary wheel exists.
#
# terraform_data (Terraform ≥ 1.4, built-in — no null provider needed) replaces
# null_resource. It re-runs the provisioner whenever triggers_replace changes,
# i.e. when requirements.txt is modified or the target architecture changes.
# replace_triggered_by on the S3 object forces a new layer version upload
# whenever the builder re-runs.
################################################################################

resource "terraform_data" "layer_builder" {
  count = local.has_requirements ? 1 : 0

  # Rebuild whenever any of these values change
  triggers_replace = [
    filemd5("${local.source_abs_path}/requirements.txt"),
    local.layer_zip_local,
    local.pip_platform,
    local.python_version,
  ]

  provisioner "local-exec" {
    command = <<-CMD
      set -e
      # Capture the working directory once so all paths remain absolute
      # after the 'cd' into the build directory below.
      ROOT_DIR="$(pwd)"
      LAYER_BUILD="$ROOT_DIR/${path.root}/.build/layer-${local.source_folder_name}"
      ZIP_OUT="$ROOT_DIR/${path.root}/.build/${local.source_folder_name}-layer.zip"

      echo "[lambda-module/${local.source_folder_name}] Building dependency layer..."

      # Clean previous build artefacts
      rm -rf "$LAYER_BUILD"
      mkdir -p "$LAYER_BUILD/python"

      # Attempt 1: install Linux-compatible binary wheels so native packages
      # (e.g. numpy, pydantic) work inside the Lambda sandbox.
      python3 -m pip install \
        -r "$ROOT_DIR/${local.source_abs_path}/requirements.txt" \
        -t "$LAYER_BUILD/python" \
        --quiet --upgrade \
        --platform "${local.pip_platform}" \
        --python-version "${local.python_version}" \
        --implementation cp \
        --only-binary=:all: 2>/dev/null \
      || \
      python3 -m pip install \
        -r "$ROOT_DIR/${local.source_abs_path}/requirements.txt" \
        -t "$LAYER_BUILD/python" \
        --quiet --upgrade

      # Strip bytecode and dist metadata to minimise layer size
      find "$LAYER_BUILD" -type d -name "__pycache__" -exec rm -rf {} + 2>/dev/null || true
      find "$LAYER_BUILD" -type d -name "*.dist-info" -exec rm -rf {} + 2>/dev/null || true
      find "$LAYER_BUILD" -type d -name "*.egg-info"  -exec rm -rf {} + 2>/dev/null || true
      find "$LAYER_BUILD" -type f -name "*.pyc"       -delete      2>/dev/null || true

      # Zip with python/ at the root — required Lambda layer directory structure.
      # ZIP_OUT is absolute so it resolves correctly after the cd.
      cd "$LAYER_BUILD"
      zip -r -q "$ZIP_OUT" python/
      cd "$ROOT_DIR"

      rm -rf "$LAYER_BUILD"
      echo "[lambda-module/${local.source_folder_name}] Layer zip ready: $ZIP_OUT"
    CMD
  }
}

resource "aws_s3_object" "s3_upload_layer_packages" {
  count = local.has_requirements ? 1 : 0

  bucket = var.lambda_artifacts_bucket
  key    = local.layer_s3_key
  source = local.layer_zip_local

  server_side_encryption = var.lambda_s3_kms_key_id != null ? "aws:kms" : null
  kms_key_id             = var.lambda_s3_kms_key_id

  tags = var.tags

  depends_on = [terraform_data.layer_builder]

  # Force S3 object replacement whenever the builder re-ran (requirements changed)
  lifecycle {
    replace_triggered_by = [terraform_data.layer_builder[0]]
  }
}

resource "aws_lambda_layer_version" "layer_packages" {
  count = local.has_requirements ? 1 : 0

  layer_name  = "${var.function_name}-layer"
  description = "Auto-generated Python dependencies for ${var.function_name}"
  s3_bucket   = aws_s3_object.s3_upload_layer_packages[0].bucket
  s3_key      = aws_s3_object.s3_upload_layer_packages[0].key

  # Hash of requirements.txt drives layer version increments
  source_code_hash = filemd5("${local.source_abs_path}/requirements.txt")

  compatible_runtimes      = [var.runtime]
  compatible_architectures = var.architectures

  depends_on = [aws_s3_object.s3_upload_layer_packages]
}

################################################################################
# SECURITY GROUP (optional)
#
# Set var.create_security_group = true to let this module create a dedicated
# security group for the Lambda function. Requires var.vpc_id to be set.
#
# To reuse existing security groups, pass their IDs via
# var.vpc_config.security_group_ids. Both the module-created SG and any
# user-supplied IDs are merged automatically in local.effective_security_group_ids.
################################################################################

resource "aws_security_group" "lambda_sg" {
  count = var.create_security_group ? 1 : 0

  name        = coalesce(var.security_group_name, "${var.function_name}-sg")
  description = var.security_group_description
  vpc_id      = var.vpc_id

  dynamic "ingress" {
    for_each = var.ingress_rules
    content {
      description      = ingress.value.description
      from_port        = ingress.value.from_port
      to_port          = ingress.value.to_port
      protocol         = ingress.value.protocol
      cidr_blocks      = ingress.value.cidr_blocks
      ipv6_cidr_blocks = ingress.value.ipv6_cidr_blocks
      security_groups  = ingress.value.security_groups
      self             = ingress.value.self
    }
  }

  dynamic "egress" {
    for_each = var.egress_rules
    content {
      description      = egress.value.description
      from_port        = egress.value.from_port
      to_port          = egress.value.to_port
      protocol         = egress.value.protocol
      cidr_blocks      = egress.value.cidr_blocks
      ipv6_cidr_blocks = egress.value.ipv6_cidr_blocks
      security_groups  = egress.value.security_groups
      self             = egress.value.self
    }
  }

  tags = merge(var.tags, {
    Name = coalesce(var.security_group_name, "${var.function_name}-sg")
  })

  lifecycle {
    create_before_destroy = true
  }
}

################################################################################
# CLOUDWATCH LOG GROUP
#
# Created before the function so its ARN is available for the IAM policy and
# to prevent Lambda auto-creating a log group with unlimited retention.
################################################################################

resource "aws_cloudwatch_log_group" "function_logs" {
  name              = "/aws/lambda/${var.function_name}"
  retention_in_days = var.log_retention_in_days
  kms_key_id        = var.log_kms_key_id

  tags = var.tags
}

################################################################################
# IAM — trust policy (Lambda service principal)
################################################################################

data "aws_iam_policy_document" "lambda_assume_role" {
  statement {
    sid     = "LambdaAssumeRole"
    effect  = "Allow"
    actions = ["sts:AssumeRole"]

    principals {
      type        = "Service"
      identifiers = ["lambda.amazonaws.com"]
    }
  }
}

################################################################################
# IAM — baseline policy
#
# Every Lambda function needs:
#   • CloudWatch Logs       – write logs to its dedicated log group
#   • EC2 network interface – only when VPC-attached
#   • X-Ray                – only when Active tracing is enabled
#   • KMS Decrypt           – only when log group or S3 objects are encrypted
################################################################################

data "aws_iam_policy_document" "lambda_baseline" {

  # CloudWatch Logs — scoped to the function's own log group
  statement {
    sid    = "CloudWatchLogs"
    effect = "Allow"
    actions = [
      "logs:CreateLogStream",
      "logs:PutLogEvents",
    ]
    resources = [
      aws_cloudwatch_log_group.function_logs.arn,
      "${aws_cloudwatch_log_group.function_logs.arn}:*",
    ]
  }

  # VPC — ENI lifecycle permissions (required for VPC-attached functions)
  dynamic "statement" {
    for_each = var.vpc_config != null ? [1] : []
    content {
      sid    = "VPCNetworkInterfaces"
      effect = "Allow"
      actions = [
        "ec2:CreateNetworkInterface",
        "ec2:DescribeNetworkInterfaces",
        "ec2:DescribeSubnets",
        "ec2:DeleteNetworkInterface",
        "ec2:AssignPrivateIpAddresses",
        "ec2:UnassignPrivateIpAddresses",
      ]
      # ENI actions require * resource; scoped further by VPC/subnet conditions
      resources = ["*"]
    }
  }

  # X-Ray — active tracing segment submission
  dynamic "statement" {
    for_each = var.tracing_mode == "Active" ? [1] : []
    content {
      sid    = "XRayTracing"
      effect = "Allow"
      actions = [
        "xray:PutTraceSegments",
        "xray:PutTelemetryRecords",
        "xray:GetSamplingRules",
        "xray:GetSamplingTargets",
      ]
      resources = ["*"]
    }
  }

  # KMS — decrypt log group and/or S3 artefact encryption
  dynamic "statement" {
    for_each = (var.log_kms_key_id != null || var.lambda_s3_kms_key_id != null) ? [1] : []
    content {
      sid    = "KMSDecrypt"
      effect = "Allow"
      actions = [
        "kms:Decrypt",
        "kms:GenerateDataKey",
      ]
      resources = compact([
        var.log_kms_key_id,
        var.lambda_s3_kms_key_id,
      ])
    }
  }
}

################################################################################
# IAM ROLE — delegated to the shared IAM module
#
# The "lambda_baseline" key in customer_managed_policies is reserved by this
# module. Extra policies from the caller are merged alongside it.
################################################################################

module "lambda_role" {
  source = "../iam"

  role_name               = "${var.function_name}-role"
  description             = "Execution role for Lambda function: ${var.function_name}"
  path                    = var.iam_role_path
  assume_role_policy      = data.aws_iam_policy_document.lambda_assume_role.json
  permission_boundary_arn = var.permission_boundary_arn
  force_detach_policies   = true

  # Merge the mandatory baseline policy with any caller-supplied policies.
  # Caller must NOT use the key "lambda_baseline" — it is reserved.
  customer_managed_policies = merge(
    {
      lambda_baseline = {
        name        = "${var.function_name}-default-policy"
        description = "Baseline CloudWatch Logs + optional VPC / X-Ray / KMS for ${var.function_name}"
        path        = var.iam_role_path
        policy      = data.aws_iam_policy_document.lambda_baseline.json
      }
    },
    var.extra_customer_managed_policies
  )

  customer_managed_policy_arns = var.extra_customer_managed_policy_arns
  aws_managed_policy_arns      = var.extra_aws_managed_policy_arns
  inline_policies              = var.extra_inline_policies

  tags = var.tags
}

################################################################################
# LAMBDA FUNCTION
################################################################################

resource "aws_lambda_function" "lambda_function" {
  function_name = var.function_name
  description   = var.description
  role          = module.lambda_role.role_arn

  # Deployment package loaded directly from the local zip — no S3 upload.
  # source_code_hash tells Lambda when to re-deploy (changes on every code edit).
  filename         = data.archive_file.function_code.output_path
  source_code_hash = data.archive_file.function_code.output_base64sha256

  runtime       = var.runtime
  handler       = var.handler
  timeout       = var.timeout
  memory_size   = var.memory_size
  architectures = var.architectures
  publish       = var.publish

  reserved_concurrent_executions = var.reserved_concurrent_executions

  # Module-generated dependency layer (if any) is always first in the list.
  # Caller-supplied layers are appended after it. Max 5 layers total.
  layers = concat(
    local.has_requirements ? [aws_lambda_layer_version.layer_packages[0].arn] : [],
    var.additional_layer_arns
  )

  # Environment variables (block omitted entirely when map is empty to avoid noisy diffs)
  dynamic "environment" {
    for_each = length(var.environment_variables) > 0 ? [var.environment_variables] : []
    content {
      variables = environment.value
    }
  }

  # VPC attachment
  # security_group_ids uses the merged list of module-created SG + user-supplied IDs
  dynamic "vpc_config" {
    for_each = var.vpc_config != null ? [var.vpc_config] : []
    content {
      subnet_ids         = vpc_config.value.subnet_ids
      security_group_ids = local.effective_security_group_ids
    }
  }

  # Dead-letter queue / SNS topic
  dynamic "dead_letter_config" {
    for_each = var.dead_letter_target_arn != null ? [var.dead_letter_target_arn] : []
    content {
      target_arn = dead_letter_config.value
    }
  }

  # X-Ray tracing
  tracing_config {
    mode = var.tracing_mode
  }

  # Expanded /tmp storage
  dynamic "ephemeral_storage" {
    for_each = var.ephemeral_storage_size != null ? [var.ephemeral_storage_size] : []
    content {
      size = ephemeral_storage.value
    }
  }

  tags = var.tags

  depends_on = [
    # IAM role must exist and all policies must be attached before the function
    # can assume it — avoids "InvalidParameterValueException: role is not ready"
    module.lambda_role,

    # Log group must exist first so Lambda doesn't auto-create one with unlimited
    # retention and so the IAM baseline policy ARN is already resolved
    aws_cloudwatch_log_group.function_logs,

    # Layer pipeline: builder → S3 upload → layer version
    # Explicit dependency ensures the layer version ARN is available before the
    # function resource is created, even when count = 0 (no requirements.txt)
    terraform_data.layer_builder,
    aws_s3_object.s3_upload_layer_packages,
    aws_lambda_layer_version.layer_packages,

    # Security group must be created before attaching it to the VPC config
    aws_security_group.lambda_sg,
  ]
}

################################################################################
# INVOKE PERMISSIONS — resource-based policy statements
################################################################################

#  Amazon S3 
resource "aws_lambda_permission" "s3" {
  for_each = { for p in var.s3_invoke_permissions : p.statement_id => p }

  statement_id   = each.value.statement_id
  action         = "lambda:InvokeFunction"
  function_name  = aws_lambda_function.lambda_function.function_name
  qualifier      = each.value.qualifier
  principal      = "s3.amazonaws.com"
  source_arn     = each.value.source_arn
  source_account = each.value.source_account
}

#  Amazon API Gateway 
resource "aws_lambda_permission" "api_gateway" {
  for_each = { for p in var.api_gateway_invoke_permissions : p.statement_id => p }

  statement_id   = each.value.statement_id
  action         = "lambda:InvokeFunction"
  function_name  = aws_lambda_function.lambda_function.function_name
  qualifier      = each.value.qualifier
  principal      = "apigateway.amazonaws.com"
  source_arn     = each.value.source_arn
  source_account = each.value.source_account
}

#  Amazon SNS 
resource "aws_lambda_permission" "sns" {
  for_each = { for p in var.sns_invoke_permissions : p.statement_id => p }

  statement_id   = each.value.statement_id
  action         = "lambda:InvokeFunction"
  function_name  = aws_lambda_function.lambda_function.function_name
  qualifier      = each.value.qualifier
  principal      = "sns.amazonaws.com"
  source_arn     = each.value.source_arn
  source_account = each.value.source_account
}

#  Amazon SQS 
# Note: for the standard Event Source Mapping pattern, invoke permissions are
# NOT needed. The execution role's SQS receive/delete permissions are sufficient.
# Add entries here only when SQS invokes Lambda via a resource-based policy.
resource "aws_lambda_permission" "sqs" {
  for_each = { for p in var.sqs_invoke_permissions : p.statement_id => p }

  statement_id   = each.value.statement_id
  action         = "lambda:InvokeFunction"
  function_name  = aws_lambda_function.lambda_function.function_name
  qualifier      = each.value.qualifier
  principal      = "sqs.amazonaws.com"
  source_arn     = each.value.source_arn
  source_account = each.value.source_account
}

#  Amazon EventBridge / CloudWatch Events 
resource "aws_lambda_permission" "eventbridge" {
  for_each = { for p in var.eventbridge_invoke_permissions : p.statement_id => p }

  statement_id   = each.value.statement_id
  action         = "lambda:InvokeFunction"
  function_name  = aws_lambda_function.lambda_function.function_name
  qualifier      = each.value.qualifier
  principal      = "events.amazonaws.com"
  source_arn     = each.value.source_arn
  source_account = each.value.source_account
}

#  Application Load Balancer 
resource "aws_lambda_permission" "alb" {
  for_each = { for p in var.alb_invoke_permissions : p.statement_id => p }

  statement_id   = each.value.statement_id
  action         = "lambda:InvokeFunction"
  function_name  = aws_lambda_function.lambda_function.function_name
  qualifier      = each.value.qualifier
  principal      = "elasticloadbalancing.amazonaws.com"
  source_arn     = each.value.source_arn
  source_account = each.value.source_account
}
