# Lambda Module

A reusable, opinionated Terraform module that provisions a complete Lambda function with:

- **Local zip deployment** — function code is zipped at plan time and deployed directly via `filename`; no S3 upload for source code
- **Automatic dependency layer** — when `requirements.txt` is present, pip packages are built and uploaded to S3 as a Lambda Layer version (rebuilt only when `requirements.txt` changes)
- **Dedicated execution role** — delegates to the `../iam` module; ships a least-privilege baseline policy (CloudWatch Logs, optional VPC ENI, optional X-Ray, optional KMS) and accepts unlimited extra policies
- **CloudWatch Log Group** — pre-created with configurable retention; prevents Lambda auto-creating one with unlimited retention
- **Optional Security Group** — create a new SG with custom ingress/egress rules, pass existing SG IDs, or combine both
- **Resource-based invoke permissions** — per-trigger-type blocks for S3, API Gateway, SNS, SQS, EventBridge, and ALB

**Minimum Terraform version:** `>= 1.4.0` (uses `terraform_data`, built-in successor to `null_resource`)

---

## Directory layout expected per function

```
functions/
└── my-function/
    ├── lambda_function.py   # handler code (or index.js, etc.)
    └── requirements.txt     # optional — triggers automatic layer build
```

---

## Quick-start (no layer, no VPC)

```hcl
module "my_lambda" {
  source = "./modules/lambda"

  function_name        = "my-function"
  description          = "Does something useful"
  function_source_path = "functions/my-function"
  runtime              = "python3.12"

  tags = local.common_tags
}
```

---

## With dependency layer (requirements.txt present)

```hcl
module "my_lambda" {
  source = "./modules/lambda"

  function_name        = "my-function"
  function_source_path = "functions/my-function"
  runtime              = "python3.12"

  # S3 bucket is required only when requirements.txt exists
  lambda_artifacts_bucket = "my-artefacts-bucket"

  tags = local.common_tags
}
```

The module auto-detects `requirements.txt`. When found it:
1. Runs `pip install` into `python/` using Linux-compatible binary wheels
2. Zips the result and uploads to `s3://<lambda_artifacts_bucket>/functions/my-function/my-function-layer.zip`
3. Publishes a new `aws_lambda_layer_version` named `my-function-layer`

The layer is rebuilt **only** when `requirements.txt` changes (content hash comparison).

---

## With VPC + module-created security group

```hcl
module "my_lambda" {
  source = "./modules/lambda"

  function_name        = "my-function"
  function_source_path = "functions/my-function"
  runtime              = "python3.12"

  vpc_config = {
    subnet_ids         = ["subnet-aaa", "subnet-bbb"]
    security_group_ids = []   # optionally pass existing SG IDs here
  }

  # Let the module create a dedicated SG
  create_security_group = true
  vpc_id                = "vpc-12345678"

  ingress_rules = []   # Lambda typically needs no inbound

  egress_rules = [
    {
      description     = "Aurora MySQL"
      from_port       = 3306
      to_port         = 3306
      protocol        = "tcp"
      security_groups = ["sg-aurora"]
    }
  ]

  tags = local.common_tags
}
```

> **Both modes can be combined.** The module-created SG and any `vpc_config.security_group_ids` are merged automatically — you never need to reference the created SG ID manually.

---

## With extra IAM policies on the execution role

The execution role always gets a baseline policy (CWLogs + optional VPC/XRay/KMS).  
Add extra permissions via any combination of these four variables:

```hcl
module "my_lambda" {
  source = "./modules/lambda"
  # ... required vars ...

  # 1. Create new customer-managed policy and attach it
  extra_customer_managed_policies = {
    s3_read = {
      name        = "my-function-s3-read"
      description = "Read from raw data bucket"
      policy      = data.aws_iam_policy_document.s3_read.json
    }
  }

  # 2. Attach a pre-existing customer-managed policy by ARN
  extra_customer_managed_policy_arns = [
    "arn:aws:iam::123456789012:policy/shared-secrets-read"
  ]

  # 3. Attach an AWS-managed policy
  extra_aws_managed_policy_arns = [
    "arn:aws:iam::aws:policy/AmazonDynamoDBReadOnlyAccess"
  ]

  # 4. Embed an inline policy (use sparingly)
  extra_inline_policies = {
    deny_delete = data.aws_iam_policy_document.deny_delete.json
  }
}
```

> **Reserved key:** `"lambda_baseline"` in `extra_customer_managed_policies` — do not use it; it is taken by the module's built-in baseline policy.

---

## With invoke permissions

```hcl
module "my_lambda" {
  source = "./modules/lambda"
  # ... required vars ...

  s3_invoke_permissions = [
    {
      statement_id   = "AllowRawBucketTrigger"
      source_arn     = "arn:aws:s3:::my-raw-bucket"
      source_account = "123456789012"   # prevents confused-deputy attacks
    }
  ]

  api_gateway_invoke_permissions = [
    {
      statement_id = "AllowAPIGW"
      source_arn   = "${aws_api_gateway_rest_api.main.execution_arn}/*/*"
    }
  ]

  eventbridge_invoke_permissions = [
    {
      statement_id = "AllowDailySchedule"
      source_arn   = aws_cloudwatch_event_rule.daily.arn
    }
  ]
}
```

---

## Input variables

### Function identity

| Variable | Type | Required | Default | Accepted Values | Description |
|---|---|---|---|---|---|
| `function_name` | `string` | ✅ Yes | — | Any valid Lambda function name | Unique Lambda function name. Also used as the base name for the role, log group, and layer. |
| `description` | `string` | No | `""` | Any string | Human-readable description of the function. |

### Source code

| Variable | Type | Required | Default | Accepted Values | Description |
|---|---|---|---|---|---|
| `function_source_path` | `string` | ✅ Yes | — | Relative directory path, e.g. `"functions/my-function"` | Path to the source folder relative to the Terraform root. Must not be empty. |

### Layer / S3 artefacts

> Only required when `requirements.txt` is present in the source folder.

| Variable | Type | Required | Default | Accepted Values | Description |
|---|---|---|---|---|---|
| `lambda_artifacts_bucket` | `string` | Conditional | `null` | Any valid S3 bucket name | S3 bucket for the layer zip. Required when `requirements.txt` exists. |
| `lambda_s3_key_prefix` | `string` | No | `null` | Any valid S3 key prefix string | S3 key prefix for the layer zip. Defaults to `function_source_path` when null. |
| `lambda_s3_kms_key_id` | `string` | No | `null` | KMS key ARN or key ID | KMS key for server-side encryption of the layer zip in S3. |

### Runtime

| Variable | Type | Required | Default | Accepted Values | Description |
|---|---|---|---|---|---|
| `runtime` | `string` | ✅ Yes | — | `python3.10`, `python3.11`, `python3.12`, `nodejs20.x`, `java21`, etc. | Lambda runtime identifier. Auto-layer build only works for Python runtimes. |
| `handler` | `string` | No | `"lambda_function.lambda_handler"` | `<file>.<function>` format | Function entrypoint. |
| `architectures` | `list(string)` | No | `["x86_64"]` | `["x86_64"]` or `["arm64"]` — exactly one value | Instruction set architecture. ARM64 is ~20% cheaper for most workloads. |
| `publish` | `bool` | No | `false` | `true`, `false` | Publish a numbered Lambda version on each deploy. Required for aliases. |

### Performance

| Variable | Type | Required | Default | Accepted Values | Description |
|---|---|---|---|---|---|
| `timeout` | `number` | No | `30` | `1` – `900` (seconds) | Maximum execution time before Lambda terminates the function. |
| `memory_size` | `number` | No | `128` | `128` – `10240` (MB) | Memory in MB. CPU is allocated proportionally to memory. |
| `reserved_concurrent_executions` | `number` | No | `-1` | `-1` (unreserved), `0` (throttled), or any positive integer | Concurrency cap. `-1` uses the account-level unreserved pool. |
| `ephemeral_storage_size` | `number` | No | `null` (512 MB) | `512` – `10240` (MB), or `null` | Size of the `/tmp` scratch space in MB. |

### Environment

| Variable | Type | Required | Default | Accepted Values | Description |
|---|---|---|---|---|---|
| `environment_variables` | `map(string)` | No | `{}` | Any `{ KEY = "value" }` map | Runtime environment variables injected into the Lambda execution environment. |

### VPC

| Variable | Type | Required | Default | Accepted Values | Description |
|---|---|---|---|---|---|
| `vpc_config` | `object({ subnet_ids = list(string), security_group_ids = list(string) })` | No | `null` | Object with `subnet_ids` and `security_group_ids` lists, or `null` | VPC attachment. When set, automatically adds VPC ENI permissions to the execution role. |

### Security group

| Variable | Type | Required | Default | Accepted Values | Description |
|---|---|---|---|---|---|
| `create_security_group` | `bool` | No | `false` | `true`, `false` | Create a dedicated security group for the function. Requires `vpc_id` and `vpc_config`. |
| `vpc_id` | `string` | Conditional | `null` | Any valid VPC ID, e.g. `"vpc-0abc1234"` | VPC in which to create the SG. Required when `create_security_group = true`. |
| `security_group_name` | `string` | No | `null` | Any valid SG name | Name for the created SG. Defaults to `"<function_name>-sg"` when null. |
| `security_group_description` | `string` | No | `"Managed by Lambda Terraform module"` | Any string | Description for the created SG. |
| `ingress_rules` | `list(object)` | No | `[]` | List of objects: `from_port`, `to_port`, `protocol`, `cidr_blocks`, `security_groups`, `self`, `description` | Inbound rules for the created SG. Lambda typically needs no ingress. |
| `egress_rules` | `list(object)` | No | `[allow-all outbound]` | Same object schema as `ingress_rules` | Outbound rules. Default permits all egress (`-1` protocol, `0.0.0.0/0`). |

### IAM role & permissions

| Variable | Type | Required | Default | Accepted Values | Description |
|---|---|---|---|---|---|
| `iam_role_path` | `string` | No | `"/"` | Must start and end with `/`, e.g. `"/"`, `"/sales-automation/"` | IAM path for the execution role. |
| `permission_boundary_arn` | `string` | No | `null` | Valid IAM managed policy ARN | Permission boundary that caps maximum role permissions. |
| `extra_customer_managed_policies` | `map(object)` | No | `{}` | Map with `name`, `description` (opt), `path` (opt), `policy` (JSON). Key `"lambda_baseline"` is reserved. | Extra customer-managed policies to create and attach to the execution role. |
| `extra_customer_managed_policy_arns` | `list(string)` | No | `[]` | List of valid IAM policy ARNs | Pre-existing customer-managed policy ARNs to attach. |
| `extra_aws_managed_policy_arns` | `list(string)` | No | `[]` | AWS-managed ARNs e.g. `"arn:aws:iam::aws:policy/AmazonDynamoDBReadOnlyAccess"` | AWS-managed policies to attach. Use sparingly — prefer narrow customer-managed policies. |
| `extra_inline_policies` | `map(string)` | No | `{}` | Map of `policy_name = json_document` | Inline policy documents embedded directly in the role. Use only for role-specific explicit Denys. |

### Layers, DLQ & observability

| Variable | Type | Required | Default | Accepted Values | Description |
|---|---|---|---|---|---|
| `additional_layer_arns` | `list(string)` | No | `[]` | List of valid Lambda layer ARNs | Extra layers to attach. Maximum 5 total (including the auto-generated dependency layer). |
| `dead_letter_target_arn` | `string` | No | `null` | SQS queue ARN or SNS topic ARN | Dead-letter destination for events that exhaust all retries. |
| `tracing_mode` | `string` | No | `"PassThrough"` | `"PassThrough"`, `"Active"` | X-Ray tracing. `"Active"` samples all requests and adds X-Ray permissions to the role. |
| `log_retention_in_days` | `number` | No | `14` | `1`, `3`, `5`, `7`, `14`, `30`, `60`, `90`, `120`, `150`, `180`, `365`, `400`, `545`, `731`, `1827`, `3653`, `0` (unlimited) | CloudWatch log retention period in days. |
| `log_kms_key_id` | `string` | No | `null` | KMS key ARN | KMS key for encrypting the CloudWatch log group. |

### Invoke permissions

All six permission variables share the same object schema:

```
list(object({
  statement_id   = string          # unique SID in the resource-based policy
  source_arn     = string          # ARN of the invoking resource
  source_account = optional(string, null)  # account ID (prevents confused-deputy)
  qualifier      = optional(string, null)  # function alias or version
}))
```

| Variable | Type | Required | Default | Accepted Values | Description |
|---|---|---|---|---|---|
| `s3_invoke_permissions` | `list(object)` | No | `[]` | List of permission objects (schema above) | Grant S3 buckets permission to invoke this function. |
| `api_gateway_invoke_permissions` | `list(object)` | No | `[]` | List of permission objects — `source_arn` typically ends with `/*/*` | Grant API Gateway stages/methods permission to invoke this function. |
| `sns_invoke_permissions` | `list(object)` | No | `[]` | List of permission objects (schema above) | Grant SNS topics permission to invoke this function. |
| `sqs_invoke_permissions` | `list(object)` | No | `[]` | List of permission objects (schema above) | Grant SQS queues permission via resource-based policy. Not needed for standard ESM pattern. |
| `eventbridge_invoke_permissions` | `list(object)` | No | `[]` | List of permission objects (schema above) | Grant EventBridge rules permission to invoke this function. |
| `alb_invoke_permissions` | `list(object)` | No | `[]` | List of permission objects (schema above) | Grant ALB target groups permission to invoke this function. |

### Tags

| Variable | Type | Required | Default | Accepted Values | Description |
|---|---|---|---|---|---|
| `tags` | `map(string)` | No | `{}` | Any `{ key = "value" }` map | Tags applied to all resources created by this module. |

---

## Outputs

| Output | Description |
|---|---|
| `function_arn` | Unqualified function ARN |
| `function_name` | Function name |
| `function_invoke_arn` | Invoke ARN for API Gateway |
| `function_qualified_arn` | Versioned ARN (when `publish = true`) |
| `function_version` | Published version number |
| `source_code_hash` | Base64 SHA-256 of the deployment zip |
| `function_zip_path` | Local path to the built deployment zip |
| `role_arn` | Execution role ARN |
| `role_name` | Execution role name |
| `role_id` | Execution role ID |
| `log_group_name` | CloudWatch log group name |
| `log_group_arn` | CloudWatch log group ARN |
| `has_layer` | `true` when `requirements.txt` was found and a layer was built |
| `layer_arn` | Layer ARN including version number (`null` when no layer) |
| `layer_version_number` | Layer version number (`null` when no layer) |
| `layer_s3_key` | S3 key of the layer zip (`null` when no layer) |
| `security_group_id` | ID of the module-created SG (`null` when not created) |
| `security_group_arn` | ARN of the module-created SG (`null` when not created) |
| `effective_security_group_ids` | All SG IDs actually attached to the Lambda VPC config |

---

## Notes

- The `functions/` source directory should **not** contain a `.gitignore` that excludes Python files — the module zips everything it finds (except `requirements.txt`).
- Add `modules/lambda/.build/*.zip` to your root `.gitignore` to avoid committing generated artefacts.
- For non-Python runtimes, the `requirements.txt` auto-build does not apply. Supply pre-built layers via `additional_layer_arns`.
