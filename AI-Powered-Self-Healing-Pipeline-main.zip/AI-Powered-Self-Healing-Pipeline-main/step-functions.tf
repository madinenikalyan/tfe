################################################################################
# STEP FUNCTIONS
#
# All Step Functions state machine module calls live here.
# Add a new state machine by adding an entry to var.step_functions in your
# tfvars file.
# The state machine name becomes: <env>-<project>-<key>
#
# Workflow definitions live under config/ as .asl.json files.
# Template variables (definition_vars) let you inject Lambda ARNs, account IDs,
# etc. at plan time so the same definition works across dev / uat / prod.
#
# Lambda invoke permissions are auto-wired via lambda_invoke_keys — just list
# the keys from var.lambda_functions and the IAM policy is generated.
################################################################################

################################################################################
# IAM — Lambda invoke policy (auto-generated per state machine)
#
# When lambda_invoke_keys is non-empty, this builds a policy granting
# lambda:InvokeFunction on the listed Lambda functions. No manual IAM wiring.
################################################################################

data "aws_iam_policy_document" "sfn_lambda_invoke" {
  for_each = {
    for k, v in var.step_functions : k => v if length(v.lambda_invoke_keys) > 0
  }

  statement {
    sid    = "InvokeLambdaFunctions"
    effect = "Allow"
    actions = [
      "lambda:InvokeFunction",
    ]
    resources = [
      for lk in each.value.lambda_invoke_keys :
      module.lambda_functions[lk].function_arn
    ]
  }
}

################################################################################
# Step Functions — for_each over var.step_functions
################################################################################

module "step_functions" {
  for_each = var.step_functions
  source   = "./modules/step-functions"

  name       = "${local.name_prefix}-${each.key}"
  type       = each.value.type
  account_id = data.aws_caller_identity.current.account_id
  aws_region = var.aws_region

  definition = templatefile(each.value.definition_file, merge(
    {
      environment  = var.environment
      project_name = var.project_name
      account_id   = data.aws_caller_identity.current.account_id
      region       = var.aws_region
    },
    each.value.definition_vars
  ))

  inline_policies = merge(
    length(each.value.lambda_invoke_keys) > 0 ? {
      lambda-invoke = data.aws_iam_policy_document.sfn_lambda_invoke[each.key].json
    } : {},
    lookup(local.sfn_extra_inline_policies, each.key, {})
    
  )

  tags = merge(local.common_tags, each.value.tags, {
    Name = "${local.name_prefix}-${each.key}"
  })
}
