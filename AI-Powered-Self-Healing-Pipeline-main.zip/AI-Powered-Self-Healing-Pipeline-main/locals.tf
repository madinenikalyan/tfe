locals {
  name_prefix = "${var.environment}-${var.project_name}"

  az_suffixes = var.availability_zones # e.g. ["us-east-1a", "us-east-1b"]

  common_tags = {
    Environment = var.environment
    Project     = var.project_name
    ManagedBy   = "terraform"
    # Maintainer   = var.maintainer
  }

  lambda_extra_policies = {
    "sales-automation-vbr-service" = {
      aurora_secrets_access = {
        name        = "${local.name_prefix}-vbr-service-aurora-secrets"
        description = "Allow VBR service Lambda to read its database user secret"
        policy = jsonencode({
          Version = "2012-10-17"
          Statement = [
            {
              Sid    = "ReadUserSecret"
              Effect = "Allow"
              Action = [
                "secretsmanager:GetSecretValue",
                "secretsmanager:DescribeSecret"
              ]
              Resource = [
                module.db_user_secrets["vbr-service"].secret_arn
              ]
            },
            {
              Sid    = "DecryptAuroraSecrets"
              Effect = "Allow"
              Action = [
                "kms:Decrypt"
              ]
              Resource = [
                module.aurora_postgres.kms_key_arn
              ]
            }
          ]
        })
      }
    }

    "sales-automation-db-user-manager" = {
      aurora_admin_access = {
        name        = "${local.name_prefix}-db-user-manager-admin-access"
        description = "Allow DB user manager Lambda to read admin secret"
        policy = jsonencode({
          Version = "2012-10-17"
          Statement = [
            {
              Sid    = "ReadAdminSecret"
              Effect = "Allow"
              Action = [
                "secretsmanager:GetSecretValue",
                "secretsmanager:DescribeSecret"
              ]
              Resource = [
                module.aurora_postgres.connection_secret_arn,
                module.aurora_postgres.master_user_secret_arn
              ]
            },
            {
              Sid    = "DecryptSecrets"
              Effect = "Allow"
              Action = [
                "kms:Decrypt",
                "kms:DescribeKey",
                "kms:GenerateDataKey"
              ]
              Resource = [
                module.aurora_postgres.kms_key_arn
              ]
            }
          ]
        })
      }
    }
  }

  lambda_env_variables = {
    "sales-automation-vbr-service" = {
      DB_SECRET_ARN = module.db_user_secrets["vbr-service"].secret_arn
    }
    "sales-automation-db-user-manager" = {
      ADMIN_SECRET_ARN = module.aurora_postgres.connection_secret_arn
    }
  }

  # ── Step Functions — extra inline policies ────────────────────────────────
  # Same pattern as lambda_extra_policies. Define IAM policies here that
  # reference dynamic Terraform resources (Lambda ARNs, S3 buckets, secrets,
  # etc.). The map key must match the step_functions key in tfvars.
  #
  # Example:
  #   "my-workflow" = {
  #     invoke-lambdas = jsonencode({
  #       Version = "2012-10-17"
  #       Statement = [{
  #         Effect   = "Allow"
  #         Action   = ["lambda:InvokeFunction"]
  #         Resource = [module.lambda_functions["my-function"].function_arn]
  #       }]
  #     })
  #   }
  sfn_extra_inline_policies = {
    # "test-workflow" = {}
  }
}
