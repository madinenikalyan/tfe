################################################################################
# API GATEWAY — Sales Automation REST APIs
#
# API definitions live in tfvars/<env>.tfvars under the api_gateways variable.
# Environments that don't need APIs simply omit the variable (defaults to {}).
#
# Methods reference Lambda functions via lambda_key — the key must match
# an entry in var.lambda_functions / module.lambda_functions.
#
# Module defaults (applied unless overridden):
#   endpoint_type   = "REGIONAL"
#   authorization   = "NONE"
#   integration_type = "AWS_PROXY"
################################################################################

module "api_gateways" {
  for_each = var.api_gateways
  source   = "./modules/api-gateway"

  api_name    = "${local.name_prefix}-${each.key}"
  description = each.value.description

  endpoint_configuration = {
    types            = [each.value.endpoint_type]
    vpc_endpoint_ids = null
  }

  environment = var.environment

  # ── Resources (paths) ───────────────────────────────────────────────────────
  resources = each.value.resources

  # ── Methods + Integrations ──────────────────────────────────────────────────
  # Resolve each method's lambda_key → actual Lambda invoke ARN
  methods = {
    for method_key, method in each.value.methods : method_key => {
      resource_key     = method.resource_key
      http_method      = method.http_method
      authorization    = method.authorization
      api_key_required = method.api_key_required

      integration = {
        type = method.integration_type
        uri  = module.lambda_functions[method.lambda_key].function_invoke_arn
      }
    }
  }

  # ── Lambda invoke permissions ───────────────────────────────────────────────
  # One permission per unique Lambda function referenced by this API's methods
  lambda_invoke_permissions = {
    for lambda_key in distinct([for m in each.value.methods : m.lambda_key]) : lambda_key => {
      function_name = module.lambda_functions[lambda_key].function_name
    }
  }

  # ── API Keys & Usage Plans ─────────────────────────────────────────────────
  api_keys    = each.value.api_keys
  usage_plans = each.value.usage_plans

  tags = local.common_tags
}
