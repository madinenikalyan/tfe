################################################################################
# COMMON VARIABLES
################################################################################

variable "aws_region" {
  description = "AWS region to deploy resources"
  type        = string
  default     = "us-east-1"
}

variable "environment" {
  description = "Environment name (e.g., uat, prod, dev)"
  type        = string
}

variable "project_name" {
  description = "Project name used for resource naming and tagging"
  type        = string
  default     = "sales-automation"
}

variable "availability_zones" {
  description = "List of availability zones to use for subnets"
  type        = list(string)
}

variable "maintainer" {
  description = "Maintainer contact for the infrastructure"
  type        = string
  default     = "BGangadhar@tegna.com"
}

################################################################################
# VPC SETUP VARIABLES
################################################################################

variable "vpc_cidr" {
  description = "CIDR block for the VPC"
  type        = string
}

variable "public_subnet_cidrs" {
  description = "List of CIDR blocks for public subnets (one per AZ)"
  type        = list(string)
}

variable "private_lambda_subnet_cidrs" {
  description = "List of CIDR blocks for private Lambda subnets (one per AZ)"
  type        = list(string)
}

variable "private_db_subnet_cidrs" {
  description = "List of CIDR blocks for private database subnets (one per AZ)"
  type        = list(string)
}

variable "private_glue_subnet_cidr" {
  description = "CIDR block for the private Glue subnet in us-east-1b"
  type        = string
}


variable "enable_dns_support" {
  description = "Enable DNS support in the VPC"
  type        = bool
  default     = true
}

variable "enable_dns_hostnames" {
  description = "Enable DNS hostnames in the VPC"
  type        = bool
  default     = true
}

variable "enable_nat_gateway" {
  description = "Enable NAT Gateway for private subnets"
  type        = bool
  default     = true
}

################################################################################
# VPC FLOW LOG VARIABLES
################################################################################

variable "enable_flow_log" {
  description = "Enable VPC Flow Logs to S3"
  type        = bool
  default     = true
}

variable "flow_log_traffic_type" {
  description = "Type of traffic to capture. Valid values: ACCEPT, REJECT, ALL"
  type        = string
  default     = "ALL"
}

variable "flow_log_max_aggregation_interval" {
  description = "Max interval (seconds) for flow log aggregation. Valid values: 60, 600"
  type        = number
  default     = 600
}


################################################################################
# GLUE JOBS
################################################################################

variable "glue_jobs" {
  description = "Map of Glue jobs to deploy. The map key is used as the job name suffix. Omit entirely (defaults to {}) in environments that don't need Glue jobs."
  type = map(object({
    description           = optional(string, "")
    job_source_dir        = string
    script_filename       = string
    default_arguments     = optional(map(string), {})
    number_of_workers     = optional(number, 2)
    timeout               = optional(number, 2800)
    max_concurrent_runs   = optional(number, 2)
    log_retention_in_days = optional(number, 30)
    create_trigger        = optional(bool, false)
    trigger_schedule      = optional(string, null)
    trigger_description   = optional(string, null)

    # Crawler settings
    create_crawler        = optional(bool, false)
    crawler_description   = optional(string, "")
    crawler_database_name = optional(string, null)
    crawler_table_prefix  = optional(string, null)
    crawler_schedule      = optional(string, null)
    crawler_s3_targets = optional(list(object({
      path            = string
      exclusions      = optional(list(string), [])
      connection_name = optional(string)
    })), [])
    crawler_jdbc_targets = optional(list(object({
      connection_name = string
      path            = string
      exclusions      = optional(list(string), [])
    })), [])

    # Extra IAM access (per-job) — use keys from s3_buckets and db_users maps
    extra_s3_bucket_keys = optional(list(string), [])
    extra_secret_keys    = optional(list(string), [])
  }))
  default = {}
}

################################################################################
# LAMBDA FUNCTIONS
################################################################################

variable "lambda_functions" {
  description = "Map of Lambda functions to deploy. The map key is used as the function name."

  type = map(object({
    source_path           = string
    description           = optional(string, "")
    environment_variables = optional(map(string), {})
    tags                  = optional(map(string), {})
  }))
  default = {}
}

variable "s3_buckets" {
  description = "Map of S3 buckets to create. The map key is a logical identifier for the bucket."
  type = map(object({
    bucket_suffix          = string
    versioning_enabled     = optional(bool, false)
    enable_kms             = optional(bool, false)
    force_destroy          = optional(bool, false)
    enable_lifecycle_rules = optional(bool, true)
    enable_bucket_policy   = optional(bool, true)
    policy_template_path   = optional(string, null)
    principal_arn          = optional(string, null)
    extra_tags             = optional(map(string), {})
  }))
  default = {}
}

################################################################################
# STEP FUNCTIONS
################################################################################

variable "step_functions" {
  description = "Map of Step Functions state machines to deploy. The map key is used as the name suffix."
  type = map(object({
    description            = optional(string, "")
    type                   = optional(string, "STANDARD")
    definition_file        = string
    definition_vars        = optional(map(string), {})
    lambda_invoke_keys     = optional(list(string), [])
    extra_inline_policies  = optional(map(string), {})
    tags                   = optional(map(string), {})
  }))
  default = {}
}

################################################################################
# API GATEWAYS
################################################################################

variable "api_gateways" {
  description = <<-EOT
    Map of API Gateway REST APIs to deploy. The map key is used as the API name suffix.

    Methods reference Lambda functions via lambda_key — the key must match
    an entry in var.lambda_functions. The module resolves it to the actual
    invoke ARN at plan time.

    Example:
      api_gateways = {
        "my-api" = {
          description   = "My REST API"
          endpoint_type = "REGIONAL"
          resources = {
            "users" = { path_part = "users" }
          }
          methods = {
            "users-post" = {
              resource_key = "users"
              http_method  = "POST"
              lambda_key   = "my-lambda-function"
            }
          }
        }
      }
  EOT
  type = map(object({
    description   = optional(string, "")
    endpoint_type = optional(string, "REGIONAL")

    resources = optional(map(object({
      path_part  = string
      parent_key = optional(string)
    })), {})

    methods = optional(map(object({
      resource_key     = string
      http_method      = string
      authorization    = optional(string, "NONE")
      api_key_required = optional(bool, false)
      integration_type = optional(string, "AWS_PROXY")
      lambda_key       = string
    })), {})

    # API Keys
    api_keys = optional(map(object({
      name        = string
      description = optional(string, "")
      enabled     = optional(bool, true)
      value       = optional(string)
    })), {})

    # Usage Plans (throttling, quotas, API key association)
    usage_plans = optional(map(object({
      name          = string
      description   = optional(string, "")
      api_key_names = optional(list(string), [])

      throttle = optional(object({
        burst_limit = optional(number, 5000)
        rate_limit  = optional(number, 10000)
      }), { burst_limit = 5000, rate_limit = 10000 })

      quota = optional(object({
        limit  = optional(number, 50000)
        offset = optional(number, 0)
        period = optional(string, "MONTH")
      }), { limit = 50000, offset = 0, period = "MONTH" })
    })), {})
  }))
  default = {}
}

variable "s3_lifecycle_rules" {
  description = "Shared lifecycle rules applied to every bucket that has enable_lifecycle_rules = true."
  type = list(object({
    id      = string
    enabled = bool
    prefix  = optional(string, null)

    transitions = optional(list(object({
      days          = number
      storage_class = string
    })), [])

    noncurrent_version_transitions = optional(list(object({
      noncurrent_days = number
      storage_class   = string
    })), [])

    expiration = optional(object({
      days                         = optional(number, null)
      expired_object_delete_marker = optional(bool, null)
    }), null)

    noncurrent_version_expiration = optional(object({
      noncurrent_days = number
    }), null)

    abort_incomplete_multipart_upload_days = optional(number, null)
  }))
  default = [
    {
      id      = "transition-to-glacier"
      enabled = true
      transitions = [
        {
          days          = 180
          storage_class = "GLACIER"
        }
      ]
      abort_incomplete_multipart_upload_days = 7
    }
  ]
}

################################################################################
# AURORA RDS
################################################################################

variable "aurora_instance_class" {
  description = "DB instance class for the Aurora cluster (e.g. db.serverless, db.r6g.large, db.r6g.xlarge)"
  type        = string
  default     = "db.serverless"
}

variable "aurora_database_name" {
  description = "Name of the initial database to create in the Aurora cluster"
  type        = string
  default     = "sales_automation"
}

variable "aurora_master_username" {
  description = "Master username for the Aurora cluster"
  type        = string
  default     = "salesadmin"
}

variable "aurora_engine_version" {
  description = "Aurora PostgreSQL engine version"
  type        = string
  default     = "17.4"
}

variable "aurora_parameter_group_family" {
  description = "Aurora parameter group family"
  type        = string
  default     = "aurora-postgresql17"
}

variable "aurora_min_capacity" {
  description = "Minimum ACU capacity for Aurora Serverless v2 scaling"
  type        = number
  default     = 0.5
}

variable "aurora_max_capacity" {
  description = "Maximum ACU capacity for Aurora Serverless v2 scaling"
  type        = number
  default     = 16
}

variable "aurora_backup_retention_period" {
  description = "Number of days to retain automated backups (1-35)"
  type        = number
  default     = 7
}

################################################################################
# VPC ENDPOINTS
################################################################################

variable "vpc_endpoints" {
  description = "Map of VPC endpoints to create. Key is a logical name, value defines the endpoint configuration."
  type = map(object({
    service               = string
    endpoint_type         = optional(string, "Gateway")
    private_dns_enabled   = optional(bool, true)
    policy                = optional(string, null)
    attach_to_all_private = optional(bool, true)
  }))
  default = {
    s3 = {
      service       = "s3"
      endpoint_type = "Gateway"
    }
    secretsmanager = {
      service       = "secretsmanager"
      endpoint_type = "Interface"
    }
  }
}

################################################################################
# DATABASE USERS
################################################################################

variable "db_users" {
  description = "Map of database users to create. Key is the service name (used in secret name), value contains the PostgreSQL username."
  type = map(object({
    username = string
  }))
  default = {}
}

################################################################################
# KEYPAIR SECRETS
################################################################################

variable "keypairs" {
  description = <<-EOT
    Map of RSA keypairs to generate and store in Secrets Manager.
    Key = logical name (used in secret path), value = configuration.

    Secret naming: <env>-<project>/<key>-private-key
                   <env>-<project>/<key>-public-key

    Example:
      keypairs = {
        "snowflake" = {
          algorithm = "RSA"
          rsa_bits  = 4096
        }
        "sftp" = {
          algorithm = "RSA"
          rsa_bits  = 2048
        }
      }
  EOT
  type = map(object({
    algorithm = optional(string, "RSA")
    rsa_bits  = optional(number, 4096)
  }))
  default = {}
}

