# ################################################################################
# # AURORA SERVERLESS v2 — POSTGRESQL
# ################################################################################

module "aurora_postgres" {
  source = "./modules/aurora-serverless"

  account_id = data.aws_caller_identity.current.account_id
  aws_region = var.aws_region

  cluster_identifier = "${local.name_prefix}-aurora-postgres"
  database_name      = var.aurora_database_name
  master_username    = var.aurora_master_username

  engine                 = "aurora-postgresql"
  engine_version         = var.aurora_engine_version
  parameter_group_family = var.aurora_parameter_group_family

  vpc_id     = aws_vpc.sales_automation_vpc.id
  subnet_ids = aws_subnet.sales_automation_private_db_subnet[*].id

  ingress_rules = [
    {
      description = "PostgreSQL from Lambda subnets"
      from_port   = 5432
      to_port     = 5432
      protocol    = "tcp"
      cidr_blocks = aws_subnet.sales_automation_private_lambda_subnet[*].cidr_block
    },
    {
      description = "PostgreSQL from Glue subnet"
      from_port   = 5432
      to_port     = 5432
      protocol    = "tcp"
      cidr_blocks = [aws_subnet.sales_automation_private_glue_subnet.cidr_block]
    },
  ]

  instance_class = var.aurora_instance_class
  min_capacity   = var.aurora_min_capacity
  max_capacity   = var.aurora_max_capacity

  instances = {
    "writer" = {
      promotion_tier    = 0
      availability_zone = aws_subnet.sales_automation_private_db_subnet[0].availability_zone
    }
    "reader" = {
      promotion_tier    = 1
      availability_zone = aws_subnet.sales_automation_private_db_subnet[1].availability_zone
    }
  }

  backup_retention_period = var.aurora_backup_retention_period
  deletion_protection = true
  skip_final_snapshot     = var.environment == "prod" ? false : true

  tags = local.common_tags
}
