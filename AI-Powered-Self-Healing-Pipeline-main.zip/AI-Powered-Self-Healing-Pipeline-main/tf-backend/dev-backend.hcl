bucket       = ""
key          = "sales-automation/dev-new/dev.tfstate"
region       = "us-east-1"
encrypt      = true
use_lockfile = true
