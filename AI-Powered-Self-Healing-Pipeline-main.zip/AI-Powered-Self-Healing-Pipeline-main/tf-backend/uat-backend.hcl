bucket       = "tegna-sales-automation-tfstate-uat"
key          = "sales-automation/uat-new/uat.tfstate"
region       = "us-east-1"
encrypt      = true
use_lockfile = true
