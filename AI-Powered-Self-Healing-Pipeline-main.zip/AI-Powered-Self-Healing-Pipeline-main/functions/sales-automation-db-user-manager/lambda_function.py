import os
import json
import boto3
import logging
import psycopg2

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

secrets_client = boto3.client("secretsmanager")


def get_secret(secret_arn: str) -> dict:
    """Fetch and parse a Secrets Manager secret."""
    resp = secrets_client.get_secret_value(SecretId=secret_arn)
    if "SecretString" in resp:
        return json.loads(resp["SecretString"])
    raise RuntimeError("SecretString not found in secret.")


def get_admin_secret():
    """Fetch admin connection secret — contains host, port, database, etc."""
    secret_arn = os.environ["ADMIN_SECRET_ARN"]
    return get_secret(secret_arn)


def get_admin_connection():
    """Connect to PostgreSQL using the admin connection secret."""
    s = get_admin_secret()

    conn = psycopg2.connect(
        host=s["host"],
        port=int(s.get("port", 5432)),
        user=s["username"],
        password=s["password"],
        dbname=s.get("database"),
        sslmode="require",
    )
    conn.autocommit = True
    return conn


def user_exists(cur, username: str) -> bool:
    """Check if a PostgreSQL role already exists."""
    cur.execute(
        "SELECT 1 FROM pg_catalog.pg_roles WHERE rolname = %s", (username,)
    )
    return cur.fetchone() is not None


def grant_schema_privileges(cur, username: str):
    """Grant USAGE and CREATE on public schema, and ALL on public tables."""
    ident = psycopg2.extensions.quote_ident(username, cur)
    cur.execute("GRANT USAGE, CREATE ON SCHEMA public TO {}".format(ident))
    cur.execute("GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO {}".format(ident))
    cur.execute("ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL PRIVILEGES ON TABLES TO {}".format(ident))
    logger.info("Granted schema privileges to: %s", username)


def create_db_user(cur, username: str, password: str):
    """Create a PostgreSQL user with LOGIN, connect, and schema privileges."""
    # Use format with identifier quoting for safety
    cur.execute(
        "CREATE ROLE {} LOGIN PASSWORD %s".format(
            psycopg2.extensions.quote_ident(username, cur)
        ),
        (password,),
    )
    grant_schema_privileges(cur, username)
    logger.info("Created user: %s", username)


def lambda_handler(event, context):
    """
    Event payload:
    {
        "users": {
            "vbr-service": {
                "username": "vbr_service_user",
                "password": "...",
                "secret_arn": "arn:aws:secretsmanager:..."
            },
            ...
        }
    }

    Connection info (host, port, database, etc.) is fetched from the
    ADMIN_SECRET_ARN environment variable — no need to pass it in the payload.
    """
    # Support both direct invoke and API Gateway proxy
    if isinstance(event.get("body"), str):
        payload = json.loads(event["body"])
    else:
        payload = event

    users = payload.get("users", {})

    if not users:
        return {"statusCode": 200, "body": json.dumps({"message": "No users to process"})}

    conn = None
    results = {"created": [], "existing": [], "errors": []}

    try:
        conn = get_admin_connection()
        cur = conn.cursor()

        # Log all existing PostgreSQL users (excluding system roles)
        cur.execute(
            "SELECT rolname FROM pg_catalog.pg_roles "
            "WHERE rolname NOT LIKE 'pg_%' AND rolname NOT LIKE 'rds%' "
            "ORDER BY rolname"
        )
        all_users = [row[0] for row in cur.fetchall()]
        logger.info("All PostgreSQL users: %s", all_users)

        for service_name, user_config in users.items():
            username = user_config["username"]
            password = user_config["password"]

            try:
                if user_exists(cur, username):
                    grant_schema_privileges(cur, username)
                    logger.info("User %s already exists, granted privileges", username)
                    results["existing"].append(username)
                else:
                    create_db_user(cur, username, password)
                    results["created"].append(username)

            except Exception as e:
                logger.error("Error processing user %s: %s", username, str(e))
                results["errors"].append({"user": username, "error": str(e)})

        # Log all users after processing to confirm creation
        cur.execute(
            "SELECT rolname FROM pg_catalog.pg_roles "
            "WHERE rolname NOT LIKE 'pg_%' AND rolname NOT LIKE 'rds%' "
            "ORDER BY rolname"
        )
        all_users_after = [row[0] for row in cur.fetchall()]
        logger.info("All PostgreSQL users after processing: %s", all_users_after)
        results["all_users"] = all_users_after

        # Log all tables in the database
        cur.execute(
            "SELECT schemaname, tablename FROM pg_catalog.pg_tables "
            "WHERE schemaname NOT IN ('pg_catalog', 'information_schema') "
            "ORDER BY schemaname, tablename"
        )
        all_tables = [f"{row[0]}.{row[1]}" for row in cur.fetchall()]
        logger.info("All tables in database: %s", all_tables)
        results["all_tables"] = all_tables

        return {
            "statusCode": 200,
            "body": json.dumps(results),
        }

    except Exception as e:
        logger.error("Fatal error: %s", str(e))
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)}),
        }

    finally:
        if conn and not conn.closed:
            conn.close()
