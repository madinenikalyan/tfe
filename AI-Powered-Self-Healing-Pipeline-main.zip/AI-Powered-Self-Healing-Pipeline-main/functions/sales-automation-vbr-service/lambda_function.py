import os
import json
import boto3
import logging
import psycopg2
from psycopg2.extras import RealDictCursor

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

secrets_client = boto3.client("secretsmanager")
_conn = None

def get_db_secret(secret_arn: str) -> dict:
    """Fetch and parse the DB secret JSON from Secrets Manager."""
    resp = secrets_client.get_secret_value(SecretId=secret_arn)
    if "SecretString" in resp:
        return json.loads(resp["SecretString"])
    raise RuntimeError("SecretString not found in secret.")

def get_connection():
    # Read the secret ARN from env var
    secret_arn = os.environ["DB_SECRET_ARN"]

    s = get_db_secret(secret_arn)

    # Expected keys: host, port, username, password, dbname (or database)
    host = s["host"]
    port = int(s.get("port", 5432))
    user = s["username"]
    password = s["password"]
    dbname = s.get("dbname") or s.get("database")
    
    # Create psycopg2 connection (TLS required)
    conn = psycopg2.connect(
        host=host,
        port=port,
        user=user,
        password=password,
        dbname=dbname,
        sslmode="require"
    )
    logger.info(f"conn: {conn}")
    return conn

def normalize_markets(market_value):
    markets = []
    if isinstance(market_value, str):
        market = market_value.strip()
        if market:
            markets = [market]
    elif isinstance(market_value, list):
        for item in market_value:
            if isinstance(item, str):
                market = item.strip()
                if market:
                    markets.append(market)
    # Deduplicate while preserving order
    seen = set()
    normalized = []
    for market in markets:
        if market not in seen:
            normalized.append(market)
            seen.add(market)
    return normalized

# ---------- Helpers ----------
def parse_event(event):
    """
    Supports both:
    - Direct Lambda invoke: event is already a dict.
    - API Gateway proxy: event['body'] is a JSON string.
    Returns (market, advertiser)
    """
    payload = event
    if isinstance(event, dict) and "body" in event:
        # API Gateway HTTP API/REST API proxy
        try:
            body = event["body"]
            payload = json.loads(body) if isinstance(body, str) else body
        except Exception:
            payload = {}

    
    # Required: market and no_of_records
    markets = normalize_markets(payload.get("market"))
    advertiser = payload.get("advertiser")
    advertiser = advertiser.replace("'", '"') 
    # print(advertiser)
    

    # Validation & defaults
    errors = []
    if not advertiser:
        errors.append("advertiser is required.")

    if errors:
        return None, None, errors

    return markets, advertiser, None

def query_records(conn, markets: list, advertiser: str):
    """
    Query tegna_abacus.vbr with:
      - WHERE market IN (%s, %s, ...)
      - Optional AND advertiser = %s
      - ORDER BY created_at DESC

    Adjust selected columns as per your schema.
    """
    # Base SQL with required advertiser filter
    base_sql = """
        SELECT
            v.market,
            v.advertiser,
            v.vbr,
            e.email_subject, 
            e.email_body,
            vc.voice_script
        FROM tegna_abacus.vbr v
        LEFT JOIN tegna_abacus.email e
        ON v.keystone_id = e.keystone_id
        LEFT JOIN tegna_abacus.voice_call AS vc
        ON v.keystone_id = vc.keystone_id
        WHERE v.advertiser = %s
    """
    params = [advertiser]

    # Optional market filter if markets provided
    if markets and len(markets) > 0:
        market_placeholders = ",".join(["%s"] * len(markets))
        base_sql += f" AND v.market IN ({market_placeholders})"
        params.extend(markets)

    with conn.cursor(cursor_factory=RealDictCursor) as cur:
        cur.execute("SET statement_timeout TO '5s';")
        cur.execute(base_sql, params)
        rows = cur.fetchall()
        # RealDictCursor returns dict rows that serialize nicely
        return rows

def lambda_handler(event, context):

    global _conn

    # Parse the input payload
    markets, advertiser, errors = parse_event(event)
    if errors:
        return {
            "statusCode": 400,
            "body": json.dumps({"errors": errors})
        }

    # Ensure we have a live connection (and recreate on failure)
    try:
        if _conn is None or _conn.closed:
            _conn = get_connection()

        rows = query_records(_conn, markets, advertiser)

        return {
            "statusCode": 200,
            "data": rows
            }


    except Exception as e:
        # Any other error
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }

    finally:
        # Ensure the connection is closed (even on errors)
        try:
            if _conn  in locals() and not _conn.closed:
                _conn.close()
        except Exception:
            pass