# TEGNA Sales Automation Infrastructure


Terraform-managed AWS infrastructure for Sales Automation data pipeline.

## Project Overview

| Component | Details |
|-----------|---------|
| **Cloud Provider** | AWS |
| **Region** | us-east-1 |
| **IaC Tool** | Terraform v1.9.8 |
| **CI/CD** | GitHub Actions |
| **Repository** | [TegnaDataTeam/sales-automation](https://github.com/TegnaDataTeam/sales-automation) |

## AWS Accounts

| Environment | Account ID | Branch |
|-------------|------------|--------|
| DEV | 591098698873 | `dev` |
| UAT | 104350167801 | `uat` |
| PROD | TBD | `main` |

## Repository Structure

```
sales-automation/
├── modules/                    # Reusable Terraform modules
│   ├── aurora/                 # Aurora PostgreSQL cluster
│   ├── lambda/                 # Lambda functions
│   ├── glue/                   # Glue jobs and crawlers
│   ├── vpc/                    # VPC configuration
│   ├── subnets/                # Subnet configuration
│   ├── secretmanager/          # Secrets Manager
│   └── ...                     # Other modules
├── env/
│   ├── dev/                    # DEV environment
│   │   ├── main.tf
│   │   ├── variables.tf
│   │   ├── terraform.tfvars
│   │   ├── provider.tf
│   │   ├── backend.tf
│   │   └── backend.s3.hcl
│   └── uat/                    # UAT environment
│       ├── main.tf
│       ├── variables.tf
│       ├── terraform.tfvars
│       ├── provider.tf
│       ├── backend.tf
│       └── backend.s3.hcl
├── code/
│   ├── glue/                   # Glue job Python scripts
│   └── lambda/                 # Lambda function code
├── scripts/                    # Deployment scripts
└── .github/workflows/          # GitHub Actions CI/CD
```

## Infrastructure Components

- **VPC** - Virtual Private Cloud with public/private subnets
- **Aurora PostgreSQL** - Database cluster for sales data
- **Lambda Functions** - Serverless data processing
- **Glue Jobs** - ETL jobs for data transformation
- **Step Functions** - Workflow orchestration
- **API Gateway** - REST APIs for data access
- **S3 Buckets** - Data storage
- **Secrets Manager** - Secure credential storage
- **CloudWatch** - Monitoring and logging

## Getting Started

### Prerequisites

- AWS CLI configured with appropriate profiles
- Terraform v1.9.8+
- Git

### AWS CLI Profiles

```
~/.aws/credentials

[default]        # DEV account
aws_access_key_id = xxx
aws_secret_access_key = xxx

[uat]            # UAT account
aws_access_key_id = xxx
aws_secret_access_key = xxx
```

### Deploy to DEV

```powershell
cd env/dev
terraform init -backend-config=backend.s3.hcl
terraform plan
terraform apply
```

### Deploy to UAT

```powershell
$env:AWS_PROFILE = "uat"
cd env/uat
terraform init -backend-config=backend.s3.hcl
terraform plan
terraform apply
```

## Branch Strategy

| Branch | Purpose | Deployment |
|--------|---------|------------|
| `main` | Production code | Manual / Protected |
| `dev` / `develop` | DEV environment | CI/CD via GitHub Actions |
| `uat` / `QA` | UAT environment | CI/CD via GitHub Actions |
| `feature/*` | Feature development | Pipeline runs on PR |

### Workflow

1. Create a `feature/*` branch from `dev` (for DEV) or `uat` (for UAT)
2. Make changes and push to the feature branch
3. Create a PR targeting `dev` or `uat`
4. Pipeline runs automatically and posts the Terraform plan to the PR
5. Review the plan, get PR approved, and merge
6. Pipeline applies the changes to the target environment

## CI/CD Pipelines

GitHub Actions workflows are configured in `.github/workflows/`:

| Workflow | PR Trigger | Push Trigger | Action |
|----------|-----------|-------------|--------|
| `develop-pipeline.yml` | PR to `dev` / `develop` | Push to `dev` / `develop` | Plan and Apply to DEV |
| `uat-pipeline.yml` | PR to `uat` / `QA` | Push to `uat` / `QA` | Plan and Apply to UAT |

### Pipeline Steps

1. **Build** - Packages Lambda deployment zips
2. **Terraform Plan** - Runs `terraform init`, `validate`, `plan`
3. **PR Approval** - Plan output posted as PR comment for review
4. **Deploy Approval** - Manual approval gate
5. **Terraform Apply** - Applies changes to the environment

Note: The CI pipeline uses `backend.s3.hcl` to override the `profile` setting in `backend.tf`, since GitHub Actions authenticates using IAM credentials via environment variables rather than named profiles.

## Key Contacts

- **Owner:** Manish Kumar (m.kumar@tegna.com)

## Last Updated

February 2026
