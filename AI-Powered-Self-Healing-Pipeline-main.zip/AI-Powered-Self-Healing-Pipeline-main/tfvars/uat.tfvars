################################################################################
# COMMON VARIABLES VALUES 
################################################################################

environment = "uat"

availability_zones = [
  "us-east-1a",
  "us-east-1b"
]

################################################################################
# VPC SETUP VARIABLES VALUES
################################################################################

vpc_cidr = "172.21.130.0/24"

################################################################################
# PUBLIC SUBNET VARIABLES VALUES
################################################################################

public_subnet_cidrs = [
  "172.21.130.0/28", # us-east-1a
  "172.21.130.16/28" # us-east-1b
]

################################################################################
# PRIVATE LAMBDA SUBNET VARIABLES VALUES
################################################################################

private_lambda_subnet_cidrs = [
  "172.21.130.128/28", # us-east-1a
  "172.21.130.144/28"  # us-east-1b
]

################################################################################
# PRIVATE DATABASE SUBNET VARIABLES VALUES
################################################################################

private_db_subnet_cidrs = [
  "172.21.130.160/28", # us-east-1a
  "172.21.130.176/28"  # us-east-1b
]

################################################################################
# PRIVATE GLUE SUBNET VARIABLES VALUES
################################################################################

private_glue_subnet_cidr = "172.21.130.192/26"

################################################################################
# VPC FLOW LOG VARIABLES VALUES
################################################################################

enable_flow_log       = true
flow_log_traffic_type = "ALL"

################################################################################
# AURORA RDS VARIABLES VALUES
################################################################################

aurora_instance_class          = "db.r6g.large"
aurora_database_name           = "sales_automation"
aurora_master_username         = "salesadmin"
aurora_engine_version          = "17.7"
aurora_parameter_group_family  = "aurora-postgresql17"
aurora_min_capacity            = 0.5
aurora_max_capacity            = 16
aurora_backup_retention_period = 7


################################################################################
# LAMBDA FUNCTIONS
# Add a new entry here to deploy an additional Lambda function.
# The map key becomes the function name suffix: <env>-<project>-<key>
################################################################################

lambda_functions = {

  "sales-automation-vbr-service" = {
    source_path = "functions/sales-automation-vbr-service"
    description = "VBR service — queries Aurora PostgreSQL for sales automation data"
    tags = {
      Service   = "vbr-service"
      Owner     = "p.kharade@tegna.com"
      Developer = "p.kharade@tegna.com"
      
    }
  }

  "sales-automation-db-user-manager" = {
    source_path = "functions/sales-automation-db-user-manager"
    description = "DB user manager — creates PostgreSQL users and manages their secrets"
    tags = {
      Service   = "db-user-manager"
      Owner     = "BGangadhar@tegna.com"
      Developer = "BGangadhar@tegna.com"
    }
  }

}

################################################################################
# DATABASE USERS
# Add a new entry to create a PostgreSQL user with its own Secrets Manager secret.
# Key = service name (used in secret name), username = PostgreSQL role name.
################################################################################

db_users = {

  "vbr-service" = {
    username = "sa_abacus"
  }

  "glue-service" = {
    username = "sa_glue"
  }
}

################################################################################
# KEYPAIRS
# Add a new entry to generate an RSA keypair and store it in Secrets Manager.
# Key = logical name (used in secret path).
# Secret names: <env>-<project>/<key>-private-key / <key>-public-key
################################################################################

keypairs = {
  "snowflake" = {}
}


# ################################################################################
# # GLUE JOBS — uat
# #
# # Add / remove entries here to control which Glue jobs are deployed in uat.
# # prod.tfvars and dev.tfvars omit this block entirely → no Glue jobs deployed.
# ################################################################################

glue_jobs = {
  # "create-test-table" = {
  #   description     = "Glue job — creates test_glue_table in Aurora PostgreSQL"
  #   job_source_dir  = "glue-jobs/create-test-table"
  #   script_filename = "create_test_table.py"
  #   default_arguments = {
  #     "--job-bookmark-option" = "job-bookmark-disable"
  #   }

    #Extra access — keys from s3_buckets and db_users maps
    #extra_s3_bucket_keys = ["test-bucket"]
    #extra_secret_keys    = ["vbr-service"]
  #}
}

################################################################################
# STEP FUNCTIONS
# Add a new entry here to deploy a Step Functions state machine.
# The name becomes: <env>-<project>-<key>
# Workflow definitions live under config/ as .asl.json files.
################################################################################

# step_functions = {

#   "test-workflow" = {
#     description     = "Test state machine — verifies Step Functions deployment"
#     type            = "STANDARD"
#     definition_file = "config/test-state-machine.asl.json"
#     tags = {
#       Owner     = "BGangadhar@tegna.com"
#       Developer = "BGangadhar@tegna.com"
#     }
#   }
# }

################################################################################
# S3 BUCKETS
# Add a new entry here to deploy an additional S3 bucket.
# The bucket name becomes: <env>-<project>-<bucket_suffix>
# Lifecycle rules (e.g. Glacier transition after 180 days) are shared via
# the s3_lifecycle_rules variable default.
################################################################################

# s3_buckets = {

#   "test-bucket" = {
#     bucket_suffix        = "test-bucket"
#     versioning_enabled   = false
#     enable_kms           = false
#     force_destroy        = true
#     enable_bucket_policy = true
#     policy_template_path = "config/cross-account-access-policy.json.tpl"
#     principal_arn        = "arn:aws:iam::448970459817:role/external/partner-95ac2cff0"
#     extra_tags = {
#       Owner     = "BGangadhar@tegna.com"
#       Developer = "BGangadhar@tegna.com"
#     }
#   }
# }

################################################################################
# API GATEWAYS
# Add a new entry here to deploy an additional API Gateway REST API.
# The API name becomes: <env>-<project>-<key>
# Methods reference Lambda functions via lambda_key — the key must match
# an entry in lambda_functions above.
################################################################################

api_gateways = {

  "api" = {
    description   = "Sales Automation REST API"
    endpoint_type = "REGIONAL"

    resources = {
      "vbr-service" = {
        path_part = "vbr-service"
      }
      "db-users" = {
        path_part = "db-users"
      }
    }

    methods = {
      "vbr-service-post" = {
        resource_key     = "vbr-service"
        http_method      = "POST"
        integration_type = "AWS"
        lambda_key       = "sales-automation-vbr-service"
      }

      "db-users-post" = {
        resource_key     = "db-users"
        http_method      = "POST"
        integration_type = "AWS_PROXY"
        lambda_key       = "sales-automation-db-user-manager"
      }
    }
  }

  # "leads-api" = {
  #   description   = "API for Sales Automation Leads Service"
  #   endpoint_type = "REGIONAL"

  #   resources = {
  #     "leads" = {
  #       path_part = "leads"
  #     }
  #   }

  #   methods = {
  #     "leads-post" = {
  #       resource_key     = "leads"
  #       http_method      = "POST"
  #       api_key_required = true
  #       integration_type = "AWS_PROXY"
  #       lambda_key       = "sales-automation-leads-service"
  #     }
  #   }

  #   api_keys = {
  #     "leads-key" = {
  #       name        = "sales-automation-leads-api-key"
  #       description = "API key for Leads Service"
  #     }
  #   }

  #   usage_plans = {
  #     "leads-plan" = {
  #       name          = "sales-automation-leads-usage-plan"
  #       description   = "Usage plan for Leads API"
  #       api_key_names = ["leads-key"]

  #       throttle = {
  #         burst_limit = 5000
  #         rate_limit  = 10000
  #       }

  #       quota = {
  #         limit  = 50000
  #         period = "MONTH"
  #       }
  #     }
  #   }
  # }
}