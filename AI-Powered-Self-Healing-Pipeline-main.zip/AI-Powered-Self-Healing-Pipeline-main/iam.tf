################################################################################
# iam.tf — Per-function IAM policy documents
#
# Define one data "aws_iam_policy_document" block per policy per function.
# Naming convention: <function_key>_<purpose>  (underscores, not hyphens)
#
# Reference the .json attribute inside local.lambda_extra_policies in locals.tf.
# The lambda module merges it with the shared S3 artifacts policy and attaches
# everything to that function's execution role automatically.
#
# To add policies for a NEW function:
#   1. Add data "aws_iam_policy_document" blocks here.
#   2. Add an entry in local.lambda_extra_policies in locals.tf.
#   Done — no changes to functions.tf or the lambda module are needed.
################################################################################

################################################################################
# bala-test — per-function policies
################################################################################

data "aws_iam_policy_document" "bala_test_s3_read" {
  statement {
    sid    = "S3ReadInputData"
    effect = "Allow"
    actions = [
      "s3:GetObject",
      "s3:ListBucket",
    ]
    resources = [
      "arn:aws:s3:::${local.name_prefix}-input-data",
      "arn:aws:s3:::${local.name_prefix}-input-data/*",
    ]
  }
}

data "aws_iam_policy_document" "bala_test_secretsmanager_read" {
  statement {
    sid    = "SecretsManagerRead"
    effect = "Allow"
    actions = [
      "secretsmanager:GetSecretValue",
    ]
    resources = [
      "arn:aws:secretsmanager:*:*:secret:${local.name_prefix}/bala-test/*",
    ]
  }
}

################################################################################
# bala-test-1 — per-function policies
################################################################################

data "aws_iam_policy_document" "bala_test_1_dynamodb_read" {
  statement {
    sid    = "DynamoDBRead"
    effect = "Allow"
    actions = [
      "dynamodb:GetItem",
      "dynamodb:Query",
      "dynamodb:Scan",
    ]
    resources = [
      "arn:aws:dynamodb:*:*:table/${local.name_prefix}-*",
    ]
  }
}

data "aws_iam_policy_document" "bala_test_1_sqs_send" {
  statement {
    sid    = "SQSSendMessage"
    effect = "Allow"
    actions = [
      "sqs:SendMessage",
      "sqs:GetQueueUrl",
      "sqs:GetQueueAttributes",
    ]
    resources = [
      "arn:aws:sqs:*:*:${local.name_prefix}-*",
    ]
  }
}




# ################################################################################
# # Trust policy: allow Lambda service to assume this role
# ################################################################################
# data "aws_iam_policy_document" "lambda_trust" {
#   statement {
#     sid     = "AllowLambdaAssumeRole"
#     effect  = "Allow"
#     actions = ["sts:AssumeRole"]

#     principals {
#       type        = "Service"
#       identifiers = ["lambda.amazonaws.com"]
#     }
#   }
# }

# ################################################################################
# # Permission document: scoped S3 + KMS access for Lambda functions
# ################################################################################


# data "aws_iam_policy_document" "lambda_s3_kms" {                                 # Allow reads from the raw-data bucket and writes to the processed bucket.
  
#   statement {
#     sid    = "S3ReadRaw"
#     effect = "Allow"
#     actions = [
#       "s3:GetObject",
#       "s3:ListBucket",
#     ]
#     resources = [
#       "arn:aws:s3:::${local.name_prefix}-raw-data",
#       "arn:aws:s3:::${local.name_prefix}-raw-data/*",
#     ]
#   }

#   statement {
#     sid    = "S3WriteProcessed"
#     effect = "Allow"
#     actions = [
#       "s3:PutObject",
#       "s3:DeleteObject",
#     ]
#     resources = [
#       "arn:aws:s3:::${local.name_prefix}-processed/*",
#     ]
#   }

  
#   statement {                                                                   # Allow use of the project KMS key for encrypting/decrypting S3 objects.
#     sid    = "KMSDecryptEncrypt"
#     effect = "Allow"
#     actions = [
#       "kms:Decrypt",
#       "kms:GenerateDataKey",
#     ]
#     resources = [
#       "arn:aws:kms:${var.aws_region}:${data.aws_caller_identity.current.account_id}:alias/${local.name_prefix}-key",
#     ]
#   }
# }

# ################################################################################
# # Inline guard-rail: explicitly deny dangerous actions for Lambda
# # An explicit Deny overrides any Allow – provides a safety net even if a
# # broader policy is accidentally attached later.
# ################################################################################
# data "aws_iam_policy_document" "lambda_deny_guardrail" {
#   statement {
#     sid    = "DenyIAMEscalation"
#     effect = "Deny"
#     actions = [
#       "iam:CreateRole",
#       "iam:DeleteRole",
#       "iam:AttachRolePolicy",
#       "iam:PutRolePolicy",
#       "iam:PassRole",
#     ]
#     resources = ["*"]
#   }
# }

# ################################################################################
# # Module call – Lambda execution role
# ################################################################################
# module "lambda_execution_role" {
#   source = "./modules/iam"

#   role_name   = "${local.name_prefix}-lambda-execution-role"
#   description = "Execution role for all ${var.project_name} Lambda functions."
#   path = "/sales-automation/"                                                    # Group all platform roles under a common path for SCP targeting.
#   assume_role_policy = data.aws_iam_policy_document.lambda_trust.json            # Trust policy: only AWS Lambda service may assume this role.
#   max_session_duration = 3600                                                     # 1-hour session is sufficient for Lambda (max invocation is 15 min).

  
#   customer_managed_policies = {                                                   #  Customer-managed policies (created & attached by this module) 
#     s3_kms_access = {
#       name        = "${local.name_prefix}-lambda-s3-kms"
#       description = "Scoped S3 read/write and KMS access for Lambda functions."
#       path        = "/sales-automation/"
#       policy      = data.aws_iam_policy_document.lambda_s3_kms.json
#     }
#   }

  
#   aws_managed_policy_arns = [                                                     # AWS-managed policies (attached but not created by this module) 
#     "arn:aws:iam::aws:policy/service-role/AWSLambdaVPCAccessExecutionRole",       # AWSLambdaVPCAccessExecutionRole: grants CloudWatch Logs + ENI permissions
#   ]                                                                               # required when Lambda runs inside a VPC.

  
#   inline_policies = {
#     deny_iam_escalation = data.aws_iam_policy_document.lambda_deny_guardrail.json  # Inline guard-rail (role-specific; cannot be reused) 
#   }

#   tags = merge(local.common_tags, {
#     Component = "lambda"
#   })
# }

# ################################################################################
# # ROLE 2 – Glue ETL Job Role
# # Assumed by all Glue jobs that process and chunk pre-qualified data.
# ################################################################################

# ################################################################################
# # Trust policy: allow Glue service to assume this role
# ################################################################################
# data "aws_iam_policy_document" "glue_trust" {
#   statement {
#     sid     = "AllowGlueAssumeRole"
#     effect  = "Allow"
#     actions = ["sts:AssumeRole"]

#     principals {
#       type        = "Service"
#       identifiers = ["glue.amazonaws.com"]
#     }
#   }
# }

# ################################################################################
# # Permission document: S3 access + Glue Data Catalog for ETL jobs
# ################################################################################
# data "aws_iam_policy_document" "glue_s3_catalog" {                           # Glue jobs read raw data and write processed output.
  
#   statement {
#     sid    = "S3GlueReadWrite"
#     effect = "Allow"
#     actions = [
#       "s3:GetObject",
#       "s3:PutObject",
#       "s3:DeleteObject",
#       "s3:ListBucket",
#     ]
#     resources = [
#       "arn:aws:s3:::${local.name_prefix}-raw-data",
#       "arn:aws:s3:::${local.name_prefix}-raw-data/*",
#       "arn:aws:s3:::${local.name_prefix}-processed",
#       "arn:aws:s3:::${local.name_prefix}-processed/*",                 # Glue requires access to its own temp/staging bucket.      
#       "arn:aws:s3:::${local.name_prefix}-glue-temp",
#       "arn:aws:s3:::${local.name_prefix}-glue-temp/*",
#     ]
#   }

  
#   statement {                                                               # Glue needs to read/write its own Data Catalog (databases + tables).
#     sid    = "GlueCatalogAccess"
#     effect = "Allow"
#     actions = [
#       "glue:GetDatabase",
#       "glue:GetTable",
#       "glue:GetTables",
#       "glue:CreateTable",
#       "glue:UpdateTable",
#       "glue:BatchCreatePartition",
#       "glue:GetPartition",
#       "glue:GetPartitions",
#     ]
#     resources = [
#       "arn:aws:glue:${var.aws_region}:${data.aws_caller_identity.current.account_id}:catalog",
#       "arn:aws:glue:${var.aws_region}:${data.aws_caller_identity.current.account_id}:database/${local.name_prefix}*",
#       "arn:aws:glue:${var.aws_region}:${data.aws_caller_identity.current.account_id}:table/${local.name_prefix}*/*",
#     ]
#   }
# }

# ################################################################################
# # Module call – Glue ETL role
# ################################################################################
# module "glue_job_role" {
#   source = "./modules/iam"

#   role_name   = "${local.name_prefix}-glue-job-role"
#   description = "Execution role for ${var.project_name} Glue ETL jobs."

#   path = "/sales-automation/"
#   assume_role_policy = data.aws_iam_policy_document.glue_trust.json                # Trust policy: only AWS Glue service may assume this role. 
#   max_session_duration = 28800                                                     # Glue jobs can run for hours – 8-hour maximum session covers batch windows.
 
#   customer_managed_policies = {                                                    # Customer-managed policies (created & attached by this module)
#     s3_catalog_access = {
#       name        = "${local.name_prefix}-glue-s3-catalog"
#       description = "S3 read/write and Glue Data Catalog access for ETL jobs."
#       path        = "/sales-automation/"
#       policy      = data.aws_iam_policy_document.glue_s3_catalog.json
#     }
#   }

#   # ── Pre-existing customer-managed policy (created outside this module) ────
#   # Example: a shared KMS policy managed centrally by the platform team.
#   # Replace the ARN below with the real shared-policy ARN for your account.
#   customer_managed_policy_arns = [
#     "arn:aws:iam::${data.aws_caller_identity.current.account_id}:policy/shared-${var.environment}-kms-policy",
#   ]

#   #  AWS-managed policy 
#   # AWSGlueServiceRole provides CloudWatch Logs + EC2 networking permissions
#   # required by all Glue jobs.  Supplement with the scoped customer-managed
#   # policy above rather than granting broader access.
#   aws_managed_policy_arns = [
#     "arn:aws:iam::aws:policy/service-role/AWSGlueServiceRole",
#   ]

#   tags = merge(local.common_tags, {
#     Component = "glue"
#   })
# }

# ################################################################################
# # ROLE 3 – Step Functions Execution Role
# # Assumed by the sales-automation-data-pipeline state machine to invoke
# # Lambda functions and publish events.
# ################################################################################

# ################################################################################
# # Trust policy: allow Step Functions to assume this role
# ################################################################################
# data "aws_iam_policy_document" "sfn_trust" {
#   statement {
#     sid     = "AllowStepFunctionsAssumeRole"
#     effect  = "Allow"
#     actions = ["sts:AssumeRole"]

#     principals {
#       type        = "Service"
#       identifiers = ["states.amazonaws.com"]
#     }
    
#     condition {                                                                  # Condition: restrict assumption to state machines in THIS account only.
#       test     = "StringEquals"                                                  # Prevents cross-account state machines from using this role.
#       variable = "aws:SourceAccount"
#       values   = [data.aws_caller_identity.current.account_id]
#     }
#   }
# }

# ################################################################################
# # Permission document: allow Step Functions to invoke project Lambda functions
# ################################################################################

# data "aws_iam_policy_document" "sfn_invoke_lambda" {
#   statement {
#     sid    = "InvokeSalesAutomationLambdas"
#     effect = "Allow"
#     actions = [
#       "lambda:InvokeFunction",
#     ]                                                                                                                                                                                   
#     resources = [                                                                                                         # Scope to only the functions in this project using a name prefix wildcard.     
#       "arn:aws:lambda:${var.aws_region}:${data.aws_caller_identity.current.account_id}:function:${local.name_prefix}-*",
#     ]
#   }

                                                                                                                   
#   statement {                                                                                                                  # Step Functions needs to publish execution logs to CloudWatch.
#     sid    = "CloudWatchLogs"
#     effect = "Allow"
#     actions = [
#       "logs:CreateLogDelivery",
#       "logs:GetLogDelivery",
#       "logs:UpdateLogDelivery",
#       "logs:DeleteLogDelivery",
#       "logs:ListLogDeliveries",
#       "logs:PutLogEvents",
#       "logs:PutResourcePolicy",
#       "logs:DescribeResourcePolicies",
#       "logs:DescribeLogGroups",
#     ]
#     resources = ["*"]                                                                                                 # CloudWatch log delivery APIs require "*"
#   }

                                                                                                                      
                                                                                                                      
#   statement {                                                                                                          #Allow Step Functions to send task tokens / events via EventBridge.
#     sid    = "EventBridgePutEvents"
#     effect = "Allow"
#     actions = [
#       "events:PutTargets",
#       "events:PutRule",
#       "events:DescribeRule",
#     ]
#     resources = [
#       "arn:aws:events:${var.aws_region}:${data.aws_caller_identity.current.account_id}:rule/StepFunctionsGetEventsFor*",
#     ]
#   }
# }

# ################################################################################
# # Inline guard-rail: deny cross-account actions from Step Functions role
# ################################################################################
# data "aws_iam_policy_document" "sfn_deny_cross_account" {
#   statement {
#     sid    = "DenyCrossAccountLambdaInvoke"
#     effect = "Deny"
#     actions = [
#       "lambda:InvokeFunction",
#     ]
                                                                                            
#     resources = ["*"]                                                                     # Deny invocations targeting any account other than this one.

#     condition {
#       test     = "StringNotEquals"
#       variable = "aws:ResourceAccount"
#       values   = [data.aws_caller_identity.current.account_id]
#     }
#   }
# }

# ################################################################################
# # Module call – Step Functions execution role
# ################################################################################
# module "sfn_execution_role" {
#   source = "./modules/iam"

#   role_name   = "${local.name_prefix}-sfn-execution-role"
#   description = "Execution role for the ${var.project_name} Step Functions state machine."

#   path = "/sales-automation/"

#   assume_role_policy = data.aws_iam_policy_document.sfn_trust.json                                                                                                                   
#   max_session_duration = 7200                                                                                       # Step Functions executions for data pipelines may run up to 2 hours.                                                                                                                                                                                                                                                                                                     
#   permission_boundary_arn = "arn:aws:iam::${data.aws_caller_identity.current.account_id}:policy/${var.environment}-permission-boundary"  # Replace with the real permission-boundary policy ARN for your org. # Remove this argument if your organisation does not use boundaries.

                                                                                                                    
#   customer_managed_policies = {                                                                                             # Customer-managed policies (created & attached by this module)
#     invoke_lambda = {
#       name        = "${local.name_prefix}-sfn-invoke-lambda"
#       description = "Allows the data-pipeline state machine to invoke project Lambda functions."
#       path        = "/sales-automation/"
#       policy      = data.aws_iam_policy_document.sfn_invoke_lambda.json
#     }
#   }

                                                                                                                     
#   inline_policies = {
#     deny_cross_account = data.aws_iam_policy_document.sfn_deny_cross_account.json                                              # Inline guard-rail (embedded, role-specific, non-reusable)
#   }
                                                                                                                    
#   force_detach_policies = var.environment != "prod"  # In non-prod, allow Terraform to detach any attached policies when destroying the role.

#   tags = merge(local.common_tags, {
#     Component = "step-functions"
#   })
# }


