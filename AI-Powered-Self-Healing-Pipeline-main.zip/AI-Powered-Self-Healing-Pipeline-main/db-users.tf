################################################################################
# DATABASE USERS
#
# Creates application-specific PostgreSQL users in the Aurora cluster.
#
# Flow:
#   1. random_password — generates a strong password per user
#   2. secrets-manager — creates a secret per user with connection details
#   3. Lambda invocation — connects as admin and creates the PostgreSQL role
#
# When var.db_users is updated (new user added), Terraform will:
#   - Generate a new random password
#   - Create a new Secrets Manager secret
#   - Re-invoke the Lambda to create the new user in PostgreSQL
#
# Secret naming: <env>-<project>-aurora-postgres/<service-name>
# Example:       uat-sales-automation-aurora-postgres/vbr-service
################################################################################

################################################################################
# RANDOM PASSWORDS — one per user, same strength as RDS-managed admin password
################################################################################

resource "random_password" "db_user" {
  for_each = var.db_users

  length           = 32
  special          = true
  override_special = "!#$%&*()-_=+[]{}|:,.<>?"
}

################################################################################
# SECRETS — one per user, stores full connection details
################################################################################

module "db_user_secrets" {
  for_each = var.db_users
  source   = "./modules/secrets-manager"

  account_id = data.aws_caller_identity.current.account_id
  aws_region = var.aws_region

  name        = "${local.name_prefix}-aurora-postgres/${each.key}"
  description = "Database credentials for ${each.key} service — Aurora cluster ${local.name_prefix}-aurora-postgres"

  kms_key_id     = module.aurora_postgres.kms_key_arn
  create_kms_key = false

  secret_string = jsonencode({
    engine      = module.aurora_postgres.engine
    host        = module.aurora_postgres.cluster_endpoint
    writer_host = module.aurora_postgres.cluster_endpoint
    reader_host = module.aurora_postgres.cluster_reader_endpoint
    port        = tostring(module.aurora_postgres.cluster_port)
    database    = var.aurora_database_name
    username    = each.value.username
    password    = random_password.db_user[each.key].result
  })

  recovery_window_in_days = 30
  tags                    = merge(local.common_tags, { Service = each.key })
}

################################################################################
# LAMBDA INVOCATION — creates/updates PostgreSQL users
#
# Triggered whenever the user map changes (new user, password rotation, etc.)
# The Lambda connects as admin and executes CREATE ROLE / ALTER ROLE.
################################################################################

resource "aws_lambda_invocation" "create_db_users" {
  count = length(var.db_users) > 0 ? 1 : 0

  function_name = module.lambda_functions["sales-automation-db-user-manager"].function_name

  input = jsonencode({
    users = {
      for k, v in var.db_users : k => {
        username = v.username
        password = random_password.db_user[k].result
      }
    }
    _trigger = module.lambda_functions["sales-automation-db-user-manager"].source_code_hash
  })

  depends_on = [
    module.lambda_functions["sales-automation-db-user-manager"],
    module.db_user_secrets,
    module.aurora_postgres,
  ]
}
