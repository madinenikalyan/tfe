terraform {
  required_version = ">= 1.2.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
    # Required by the Lambda module: packages function code and dependency layers
    archive = {
      source  = "hashicorp/archive"
      version = ">= 2.4"
    }
    # Required for generating RSA keypair stored in Secrets Manager
    tls = {
      source  = "hashicorp/tls"
      version = ">= 4.0"
    }
  }

  backend "s3" {}
}

provider "aws" {
  region = var.aws_region

  default_tags {
    tags = {
      Environment = var.environment
      Project     = var.project_name
      ManagedBy   = "terraform"
    }
  }
}


data "aws_caller_identity" "current" {}