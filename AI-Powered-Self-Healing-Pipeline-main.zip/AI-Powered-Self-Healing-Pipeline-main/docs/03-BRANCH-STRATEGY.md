# Branch Strategy and Git Workflow

This document explains the branching model, how to create feature branches, and the complete workflow from feature development to production deployment.

---

## Branch Overview

| Branch | Purpose | Protected | Environment |
|--------|---------|-----------|-------------|
| `dev` | Primary branch for DEV environment | Yes | DEV (Account: 591098698873) |
| `develop` | Alias/mirror of `dev` | Yes | DEV (same account) |
| `uat` | Primary branch for UAT environment | Yes | UAT (Account: 104350167801) |
| `QA` | Alias/mirror of `uat` | Yes | UAT (same account) |
| `main` | Production branch (future use) | Yes | PROD (not yet configured) |
| `feature/*` | Feature development branches | No | No direct deployment |

Note: `dev` and `develop` are effectively the same branch - the pipeline triggers on both. Same for `uat` and `QA`.

---

## Feature Branch Workflow

### For DEV Environment Changes

**Step 1: Start from the latest `dev` branch**

```powershell
git checkout dev
git pull origin dev
```

**Step 2: Create a feature branch**

```powershell
git checkout -b feature/your-descriptive-name
```

Branch naming conventions:
- `feature/add-s3-bucket-for-reports` - new feature
- `fix/lambda-timeout-issue` - bug fix
- `refactor/glue-job-parameters` - code refactoring
- `docs/update-readme` - documentation updates
- `test/validate-pipeline` - testing changes

**Step 3: Make your changes**

Edit the relevant files in `env/dev/`, `modules/`, `code/lambda/`, or `code/glue/`.

**Step 4: Verify locally (optional but recommended)**

```powershell
cd env/dev
terraform plan
```

Review the plan output to ensure it shows only your intended changes.

**Step 5: Commit your changes**

```powershell
git add .
git commit -m "feat: short description of your change"
```

Commit message prefixes:
- `feat:` - new feature
- `fix:` - bug fix
- `refactor:` - code refactoring
- `docs:` - documentation changes
- `test:` - test-related changes
- `chore:` - maintenance tasks

**Step 6: Push to GitHub**

```powershell
git push origin feature/your-descriptive-name
```

**Step 7: Create a Pull Request**

- Go to https://github.com/TegnaDataTeam/sales-automation
- Click "Compare & pull request"
- Ensure base branch is `dev`
- Add a clear description of what you changed and why
- Click "Create pull request"

**Step 8: Wait for the pipeline**

The pipeline will automatically run and post a comment on your PR with the Terraform plan output.

**Step 9: Review and get approval**

- Review the plan comment carefully
- Request review from a team member
- Address any feedback or concerns
- Get the PR approved

**Step 10: Approve deployment**

After PR approval, the "Deploy Approval" gate will appear. A designated approver must approve the deployment.

**Step 11: Merge**

Once deployment is approved, merge the PR. The pipeline will automatically run `terraform apply` and deploy your changes to DEV.

**Step 12: Verify deployment**

Check the pipeline logs and AWS console to confirm your changes were applied successfully.

**Step 13: Clean up**

```powershell
git checkout dev
git pull origin dev
git branch -d feature/your-descriptive-name
```

---

### For UAT Environment Changes

The process is identical to DEV, but:

1. Start from `uat` branch: `git checkout uat`
2. Create feature branch from `uat`: `git checkout -b feature/your-name-uat`
3. Make changes in `env/uat/` instead of `env/dev/`
4. Remember to set `$env:AWS_PROFILE = "uat"` before running any local terraform commands
5. Create PR targeting `uat` branch (not `dev`)
6. After merge, changes deploy to the UAT environment

---

## Important Rules

### DO

- Always create a feature branch from the environment branch you are targeting
- Pull latest before creating a feature branch
- Use descriptive branch names
- Write clear commit messages
- Run `terraform plan` locally before pushing
- Review the pipeline's plan output in the PR comment
- Get code review before merging
- Delete your feature branch after merging

### DO NOT

- Never commit directly to `dev`, `uat`, `develop`, or `QA` branches
- Never force push to shared branches
- Never create a feature branch from `dev` and target the PR to `uat` (or vice versa)
- Never merge without code review
- Never merge without reviewing the terraform plan output
- Never push without testing locally first
- Never rewrite git history on shared branches

---

## Multi-Environment Workflow

If you need to deploy the same change to both DEV and UAT:

**Option 1: Sequential (Recommended)**

1. Create feature branch from `dev`, make changes, get PR merged to DEV
2. After DEV deployment is verified, create a new feature branch from `uat`
3. Apply the same changes to UAT's config files
4. Get PR merged to UAT

**Option 2: Parallel (Advanced)**

1. Create `feature/change-dev` from `dev` and `feature/change-uat` from `uat` simultaneously
2. Make equivalent changes in each branch
3. Get both PRs reviewed
4. Merge DEV first, verify, then merge UAT

---

## What Triggers the Pipeline

The pipeline triggers on **Pull Requests** and **Pushes** to the base branches, but only if files in these paths change:

| Path | What's in it |
|------|-------------|
| `env/dev/**` | DEV environment Terraform config |
| `env/uat/**` | UAT environment Terraform config |
| `modules/**` | Shared Terraform modules |
| `code/lambda/**` | Lambda function source code |
| `code/glue/**` | Glue job scripts |
| `.github/workflows/**` | Pipeline definitions |

Changes to these paths do NOT trigger the pipeline:
- `README.md` or any `.md` files
- `docs/**`
- `scripts/**`
- `.gitignore`
- `database/**`

---

## Rollback Process

If a deployment causes issues:

**Method 1: Revert the merge commit**

```powershell
# Find the merge commit hash from GitHub
git checkout dev
git pull origin dev
git revert <merge-commit-hash> -m 1
git push origin dev
```

This creates a new commit that undoes the changes. The pipeline will automatically deploy the rollback.

**Method 2: Create a hotfix**

```powershell
git checkout dev
git checkout -b fix/rollback-broken-change
# Make corrective changes
git commit -m "fix: rollback broken change"
git push origin fix/rollback-broken-change
# Create PR, fast-track review, merge
```

---

## Branch Synchronization

The `dev`/`develop` and `uat`/`QA` branch pairs should stay in sync. Do not manually merge between them. If they get out of sync, contact the infrastructure team.

---

## Example Workflow Walkthrough

**Scenario:** Add a new S3 bucket to DEV for storing customer analytics data.

```powershell
# 1. Start fresh
git checkout dev
git pull origin dev

# 2. Create feature branch
git checkout -b feature/add-customer-analytics-bucket

# 3. Edit terraform.tfvars
# Add to the s3_buckets map:
#   customer_analytics = {
#     bucket_name        = "sales-automation-customer-analytics"
#     versioning_enabled = true
#   }

# 4. Verify locally
cd env/dev
terraform plan
# Review output - should show 1 S3 bucket to add

# 5. Commit
git add env/dev/terraform.tfvars
git commit -m "feat: add S3 bucket for customer analytics data"

# 6. Push
git push origin feature/add-customer-analytics-bucket

# 7. Create PR on GitHub
# Base: dev
# Compare: feature/add-customer-analytics-bucket
# Title: "Add S3 bucket for customer analytics"
# Description: "Creates a new S3 bucket with versioning enabled to store customer analytics data."

# 8. Wait for pipeline to post plan comment

# 9. Request review from teammate

# 10. After approval, merge PR

# 11. Pipeline automatically deploys to DEV

# 12. Verify in AWS console that bucket exists

# 13. Clean up
git checkout dev
git pull origin dev
git branch -d feature/add-customer-analytics-bucket
```

Done.
