# Best Practices and Guidelines

This document outlines best practices, coding standards, and guidelines for working with the TEGNA Sales Automation infrastructure.

---

## Git and Version Control

### Commit Messages

Use descriptive, concise commit messages following this format:

```
<type>: <short description>

<optional detailed description>
```

**Types:**
- `feat:` - New feature
- `fix:` - Bug fix
- `refactor:` - Code refactoring without behavior change
- `docs:` - Documentation updates
- `test:` - Test-related changes
- `chore:` - Maintenance tasks (dependency updates, etc.)

**Examples:**

Good:
```
feat: add S3 bucket for customer analytics data

Creates a new versioned S3 bucket to store customer analytics reports.
Bucket lifecycle policy set to 90 days retention.
```

Bad:
```
updated files
```

```
fix stuff
```

### Branch Naming

Use descriptive branch names with a prefix:

**Format:** `<type>/<short-description>`

**Examples:**
- `feature/add-customer-analytics-bucket`
- `fix/lambda-timeout-issue`
- `refactor/glue-job-parameters`
- `docs/update-troubleshooting-guide`

**Avoid:**
- `my-branch`
- `temp`
- `test123`

### Pull Requests

**Title:** Clear and descriptive
- Good: "Add S3 bucket for customer analytics data"
- Bad: "Update terraform.tfvars"

**Description:** Include:
- What you changed
- Why you changed it
- Any potential impact
- Testing done (if applicable)

**Example:**
```
## What

Adds a new S3 bucket `sales-automation-customer-analytics` to store customer analytics reports.

## Why

The reporting team needs a dedicated bucket with versioning enabled to store historical analytics data.

## Impact

- Creates 1 new S3 bucket in DEV
- No impact on existing resources
- Estimated cost: ~$5/month for 100GB storage

## Testing

- Ran `terraform plan` locally - confirmed only 1 S3 bucket to add
- No other resources affected
```

### Code Review

**As the author:**
- Respond to all comments
- Explain your reasoning if you disagree with feedback
- Make requested changes or discuss alternatives
- Do not merge without approval

**As the reviewer:**
- Review the code changes AND the Terraform plan output
- Check for security issues (overly permissive IAM policies, public S3 buckets, etc.)
- Verify naming conventions are followed
- Ensure changes are well-documented
- Approve only if you fully understand the changes

---

## Terraform

### Naming Conventions

**Resources:**
- Use lowercase with hyphens: `sales-automation-customer-analytics`
- Always prefix with `sales-automation-`
- Be descriptive but concise

**Variables:**
- Use snake_case: `enable_vbr_api`, `lambda_timeout`
- Boolean variables should start with `enable_`, `is_`, or `has_`

### Formatting

Always run `terraform fmt` before committing:

```powershell
cd env/dev
terraform fmt -recursive
```

This ensures consistent formatting across all `.tf` files.

### State Management

**DO:**
- Always work with the remote state in S3
- Use `terraform plan` before `terraform apply`
- Let the pipeline run `terraform apply` in most cases

**DO NOT:**
- Never manually edit the state file
- Never run `terraform apply` locally without good reason
- Never commit `.terraform/` directories or state files
- Never use `terraform destroy` in production

### Resource Tagging

All resources should have appropriate tags. The tagging is typically handled by modules, but if you are adding custom tags:

```hcl
tags = {
  Environment = "dev"           # or "uat", "prod"
  Project     = "sales-automation"
  ManagedBy   = "terraform"
  Owner       = "data-team"
}
```

---

## Lambda Functions

### Code Structure

```
code/lambda/function-name/
├── lambda_function.py       # Main handler
├── requirements.txt         # Dependencies
└── utils.py                 # Optional: utility functions
```

### Best Practices

**Handler function:**
```python
def lambda_handler(event, context):
    """
    Main Lambda handler.
    
    Args:
        event: Lambda event object
        context: Lambda context object
        
    Returns:
        dict: Response with statusCode and body
    """
    try:
        # Your logic here
        
        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Success'})
        }
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
```

**Logging:**
- Use `print()` for logs (automatically sent to CloudWatch)
- Include context in log messages
- Log at appropriate levels (INFO, WARNING, ERROR)

**Error handling:**
- Always use try/except blocks
- Return proper HTTP status codes
- Log errors with stack traces

**Dependencies:**
- Pin versions in `requirements.txt`: `requests==2.31.0`, not `requests`
- Only include necessary packages
- Keep packages lightweight (Lambda has size limits)

### Configuration

**In terraform.tfvars:**
```hcl
lambda_functions = {
  my_function = {
    function_name = "sales-automation-my-function"
    handler       = "lambda_function.lambda_handler"
    runtime       = "python3.12"
    timeout       = 300       # 5 minutes max for most functions
    memory_size   = 256       # Start with 256MB, increase if needed
    environment_variables = {
      LOG_LEVEL = "INFO"      # Use environment-specific values
    }
  }
}
```

**Timeout:**
- Default: 300 seconds (5 minutes)
- Maximum: 900 seconds (15 minutes)
- Set based on actual execution time + buffer

**Memory:**
- Minimum: 128 MB
- Maximum: 10240 MB
- More memory = more CPU power and cost
- Test to find the optimal value

---

## Glue Jobs

### Script Best Practices

**Imports:**
```python
import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
```

**Job initialization:**
```python
args = getResolvedOptions(sys.argv, ['JOB_NAME'])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)
```

**Job completion:**
```python
job.commit()
```

**Error handling:**
- Wrap main logic in try/except
- Log errors with context
- Re-raise exceptions for Glue to catch

### Configuration

```hcl
glue_jobs = {
  my_job = {
    name              = "sales-automation-my-job"
    script_location   = "s3://sales-automation-aws-glue-assets/scripts/my-job.py"
    max_retries       = 1           # Usually 0-2 retries
    timeout           = 2880        # 48 hours max
    glue_version      = "4.0"
    worker_type       = "G.1X"      # Or "G.2X" for larger jobs
    number_of_workers = 10          # Scale based on data volume
  }
}
```

**Worker types:**
- `G.1X`: 4 vCPU, 16 GB memory, 64 GB disk
- `G.2X`: 8 vCPU, 32 GB memory, 128 GB disk

Choose based on data size and processing requirements.

---

## Security

### IAM Permissions

**Principle of least privilege:**
- Grant only the minimum permissions needed
- Use specific resource ARNs, not `*`
- Regularly review and prune unused policies

**Example of good IAM policy:**
```json
{
  "Version": "2012-10-17",
  "Statement": [{
    "Effect": "Allow",
    "Action": [
      "s3:GetObject",
      "s3:PutObject"
    ],
    "Resource": "arn:aws:s3:::sales-automation-specific-bucket/*"
  }]
}
```

**Example of bad IAM policy:**
```json
{
  "Version": "2012-10-17",
  "Statement": [{
    "Effect": "Allow",
    "Action": "s3:*",
    "Resource": "*"
  }]
}
```

### Secrets Management

**DO:**
- Store secrets in AWS Secrets Manager
- Reference secrets in Lambda/Glue via ARN
- Rotate secrets regularly

**DO NOT:**
- Never hardcode secrets in code
- Never commit secrets to git
- Never store secrets in environment variables if avoidable

### S3 Buckets

**Best practices:**
- Enable versioning for important data
- Use bucket policies to restrict access
- Enable server-side encryption
- Block public access unless explicitly required

---

## Testing

### Local Testing

**Terraform:**
```powershell
cd env/dev
terraform validate      # Check syntax
terraform fmt -check    # Check formatting
terraform plan          # Preview changes
```

**Lambda (basic test):**
```powershell
python code/lambda/my-function/lambda_function.py
```

For full testing, consider using AWS SAM or LocalStack.

### In DEV Environment

- Always deploy to DEV first
- Test functionality in AWS console
- Monitor CloudWatch Logs for errors
- Verify data outputs
- Only deploy to UAT after DEV is confirmed working

---

## Documentation

### Code Comments

**Good comments explain WHY, not WHAT:**

Good:
```python
# Use exponential backoff to avoid API rate limiting
for attempt in range(max_retries):
    ...
```

Bad:
```python
# Loop through attempts
for attempt in range(max_retries):
    ...
```

### Terraform Comments

Use comments to explain complex logic or non-obvious decisions:

```hcl
# Disable versioning for temp data bucket to reduce costs
versioning_enabled = false
```

### README and Documentation

- Keep documentation up to date with code changes
- Update docs in the same PR as code changes
- Use clear, concise language
- Include examples where helpful

---

## Deployment

### Deployment Windows

While there are no strict deployment windows currently, follow these guidelines:

**Avoid deploying:**
- During business-critical hours (8 AM - 6 PM ET on weekdays) unless necessary
- Late Friday afternoons (in case of issues over the weekend)

**Preferred times:**
- Early morning (6-8 AM ET)
- During lunch hours (12-1 PM ET)
- After business hours (6-8 PM ET)

**Emergency deployments:**
- Can be done anytime with proper approvals
- Notify the team in advance if possible

### Deployment Size

**Small deployments (preferred):**
- 1-3 resources changed
- Single feature or bug fix
- Lower risk

**Large deployments:**
- 10+ resources changed
- Multiple features
- Higher risk
- Require extra scrutiny and testing

Break large changes into smaller, incremental deployments when possible.

---

## Monitoring

### After Deployment

Within 1 hour:
- Check CloudWatch Logs for errors
- Verify resources in AWS console
- Test the deployed feature (if applicable)

Within 24 hours:
- Monitor CloudWatch metrics
- Check for any unexpected behavior
- Review cost impact (if significant changes)

### CloudWatch Alarms

Set up alarms for:
- Lambda errors
- Lambda throttling
- Glue job failures
- High API Gateway latency

Contact the infrastructure team if you need help setting up alarms.

---

## Cost Optimization

### Lambda

- Right-size memory allocation
- Optimize code for faster execution
- Avoid unnecessary cold starts

### Glue

- Use appropriate worker type and count
- Optimize data partitioning
- Enable job bookmarks to avoid reprocessing data

### S3

- Use lifecycle policies to expire old data
- Enable intelligent tiering for infrequent access data
- Avoid storing unnecessary data

---

## Getting Help

**Before asking for help:**
1. Check `docs/06-TROUBLESHOOTING.md`
2. Search GitHub Issues for similar problems
3. Read the error message carefully and try to understand it

**When asking for help, provide:**
- What you were trying to do
- What you expected to happen
- What actually happened
- The exact error message
- Steps to reproduce
- What you have already tried

**Who to ask:**
- Team chat for quick questions
- GitHub Issues for bugs or feature requests
- Infrastructure owner (Manish Kumar) for urgent issues

---

## Continuous Improvement

- Share knowledge with the team
- Document solutions to problems you solve
- Suggest improvements to processes and tools
- Review and update documentation regularly
