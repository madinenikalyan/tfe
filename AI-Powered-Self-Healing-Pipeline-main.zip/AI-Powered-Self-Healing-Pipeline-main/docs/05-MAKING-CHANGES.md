# Making Changes

This document provides step-by-step instructions for common changes you will make to the infrastructure and application code.

---

## Adding an S3 Bucket

**File to edit:** `env/dev/terraform.tfvars` (or `env/uat/terraform.tfvars` for UAT)

**Location in file:** Find the `s3_buckets` map (around line 2430 for DEV, 2254 for UAT)

**Steps:**

1. Open `env/dev/terraform.tfvars`
2. Scroll to the `s3_buckets` section
3. Add your bucket entry before the closing `}`

```hcl
s3_buckets = {
  # ... existing buckets ...
  
  your_new_bucket = {
    bucket_name        = "sales-automation-your-bucket-name"
    versioning_enabled = true  # or false
  }
}
```

4. If the bucket needs a custom policy, add it:

```hcl
  your_new_bucket = {
    bucket_name        = "sales-automation-your-bucket-name"
    versioning_enabled = true
    policy             = "{\"Version\":\"2012-10-17\",\"Statement\":[...]}"
  }
```

5. Save the file
6. Run `terraform plan` locally to verify
7. Commit, push, and create a PR

**Naming convention:** All S3 buckets should start with `sales-automation-` and use lowercase with hyphens.

---

## Modifying a Lambda Function

### Updating Lambda Code

**Location:** `code/lambda/<function-name>/`

**Steps:**

1. Navigate to the Lambda function folder, e.g., `code/lambda/sales-automation-leads-service/`
2. Edit the Python files (usually `lambda_function.py` or similar)
3. Make your changes
4. Test locally if possible:
   ```powershell
   python code/lambda/sales-automation-leads-service/lambda_function.py
   ```
5. Commit, push, and create a PR
6. The pipeline will automatically detect the change via `source_code_hash` and update the Lambda function in AWS

### Adding Python Dependencies

**File to edit:** `code/lambda/<function-name>/requirements.txt`

**Steps:**

1. Open the `requirements.txt` file in the Lambda function folder
2. Add the package and version:
   ```
   requests==2.31.0
   boto3==1.34.0
   ```
3. Save the file
4. The pipeline will automatically install these dependencies when building the Lambda package
5. Commit, push, and create a PR

### Changing Lambda Configuration (timeout, memory, environment variables)

**File to edit:** `env/dev/terraform.tfvars` (or `env/uat/terraform.tfvars`)

**Location in file:** Find the `lambda_functions` map

**Steps:**

1. Open `env/dev/terraform.tfvars`
2. Find your Lambda function in the `lambda_functions` map
3. Modify the configuration:

```hcl
lambda_functions = {
  leads_service = {
    function_name = "sales-automation-leads-service"
    handler       = "lambda_function.lambda_handler"
    runtime       = "python3.12"
    timeout       = 900           # Change timeout (seconds)
    memory_size   = 512           # Change memory (MB)
    environment_variables = {
      LOG_LEVEL = "DEBUG"         # Add or modify env vars
      API_URL   = "https://api.example.com"
    }
  }
}
```

4. Save the file
5. Run `terraform plan` to verify the changes
6. Commit, push, and create a PR

---

## Updating a Glue Job Script

**Location:** `code/glue/`

**Steps:**

1. Navigate to `code/glue/`
2. Find your Glue job script (e.g., `sales-automation-insert-matrix-aurora-db-glue.py`)
3. Edit the Python script
4. Save the file
5. Commit, push, and create a PR
6. The pipeline will automatically upload the updated script to S3, and Terraform will detect the change

**Note:** Glue job scripts are stored as flat `.py` files in the `code/glue/` directory, not in subfolders.

### Changing Glue Job Configuration

**File to edit:** `env/dev/terraform.tfvars`

**Location in file:** Find the `glue_jobs` map

**Steps:**

1. Open `env/dev/terraform.tfvars`
2. Find your Glue job in the `glue_jobs` map
3. Modify the configuration:

```hcl
glue_jobs = {
  matrix_insert = {
    name              = "sales-automation-insert-matrix-aurora-db-glue"
    script_location   = "s3://sales-automation-aws-glue-assets/scripts/sales-automation-insert-matrix-aurora-db-glue.py"
    max_retries       = 2                # Change retry count
    timeout           = 2880             # Change timeout (minutes)
    glue_version      = "4.0"
    worker_type       = "G.1X"
    number_of_workers = 10               # Change worker count
    default_arguments = {
      "--job-language" = "python"
      "--TempDir"      = "s3://sales-automation-aws-glue-assets/temporary/"
    }
  }
}
```

4. Save the file
5. Run `terraform plan` to verify
6. Commit, push, and create a PR

---

## Creating a New Lambda Function

**Steps:**

1. Create a new folder in `code/lambda/`:
   ```powershell
   mkdir code/lambda/my-new-function
   ```

2. Create `lambda_function.py`:
   ```python
   def lambda_handler(event, context):
       return {
           'statusCode': 200,
           'body': 'Hello from my new Lambda'
       }
   ```

3. Create `requirements.txt` (even if empty):
   ```
   # Add dependencies here
   ```

4. Add the Lambda configuration to `env/dev/terraform.tfvars`:
   ```hcl
   lambda_functions = {
     # ... existing functions ...
     
     my_new_function = {
       function_name = "sales-automation-my-new-function"
       handler       = "lambda_function.lambda_handler"
       runtime       = "python3.12"
       timeout       = 300
       memory_size   = 256
       environment_variables = {}
     }
   }
   ```

5. Run `terraform plan` to verify
6. Commit, push, and create a PR

---

## Modifying Infrastructure Modules

**Location:** `modules/<module-name>/`

**Important:** Changes to modules affect BOTH DEV and UAT environments.

**Steps:**

1. Navigate to the module folder, e.g., `modules/lambda/`
2. Edit the module files (`main.tf`, `variables.tf`, `outputs.tf`)
3. Test the change in DEV first:
   - Create a feature branch from `dev`
   - Make the module change
   - Deploy to DEV via PR
   - Verify in AWS
4. Once confirmed working in DEV, deploy to UAT:
   - Create a separate feature branch from `uat`
   - The module change will already be there (modules are shared)
   - But UAT's `terraform.tfvars` may need updating if new variables were added
   - Deploy to UAT via PR

**Example:** Adding a new variable to the Lambda module

1. Edit `modules/lambda/variables.tf`:
   ```hcl
   variable "enable_x_ray" {
     description = "Enable X-Ray tracing"
     type        = bool
     default     = false
   }
   ```

2. Edit `modules/lambda/main.tf` to use the variable:
   ```hcl
   resource "aws_lambda_function" "function" {
     # ... existing config ...
     
     tracing_config {
       mode = var.enable_x_ray ? "Active" : "PassThrough"
     }
   }
   ```

3. Update `env/dev/main.tf` where the module is called:
   ```hcl
   module "lambda" {
     # ... existing config ...
     enable_x_ray = true
   }
   ```

4. Test in DEV, then repeat for UAT

---

## Adding IAM Users or Roles

**File to edit:** `env/dev/terraform.tfvars`

**Location in file:** Find `iam_users` or `iam_roles`

**Adding a user:**

```hcl
iam_users = {
  # ... existing users ...
  
  new_service_user = {
    name = "sales-automation-service-user"
    path = "/"
    tags = {
      Purpose = "Service account for data sync"
    }
  }
}
```

**Adding a role:**

```hcl
iam_roles = {
  # ... existing roles ...
  
  new_service_role = {
    name               = "sales-automation-service-role"
    assume_role_policy = jsonencode({
      Version = "2012-10-17"
      Statement = [{
        Action = "sts:AssumeRole"
        Effect = "Allow"
        Principal = {
          Service = "lambda.amazonaws.com"
        }
      }]
    })
  }
}
```

**Important:** Be very careful with IAM changes. Review the Terraform plan carefully to ensure you are not accidentally granting excessive permissions.

---

## Enabling or Disabling a Module

Some modules have toggle variables in `env/dev/terraform.tfvars`.

**Example:** Enabling the VBR API

Find the toggle variable:

```hcl
enable_vbr_api = true  # Change to false to disable
```

When you set it to `false`, Terraform will destroy all resources associated with that module. Review the plan carefully.

---

## Changing VPC or Network Configuration

**File to edit:** `env/dev/terraform.tfvars`

**Location in file:** VPC and subnet sections

**Example:** Changing VPC CIDR

```hcl
vpc_cidr = "172.21.128.0/24"  # Change to your desired CIDR
```

**Warning:** Changing network configuration can be disruptive and may require resource recreation. Always test in DEV first and plan for downtime in UAT/PROD.

---

## Best Practices

1. **Always test in DEV first** before deploying to UAT
2. **Make small, incremental changes** rather than large batch changes
3. **Run `terraform plan` locally** before creating a PR
4. **Read the Terraform plan output** in the PR comment carefully
5. **Document why you are making the change** in the PR description
6. **Coordinate with the team** if changing shared modules
7. **Back up data** before making destructive changes (e.g., deleting S3 buckets)

---

## Quick Reference

| Task | File to Edit | Section |
|------|-------------|---------|
| Add S3 bucket | `terraform.tfvars` | `s3_buckets` |
| Modify Lambda code | `code/lambda/<name>/*.py` | N/A |
| Add Lambda dependency | `code/lambda/<name>/requirements.txt` | N/A |
| Change Lambda config | `terraform.tfvars` | `lambda_functions` |
| Modify Glue script | `code/glue/<name>.py` | N/A |
| Change Glue config | `terraform.tfvars` | `glue_jobs` |
| Add IAM user | `terraform.tfvars` | `iam_users` |
| Add IAM role | `terraform.tfvars` | `iam_roles` |
| Enable/disable module | `terraform.tfvars` | Look for `enable_*` variables |
| Change VPC config | `terraform.tfvars` | `vpc_*` variables |
