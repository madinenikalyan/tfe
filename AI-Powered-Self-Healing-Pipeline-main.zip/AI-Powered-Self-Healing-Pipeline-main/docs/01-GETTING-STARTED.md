# Getting Started

This guide covers everything a new developer needs to set up their local environment and start working with the TEGNA Sales Automation infrastructure.

---

## Prerequisites

### Software

| Tool | Version | Download |
|------|---------|----------|
| Git | Latest | https://git-scm.com/downloads |
| Terraform | v1.9.8 or later | https://developer.hashicorp.com/terraform/downloads |
| AWS CLI | v2 | https://aws.amazon.com/cli/ |
| Python | 3.12+ | https://www.python.org/downloads/ |
| VS Code | Latest (recommended) | https://code.visualstudio.com/ |

### VS Code Extensions (Recommended)

- HashiCorp Terraform
- Python
- GitLens

### AWS Credentials

You need access to two AWS accounts. Request credentials from your team lead or DevOps team.

| Profile Name | AWS Account | Account ID | Purpose |
|-------------|-------------|------------|---------|
| `default` | DEV | 591098698873 | Development environment |
| `uat` | UAT | 104350167801 | User Acceptance Testing environment |

Configure them in your AWS credentials file:

**Windows:** `C:\Users\<your-username>\.aws\credentials`
**Mac/Linux:** `~/.aws/credentials`

```ini
[default]
aws_access_key_id = <your-dev-access-key>
aws_secret_access_key = <your-dev-secret-key>

[uat]
aws_access_key_id = <your-uat-access-key>
aws_secret_access_key = <your-uat-secret-key>
```

Also configure the region in `~/.aws/config`:

```ini
[default]
region = us-east-1

[profile uat]
region = us-east-1
```

### GitHub Access

- You need read/write access to https://github.com/TegnaDataTeam/sales-automation
- You must be able to create branches and pull requests
- Request access from the repository admin if needed

---

## Day One Setup

### Step 1: Clone the Repository

```powershell
git clone https://github.com/TegnaDataTeam/sales-automation.git
cd sales-automation
```

### Step 2: Verify AWS Credentials

```powershell
# Verify DEV access
aws sts get-caller-identity

# Verify UAT access
aws sts get-caller-identity --profile uat
```

Both commands should return your account ID and user ARN without errors.

### Step 3: Initialize Terraform for DEV

```powershell
cd env/dev
terraform init
```

You should see "Terraform has been successfully initialized!" at the end.

### Step 4: Verify DEV is Working

```powershell
terraform plan
```

This should show "No changes. Your infrastructure matches the configuration." which means you are connected to the correct state and everything is in sync.

### Step 5: Initialize Terraform for UAT

Open a new terminal or navigate back to the repo root first:

```powershell
cd ..\..\env\uat
$env:AWS_PROFILE = "uat"
terraform init
```

### Step 6: Verify UAT is Working

```powershell
$env:AWS_PROFILE = "uat"
terraform plan
```

This should also show "No changes."

---

## Important Notes

- The DEV environment uses the `default` AWS profile automatically. No extra setup needed.
- The UAT environment requires you to set `$env:AWS_PROFILE = "uat"` in your terminal session before running any terraform or AWS CLI commands. This is because your shell defaults to the `default` (DEV) profile.
- Switching git branches does NOT switch your AWS profile. You must set the profile manually.
- Never run `terraform apply` locally unless instructed to do so. All deployments go through the CI/CD pipeline.

---

## Verification Checklist

Before starting any work, confirm the following:

- [ ] Git clone successful
- [ ] AWS CLI returns correct identity for both accounts
- [ ] `terraform init` succeeds for both env/dev and env/uat
- [ ] `terraform plan` shows "No changes" for both environments
- [ ] You can create branches and push to GitHub

If any step fails, refer to `docs/06-TROUBLESHOOTING.md` or contact the infrastructure team.

---

## Next Steps

Once your environment is set up, read:

1. `docs/02-REPOSITORY-STRUCTURE.md` to understand the codebase layout
2. `docs/03-BRANCH-STRATEGY.md` to understand how to create branches and PRs
3. `docs/04-CICD-PIPELINE.md` to understand the deployment pipeline
