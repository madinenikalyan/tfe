# Repository Structure

This document explains the folder layout of the TEGNA Sales Automation repository and the purpose of each directory and key file.

---

## Top-Level Structure

```
sales-automation/
|
|-- .github/workflows/          CI/CD pipeline definitions
|-- code/                       Application code (Lambda, Glue)
|-- docs/                       Documentation
|-- env/                        Environment-specific Terraform configs
|-- modules/                    Reusable Terraform modules
|-- scripts/                    Utility and deployment scripts
|-- .gitignore                  Git ignore rules
|-- README.md                   Project overview
```

---

## .github/workflows/

Contains the GitHub Actions CI/CD pipeline definitions.

| File | Purpose |
|------|---------|
| `develop-pipeline.yml` | Pipeline for DEV environment. Triggers on PRs and pushes to `dev` / `develop` branches. |
| `uat-pipeline.yml` | Pipeline for UAT environment. Triggers on PRs and pushes to `uat` / `QA` branches. |

These files should not be modified unless you are changing the pipeline behavior itself.

---

## env/

Contains environment-specific Terraform configurations. Each environment has its own subdirectory.

### env/dev/ (DEV Environment)

| File | Purpose | When to Edit |
|------|---------|-------------|
| `main.tf` | Calls all Terraform modules. Defines which resources are created. | When adding a new module or toggling a resource on/off. |
| `variables.tf` | Declares all input variables and their types. | When adding a new variable that `main.tf` or modules need. |
| `terraform.tfvars` | Provides actual values for all variables. This is where most configuration changes happen. | Most of your changes will be here - adding S3 buckets, Lambda configs, Glue jobs, etc. |
| `provider.tf` | Configures the AWS provider (region, account ID safety check). | Rarely. Do not add a `profile` here. |
| `backend.tf` | Configures S3 backend for Terraform state. Has `profile = "default"` for local use. | Rarely. |
| `backend.s3.hcl` | Backend override for CI/CD. Has `profile = ""` to blank out the profile when running in GitHub Actions. | Never, unless changing the state bucket. |

### env/uat/ (UAT Environment)

Same structure as `env/dev/` but with UAT-specific values. The `backend.tf` has `profile = "uat"` for local use.

### How env/ Files Work Together

```
terraform.tfvars      -->  Provides values
        |
        v
variables.tf          -->  Declares variable types and defaults
        |
        v
main.tf               -->  Passes variables to modules
        |
        v
modules/*             -->  Creates AWS resources
```

---

## modules/

Contains reusable Terraform modules. Each module manages one type of AWS resource. These modules are shared across both DEV and UAT environments.

| Module | Purpose |
|--------|---------|
| `alb/` | Application Load Balancer |
| `api_get_matrix_indo/` | API Gateway for Matrix data |
| `api_sales_automation_leads/` | API Gateway for Leads |
| `api-glue-job-launcher/` | API Gateway for Glue job launching |
| `api-seamless-webhook/` | API Gateway for SeamlessAI webhook |
| `api-vbr/` | API Gateway for VBR |
| `aurora/` | Aurora PostgreSQL database cluster |
| `Cloudwatch/` | CloudWatch log groups and alarms |
| `eni/` | Elastic Network Interfaces |
| `glue/` | AWS Glue jobs and crawlers |
| `iam/` | IAM users, roles, and policies |
| `internet-gateway/` | Internet Gateway |
| `kms/` | KMS encryption keys |
| `lambda/` | Lambda functions |
| `nacl/` | Network ACLs |
| `nat/` | NAT Gateway |
| `private-link/` | VPC Private Link |
| `route-tables/` | Route Tables |
| `s3/` | S3 buckets |
| `secretmanager/` | AWS Secrets Manager |
| `security-groups/` | Security Groups |
| `sns/` | SNS topics |
| `sqs/` | SQS queues |
| `stepfunctions/` | Step Functions state machines |
| `subnets/` | VPC Subnets |
| `vpc/` | VPC |
| `vpc-endpoint/` | VPC Endpoints |

**Important:** Changes to any module affect BOTH DEV and UAT environments. If you modify a module, test it in DEV first, then deploy to UAT separately.

---

## code/

Contains application source code that gets deployed to AWS.

### code/lambda/

Lambda function source code. Each Lambda function has its own subdirectory containing the Python source files.

### code/glue/

AWS Glue job scripts. These are Python scripts that run as Glue ETL jobs. They are stored as flat `.py` files in this directory.

---

## scripts/

Utility scripts for local development and operations.

| Script | Purpose |
|--------|---------|
| `build-lambdas.sh` | Builds Lambda deployment packages. Used by the CI/CD pipeline. |
| `build-lambda.ps1` | PowerShell version for local Lambda builds. |
| `build-db-migration-lambda.ps1` | Builds the database migration Lambda package. |
| `deploy-lambda.ps1` | Deploys a Lambda function directly to AWS (manual/emergency use). |
| `deploy-glue.ps1` | Deploys a Glue job script directly to AWS (manual/emergency use). |
| `download-code-from-aws.ps1` | Downloads existing Lambda/Glue code from AWS to local. |
| `setup-terraform-backend.ps1` | One-time script to create the S3 backend bucket. |
| `sync-dev-to-uat.ps1` | Syncs code from DEV to UAT. |
| `verify-unified-files.ps1` | Verifies that shared files are consistent across branches. |

Note: The `deploy-lambda.ps1` and `deploy-glue.ps1` scripts are for manual or emergency deployments only. Normal deployments should always go through the CI/CD pipeline.

---

## Key Relationships

```
Developer edits terraform.tfvars
        |
        v
main.tf reads variables and calls modules/
        |
        v
modules/ define the AWS resources
        |
        v
Pipeline runs terraform plan and terraform apply
        |
        v
Resources created/updated in AWS
```

```
Developer edits code/lambda/ or code/glue/
        |
        v
Pipeline packages the code (build-lambdas.sh)
        |
        v
Terraform detects the changed source_code_hash
        |
        v
Lambda/Glue updated in AWS
```
