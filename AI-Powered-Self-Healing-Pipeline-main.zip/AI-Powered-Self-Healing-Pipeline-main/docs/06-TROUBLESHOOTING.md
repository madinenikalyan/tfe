# Troubleshooting

This document contains solutions to common problems you may encounter while working with the TEGNA Sales Automation infrastructure.

---

## Local Terraform Issues

### Error: Failed to get shared config profile

**Full error:**
```
Error: failed to get shared config profile, default
```

**Cause:** Terraform is trying to use the `default` AWS profile, but it is not configured or the credentials are invalid.

**Solution for DEV:**
```powershell
# Verify your credentials file exists
cat ~/.aws/credentials

# Verify DEV credentials work
aws sts get-caller-identity

# Should return: Account: 591098698873
```

**Solution for UAT:**
```powershell
# Set the UAT profile
$env:AWS_PROFILE = "uat"

# Verify UAT credentials work
aws sts get-caller-identity --profile uat

# Should return: Account: 104350167801

# Then run terraform
terraform plan
```

---

### Error: AWS account ID not allowed

**Full error:**
```
Error: AWS account ID not allowed: 591098698873
```

**Cause:** You are authenticated to the DEV account (591098698873) but trying to run Terraform in the UAT environment, which expects account 104350167801.

**Solution:**
```powershell
$env:AWS_PROFILE = "uat"
terraform plan
```

**Opposite scenario:** If you see `Error: AWS account ID not allowed: 104350167801` while working on DEV, you have the UAT profile set. Unset it or open a new terminal.

---

### Error: Backend initialization required

**Full error:**
```
Error: Backend initialization required, please run "terraform init"
```

**Cause:** Terraform has not been initialized in this directory, or the backend configuration changed.

**Solution:**
```powershell
terraform init -reconfigure
```

The `-reconfigure` flag forces Terraform to reinitialize without asking for confirmation.

---

### Error: Inconsistent dependency lock file

**Full error:**
```
Error: Inconsistent dependency lock file
```

**Cause:** The `.terraform.lock.hcl` file is out of sync with the provider versions.

**Solution:**
```powershell
terraform init -upgrade
```

Then commit the updated `.terraform.lock.hcl` file if it changed.

---

### Terraform plan shows "No changes" but I changed code

**Symptoms:** You modified Lambda or Glue code, but `terraform plan` shows "No changes."

**Possible causes:**

1. **Wrong directory:** Make sure you are editing files in `code/lambda/` or `code/glue/`, not somewhere else.

2. **Terraform hasn't rebuilt the package yet:** The pipeline builds Lambda packages, but locally you may need to manually rebuild.

   **Solution:** Let the pipeline build it. Just push your changes and the pipeline will package the code.

3. **Source code hash didn't change:** If you only edited comments or whitespace, the hash may not change.

   **Solution:** Make a meaningful change to the code.

---

### Terraform plan shows unexpected changes I didn't make

**Symptoms:** The plan output shows changes to resources you did not touch.

**Possible causes:**

1. **State drift:** Someone made manual changes in the AWS console that are not reflected in Terraform state.

   **Solution:** Discuss with the team. You may need to run `terraform refresh` or import the changes.

2. **Module change affecting multiple resources:** You changed a shared module, which affects multiple resources that use that module.

   **Solution:** Review the module change carefully. This is expected behavior.

3. **Edited the wrong file:** You edited a file in the wrong environment folder (dev vs uat).

   **Solution:** Double-check which file you edited.

---

## Git and GitHub Issues

### Error: Failed to push, updates were rejected

**Full error:**
```
! [rejected]        dev -> dev (fetch first)
error: failed to push some refs
```

**Cause:** Your local branch is behind the remote branch. Someone else pushed changes.

**Solution:**
```powershell
git pull origin dev --no-edit
git push origin dev
```

If you encounter merge conflicts, resolve them manually, then commit and push.

---

### How to resolve merge conflicts

**Symptoms:** `git pull` results in conflicts.

**Solution:**

1. Open the conflicted files in your editor. Look for conflict markers:
   ```
   <<<<<<< HEAD
   Your changes
   =======
   Their changes
   >>>>>>> branch-name
   ```

2. Decide which version to keep, or manually merge both.

3. Remove the conflict markers.

4. Save the file.

5. Mark as resolved:
   ```powershell
   git add <conflicted-file>
   ```

6. Complete the merge:
   ```powershell
   git commit
   ```

7. Push:
   ```powershell
   git push origin dev
   ```

---

### I committed to the wrong branch

**Scenario:** You committed changes directly to `dev` instead of a feature branch.

**Solution:**

1. Create a feature branch from the current state:
   ```powershell
   git checkout -b feature/my-changes
   ```

2. Push the feature branch:
   ```powershell
   git push origin feature/my-changes
   ```

3. Reset `dev` to the remote state:
   ```powershell
   git checkout dev
   git reset --hard origin/dev
   ```

4. Create a PR from `feature/my-changes` to `dev`.

---

### I accidentally pushed to the protected branch

**Symptoms:** You pushed directly to `dev` or `uat` and it succeeded.

**Solution:** If the push succeeded, the branch may not be fully protected. Contact the repository admin to enable branch protection rules.

If the push triggered the pipeline and deployed unintended changes, follow the rollback process in `docs/03-BRANCH-STRATEGY.md`.

---

## Pipeline Issues

### Pipeline fails at Build stage

**Common errors:**

**Error:** `SyntaxError: invalid syntax`

**Cause:** Python syntax error in Lambda code.

**Solution:** Fix the syntax error in the Lambda function code, commit, and push.

---

**Error:** `No module named 'xyz'`

**Cause:** Missing dependency in `requirements.txt`.

**Solution:** Add the missing package to `requirements.txt`:
```
xyz==1.2.3
```

---

**Error:** `Permission denied: ./scripts/build-lambdas.sh`

**Cause:** The build script does not have execute permissions.

**Solution:** The script should already have permissions in the repo. If this error occurs, contact the infrastructure team.

---

### Pipeline fails at Terraform Plan stage

**Common errors:**

**Error:** `Error: Unsupported block type`

**Cause:** Terraform syntax error in a `.tf` file.

**Solution:** Review the error message for the line number. Fix the syntax error, commit, and push.

---

**Error:** `Error: Missing required argument`

**Cause:** A required variable was not provided in `terraform.tfvars`.

**Solution:** Add the missing variable to `terraform.tfvars`.

---

**Error:** `Error: error acquiring the state lock`

**Cause:** Another Terraform process is running and has locked the state.

**Solution:** Wait a few minutes for the other process to finish, then re-run the pipeline. If the lock persists for more than 15 minutes, contact the infrastructure team to manually unlock it.

---

**Error:** `Error: error configuring S3 Backend: no valid credential sources found`

**Cause:** GitHub secrets are not configured correctly.

**Solution:** Contact the repository admin to verify that the GitHub secrets (`AWS_ACCESS_KEY_ID_DEV`, `AWS_SECRET_ACCESS_KEY_DEV`, `UAT_AWS_ACCESS_KEY`, `UAT_AWS_SECRET_ACCESS_KEY`) are set correctly.

---

### Pipeline fails at Terraform Apply stage

**Common errors:**

**Error:** `Error: creating S3 Bucket: BucketAlreadyExists`

**Cause:** An S3 bucket with that name already exists (globally unique requirement).

**Solution:** Choose a different bucket name. S3 bucket names must be globally unique across all AWS accounts.

---

**Error:** `Error: UnauthorizedOperation: You are not authorized to perform this operation`

**Cause:** The IAM user/role used by GitHub Actions does not have sufficient permissions.

**Solution:** Contact the DevOps team to review and update the IAM policy.

---

**Error:** `Error: timeout while waiting for resource to reach 'CREATE_COMPLETE' state`

**Cause:** A resource is taking longer than expected to create.

**Solution:** Re-run the pipeline. If it fails again, the resource may have an issue. Check the AWS console for more details.

---

### Pipeline does not trigger

**Symptoms:** You created a PR or pushed changes, but the pipeline did not run.

**Possible causes:**

1. **No files changed in the trigger paths:** The pipeline only runs if you change files in `env/dev/`, `env/uat/`, `modules/`, `code/lambda/`, `code/glue/`, or `.github/workflows/`.

   **Solution:** If you changed files outside those paths, the pipeline will not run. This is expected.

2. **GitHub Actions is disabled for the repository.**

   **Solution:** Contact the repository admin to enable GitHub Actions.

3. **Branch protection rules prevent the pipeline from running.**

   **Solution:** Contact the repository admin to review branch protection settings.

---

## AWS Console Issues

### Resource not found in AWS console

**Symptoms:** Terraform says the resource exists, but you cannot find it in the AWS console.

**Possible causes:**

1. **Wrong AWS account:** You are logged into DEV but looking for a UAT resource (or vice versa).

   **Solution:** Verify which account you are logged into. DEV = 591098698873, UAT = 104350167801.

2. **Wrong region:** You are looking in the wrong AWS region.

   **Solution:** Ensure you are in `us-east-1`.

3. **Resource not yet created:** Terraform plan showed it would be created, but the apply failed.

   **Solution:** Check the pipeline apply logs to see if the resource creation succeeded.

---

### Lambda function exists but code is outdated

**Symptoms:** You deployed new Lambda code, but invoking the function still runs the old code.

**Possible causes:**

1. **Deploy did not actually update:** Check the Terraform apply logs. It should show:
   ```
   module.lambda["function_name"].aws_lambda_function.function: Modifying...
   ```

2. **Lambda has multiple versions:** You may be invoking a specific version or alias, not `$LATEST`.

   **Solution:** Ensure you are invoking the `$LATEST` version, or update the version/alias.

---

## Performance Issues

### Terraform plan is very slow

**Symptoms:** `terraform plan` takes more than 5 minutes.

**Possible causes:**

1. **Large state file:** The infrastructure has grown and Terraform must compare many resources.

   **Solution:** This is normal as the infrastructure grows. Be patient.

2. **Network latency to AWS:** Slow connection to AWS S3 or APIs.

   **Solution:** Ensure you have a stable internet connection.

---

### Pipeline times out

**Symptoms:** The pipeline fails with a timeout error.

**Possible causes:**

1. **Large Lambda packages:** Building large Lambda packages takes time.

   **Solution:** Optimize your Lambda dependencies. Remove unused packages from `requirements.txt`.

2. **AWS API rate limiting:** AWS is throttling API requests.

   **Solution:** Wait a few minutes and re-run the pipeline.

---

## Still Stuck?

If none of the above solutions work:

1. **Check the pipeline logs** for the specific error message.
2. **Search GitHub Issues** in the repository for similar problems.
3. **Ask the team** in your team chat or during standup.
4. **Contact the infrastructure owner:** Manish Kumar (m.kumar@tegna.com)

When asking for help, provide:
- The exact error message
- The steps you took
- The environment (DEV or UAT)
- The PR number or pipeline run link
- Any relevant logs
