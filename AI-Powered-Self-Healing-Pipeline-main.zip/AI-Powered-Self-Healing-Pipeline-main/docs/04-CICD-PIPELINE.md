# CI/CD Pipeline

This document explains how the GitHub Actions CI/CD pipelines work, what happens at each stage, and how to interpret pipeline results.

---

## Pipeline Overview

The repository has two pipelines:

| Pipeline File | Environment | Triggers |
|--------------|-------------|----------|
| `develop-pipeline.yml` | DEV | Pull requests and pushes to `dev` or `develop` branches |
| `uat-pipeline.yml` | UAT | Pull requests and pushes to `uat` or `QA` branches |

Both pipelines follow the same structure but deploy to different AWS accounts.

---

## Pipeline Stages

### Stage 1: Build (runs on PR and push)

**Purpose:** Package Lambda functions and prepare Glue scripts.

**What happens:**
1. Checkout code from the repository
2. Run `scripts/build-lambdas.sh` to create deployment ZIP files for each Lambda function
3. Upload Lambda ZIPs as artifacts (available for download)
4. Glue scripts are already in the repo, no build needed

**When it runs:** On every PR and every push to the base branch.

**Duration:** Typically 1-2 minutes.

**Common failures:**
- Missing `requirements.txt` in a Lambda function folder
- Invalid Python syntax in Lambda code
- `build-lambdas.sh` script permission error

---

### Stage 2: Terraform Plan (runs on PR and push)

**Purpose:** Show what changes Terraform will make to AWS infrastructure.

**What happens:**
1. Configure AWS credentials (using GitHub secrets)
2. Setup Terraform v1.9.8
3. Run `terraform init -reconfigure -backend-config=backend.s3.hcl`
4. Run `terraform validate` to check syntax
5. Run `terraform plan` and save output
6. Post the plan as a comment on the PR (PR only, not on push)

**When it runs:** On every PR and every push to the base branch.

**Duration:** Typically 2-3 minutes.

**What to review in plan output:**

```
Plan: 2 to add, 1 to change, 0 to destroy.

Terraform will perform the following actions:

  # module.s3["customer_analytics"].aws_s3_bucket.bucket will be created
  + resource "aws_s3_bucket" "bucket" {
      + bucket                      = "sales-automation-customer-analytics"
      + versioning_enabled          = true
      ...
    }

  # module.lambda["leads_service"].aws_lambda_function.function will be updated in-place
  ~ resource "aws_lambda_function" "function" {
      ~ source_code_hash            = "abc123..." -> "def456..."
        ...
    }
```

Key symbols:
- `+` = resource will be created
- `-` = resource will be destroyed
- `~` = resource will be modified in-place
- `-/+` = resource will be destroyed and recreated

**Common failures:**
- Terraform syntax error in `.tf` files
- Missing required variable in `terraform.tfvars`
- Invalid AWS resource configuration
- Backend S3 bucket not accessible

---

### Stage 3: PR Approval (manual, PR only)

**Purpose:** Human review of the changes.

**What happens:**
1. Team member reviews the code changes
2. Team member reviews the Terraform plan output
3. Team member approves or requests changes

**When it runs:** Only on PRs, not on direct pushes.

**Duration:** Depends on team availability.

**What the reviewer checks:**
- Code quality and best practices
- Terraform plan output matches intended changes
- No unexpected resource deletions or modifications
- Proper naming conventions
- Security considerations

---

### Stage 4: Deploy Approval (manual, after PR merge)

**Purpose:** Final gate before deployment to AWS.

**What happens:**
1. After PR is merged, the pipeline pauses at "Deploy Approval Required"
2. A designated approver must manually approve the deployment
3. Approval triggers the next stage

**When it runs:** After PR merge, before `terraform apply`.

**Duration:** Depends on approver availability.

**Who can approve:** Configured in GitHub repository settings (typically team leads or senior developers).

---

### Stage 5: Terraform Apply (automatic after approval)

**Purpose:** Actually deploy the changes to AWS.

**What happens:**
1. Configure AWS credentials
2. Setup Terraform
3. Run `terraform init -reconfigure -backend-config=backend.s3.hcl`
4. Re-run `terraform plan` to ensure nothing changed
5. Run `terraform apply` to create/modify/delete resources
6. Post deployment summary

**When it runs:** After Deploy Approval is granted.

**Duration:** Typically 3-10 minutes, depending on resources being changed.

**What happens in AWS:**
- S3 buckets are created/modified
- Lambda function code is updated
- Glue job scripts are uploaded to S3
- IAM policies are updated
- Network resources are modified
- etc.

**Common failures:**
- AWS API rate limiting
- IAM permission errors
- Resource dependency conflicts
- Timeout errors for slow-creating resources

---

## Pipeline Flow Diagram

```
Pull Request Created
        |
        v
    [Build]
        |
        v
[Terraform Plan]
        |
        v
Plan posted as PR comment
        |
        v
[PR Approval Required] <-- Team member reviews
        |
        v
    PR Merged
        |
        v
[Deploy Approval Required] <-- Designated approver
        |
        v
[Terraform Apply]
        |
        v
Changes deployed to AWS
```

---

## Reading Pipeline Logs

### Accessing Logs

1. Go to the GitHub repository
2. Click "Actions" tab
3. Click on the workflow run
4. Click on a job to see its logs

### Understanding Log Output

**Build stage logs:**
```
Building Lambda: sales-automation-leads-service
  Installing dependencies from requirements.txt
  Creating deployment package
  Package created: sales-automation-leads-service.zip (2.3 MB)
```

**Terraform Plan logs:**
```
Terraform used the selected providers to generate the following execution plan.

  # module.lambda["leads_service"].aws_lambda_function.function will be updated
  ~ resource "aws_lambda_function" "function" {
      ~ source_code_hash = "old-hash" -> "new-hash"
    }

Plan: 0 to add, 1 to change, 0 to destroy.
```

**Terraform Apply logs:**
```
module.lambda["leads_service"].aws_lambda_function.function: Modifying...
module.lambda["leads_service"].aws_lambda_function.function: Modifications complete after 12s

Apply complete! Resources: 0 added, 1 changed, 0 destroyed.
```

---

## Pipeline Trigger Paths

The pipeline only runs if files in these paths are changed:

| Path | Triggers DEV Pipeline | Triggers UAT Pipeline |
|------|----------------------|----------------------|
| `env/dev/**` | Yes | No |
| `env/uat/**` | No | Yes |
| `modules/**` | Yes | Yes |
| `code/lambda/**` | Yes | Yes |
| `code/glue/**` | Yes | Yes |
| `.github/workflows/**` | Yes | Yes |

Changes to documentation, scripts, or other files do NOT trigger the pipeline.

---

## GitHub Secrets

The pipelines use these secrets configured in the GitHub repository:

**For DEV:**
- `AWS_ACCESS_KEY_ID_DEV` - AWS access key for DEV account
- `AWS_SECRET_ACCESS_KEY_DEV` - AWS secret key for DEV account

**For UAT:**
- `UAT_AWS_ACCESS_KEY` - AWS access key for UAT account
- `UAT_AWS_SECRET_ACCESS_KEY` - AWS secret key for UAT account

These are configured in GitHub repo settings under Settings > Secrets and variables > Actions.

---

## Pipeline Failure Scenarios

### Scenario 1: Build Fails

**Symptoms:** Build stage shows red X, pipeline stops.

**Common causes:**
- Syntax error in Lambda Python code
- Missing `requirements.txt`
- Invalid package name in `requirements.txt`

**Fix:**
1. Check the build logs for the specific error
2. Fix the error in your feature branch
3. Commit and push - pipeline will re-run

### Scenario 2: Terraform Plan Fails

**Symptoms:** Plan stage shows red X, pipeline stops.

**Common causes:**
- Terraform syntax error in `.tf` files
- Missing required variable
- Invalid resource configuration
- Backend state access error

**Fix:**
1. Check the plan logs for the specific error
2. Fix the Terraform configuration
3. If it is a state lock issue, wait a few minutes and re-run
4. Commit and push to re-trigger the pipeline

### Scenario 3: Terraform Apply Fails

**Symptoms:** Apply stage shows red X, resources may be partially created.

**Common causes:**
- AWS API throttling
- IAM permission denied
- Resource quota exceeded
- Dependency conflict

**Fix:**
1. Check the apply logs for the specific error
2. If it is a transient error (throttling), re-run the pipeline
3. If it is a permission error, contact DevOps team
4. If resources are partially created, determine if a manual cleanup is needed

### Scenario 4: Unexpected Terraform Plan Output

**Symptoms:** Plan shows changes you did not intend to make.

**Causes:**
- Edited the wrong file
- Terraform state drift (someone made manual changes in AWS console)
- Module change affecting multiple resources

**Fix:**
1. Do NOT merge the PR
2. Review your changes carefully
3. If state drift, discuss with team - may need to import or refresh state
4. Fix the configuration and re-run

---

## Best Practices

1. **Always review the plan output** before approving a PR.
2. **Never approve a plan you do not understand.** Ask questions.
3. **Deploy to DEV first,** verify it works, then deploy to UAT.
4. **Monitor the apply stage** logs to confirm successful deployment.
5. **Verify in AWS console** after deployment that resources are created as expected.
6. **Small changes are safer** than large changes. Keep PRs focused.
7. **If in doubt, ask for help** before merging.

---

## Pipeline Monitoring

After a deployment:

1. Check CloudWatch Logs for any Lambda function errors
2. Check AWS console to verify resources exist and are configured correctly
3. Run a quick smoke test if applicable (e.g., invoke a Lambda, run a Glue job)
4. Monitor for any alerts or errors in the first 24 hours

If issues are found, follow the rollback process in `docs/03-BRANCH-STRATEGY.md`.
