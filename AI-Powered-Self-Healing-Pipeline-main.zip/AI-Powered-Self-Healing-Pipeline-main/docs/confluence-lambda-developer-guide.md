# Developer Guide: Adding a Lambda Function via Terraform

**Project:** Sales Automation Infrastructure
**Repository:** `sales-automation`
**Last Updated:** 2026-05-21

---

## Overview

Lambda functions in this project are deployed through a reusable Terraform module at `modules/lambda/`. The module handles:

- Zipping and deploying your function source code
- Automatically building a Python dependency layer if `requirements.txt` is present
- Creating a dedicated IAM execution role with least-privilege policies
- Attaching the function to the private VPC subnets with an auto-created Security Group
- Creating a CloudWatch Log Group with configurable retention

**You only need to edit one file to add a new function: the environment `tfvars` file.**

---

## Architecture

```
tfvars/uat.tfvars
  └── lambda_functions map
        └── functions.tf  (for_each loop)
              └── modules/lambda  (creates all AWS resources)
```

All functions share:
- A single S3 artifacts bucket (`<env>-sales-automation-lambda-artifacts`) for dependency layer zips
- Private Lambda subnets inside the project VPC
- Runtime: `python3.13`, Handler: `lambda_function.lambda_handler`, Timeout: `60s`, Memory: `256 MB`

---

## Step 1 — Create the Function Source Directory

Create a new folder under `functions/` in the repository root. The folder name is typically the function name.

```
functions/
└── my-new-function/
    ├── lambda_function.py       # Required — entry point
    └── requirements.txt         # Optional — pip dependencies (triggers auto layer build)
```

### lambda_function.py

Your handler must be named `lambda_handler` (or update `handler` in `functions.tf`):

```python
def lambda_handler(event, context):
    # your logic here
    return {"statusCode": 200, "body": "OK"}
```

### requirements.txt (optional)

If your function has pip dependencies, list them here. The module automatically builds and uploads a Lambda layer on `terraform apply`.

```
psycopg2-binary==2.9.9
boto3==1.34.0
```

> **Note:** Do **not** include `boto3` unless you need a specific version — it is pre-installed in the Lambda runtime.

---

## Step 2 — Register the Function in tfvars

Open the environment tfvars file (e.g., `tfvars/uat.tfvars`) and add an entry to the `lambda_functions` map.

The **map key** becomes the function name suffix. The final AWS function name will be:
`<environment>-<map-key>` → e.g., `uat-my-new-function`

### Minimal Entry (no env vars, no extra tags)

```hcl
lambda_functions = {

  "my-new-function" = {
    source_path = "functions/my-new-function"
    description = "Brief description of what this function does"
  }

}
```

### Full Entry (with environment variables and tags)

```hcl
lambda_functions = {

  "my-new-function" = {
    source_path = "functions/my-new-function"
    description = "Brief description of what this function does"

    environment_variables = {
      DB_HOST    = "my-db-host.cluster.rds.amazonaws.com"
      SECRET_ARN = "arn:aws:secretsmanager:us-east-1:123456789012:secret:my-secret"
    }

    tags = {
      Service   = "my-new-function"
      Owner     = "your-email@tegna.com"
      Developer = "your-email@tegna.com"
    }
  }

}
```

> **Sensitive values:** Do **not** store secrets as plain-text environment variables. Store them in AWS Secrets Manager or SSM Parameter Store and pass their ARN/name as the env var value. The function retrieves the secret at runtime.

---

## Step 3 — Apply the Changes

```bash
# Review the plan
terraform plan -var-file=tfvars/uat.tfvars

# Apply
terraform apply -var-file=tfvars/uat.tfvars
```

The module will create:
- `aws_lambda_function.lambda_function`
- `aws_iam_role` + attached policies
- `aws_cloudwatch_log_group`
- `aws_security_group` (auto-created, allow-all egress)
- `aws_lambda_layer_version` (only if `requirements.txt` is present)

---

## `lambda_functions` Variable Reference

This is the root-level variable in [variables.tf](../variables.tf) that you configure in tfvars.

| Field | Type | Required | Default | Description |
|---|---|---|---|---|
| `source_path` | `string` | **Yes** | — | Path to the function source folder, relative to the Terraform root. Example: `"functions/my-new-function"` |
| `description` | `string` | No | `""` | Human-readable description shown in the AWS console |
| `environment_variables` | `map(string)` | No | `{}` | Key-value pairs injected into the Lambda runtime environment |
| `tags` | `map(string)` | No | `{}` | Additional AWS resource tags merged with common project tags |

---

## Full Module Variable Reference

The following variables are accepted by `modules/lambda`. Most are already set with sensible defaults in [functions.tf](../functions.tf). You would only need these if directly calling the module or requesting infrastructure changes.

### Function Identity

| Variable | Type | Default | Description |
|---|---|---|---|
| `function_name` | `string` | **required** | Unique Lambda function name. Used as base name for role, log group, and layer. |
| `description` | `string` | `""` | Human-readable description. |

### Source Code

| Variable | Type | Default | Description |
|---|---|---|---|
| `function_source_path` | `string` | **required** | Path to function source directory (relative to Terraform root). The module zips all files except `requirements.txt` and deploys via `filename`. |

### S3 Artifacts (for dependency layers)

| Variable | Type | Default | Description |
|---|---|---|---|
| `lambda_artifacts_bucket` | `string` | `null` | S3 bucket name for layer zip uploads. Required when `requirements.txt` is present. |
| `lambda_s3_key_prefix` | `string` | `null` | S3 key prefix for the layer zip. Defaults to `function_source_path`. |
| `lambda_s3_kms_key_id` | `string` | `null` | KMS key ARN for encrypting the S3 layer zip. Null = bucket default encryption. |

### Runtime Configuration

| Variable | Type | Default | Description |
|---|---|---|---|
| `runtime` | `string` | **required** | Lambda runtime. Examples: `python3.13`, `python3.12`, `nodejs20.x`. Auto layer build only works for Python. |
| `handler` | `string` | `"lambda_function.lambda_handler"` | Entrypoint in `<file>.<function>` format. |
| `architectures` | `list(string)` | `["x86_64"]` | `["x86_64"]` or `["arm64"]`. ARM64 is ~20% cheaper. |
| `publish` | `bool` | `false` | Publish a new version on each deploy. Required for aliases or provisioned concurrency. |

### Performance Tuning

| Variable | Type | Default | Constraints | Description |
|---|---|---|---|---|
| `timeout` | `number` | `30` | 1–900 | Max execution time in seconds. Project default is `60`. |
| `memory_size` | `number` | `128` | 128–10240 | Memory in MB. CPU scales proportionally. Project default is `256`. |
| `reserved_concurrent_executions` | `number` | `-1` | ≥ -1 | `-1` = unreserved. `0` = fully throttled. |
| `ephemeral_storage_size` | `number` | `null` | 512–10240 | `/tmp` storage in MB. Null = Lambda default (512 MB). |

### Environment Variables

| Variable | Type | Default | Description |
|---|---|---|---|
| `environment_variables` | `map(string)` | `{}` | Key-value pairs injected at runtime. Use ARNs for sensitive values — not plain secrets. |

### VPC Configuration

| Variable | Type | Default | Description |
|---|---|---|---|
| `vpc_config` | `object` | `null` | Attach function to VPC. Object has `subnet_ids` (list) and `security_group_ids` (list). |
| `create_security_group` | `bool` | `false` | Create a dedicated SG. Requires `vpc_id`. The created SG is automatically merged with `vpc_config.security_group_ids`. |
| `vpc_id` | `string` | `null` | VPC ID. Required when `create_security_group = true`. |
| `security_group_name` | `string` | `null` | Name for the created SG. Defaults to `<function_name>-sg`. |
| `security_group_description` | `string` | `"Managed by Lambda Terraform module"` | Description for the created SG. |
| `ingress_rules` | `list(object)` | `[]` | Inbound rules for the created SG. See schema below. |
| `egress_rules` | `list(object)` | allow-all outbound | Outbound rules for the created SG. |

**Security Group Rule Schema:**

```hcl
{
  description      = "optional description"
  from_port        = 443        # number
  to_port          = 443        # number
  protocol         = "tcp"      # "tcp", "udp", "icmp", "-1" (all)
  cidr_blocks      = []         # list of IPv4 CIDRs
  ipv6_cidr_blocks = []         # list of IPv6 CIDRs
  security_groups  = []         # list of SG IDs
  self             = false      # bool
}
```

### IAM Permissions

| Variable | Type | Default | Description |
|---|---|---|---|
| `iam_role_path` | `string` | `"/"` | IAM path for the execution role. Must start and end with `/`. |
| `permission_boundary_arn` | `string` | `null` | ARN of IAM managed policy used as permission boundary. |
| `extra_customer_managed_policies` | `map(object)` | `{}` | Create and attach new customer-managed policies. Key = logical name. **Reserved key:** `lambda_baseline`. |
| `extra_customer_managed_policy_arns` | `list(string)` | `[]` | ARNs of existing customer-managed policies to attach. |
| `extra_aws_managed_policy_arns` | `list(string)` | `[]` | ARNs of AWS-managed policies to attach. Use sparingly — prefer narrow custom policies. |
| `extra_inline_policies` | `map(string)` | `{}` | Inline policies embedded directly in the role. Key = policy name, value = JSON document. |

**`extra_customer_managed_policies` entry schema:**

```hcl
{
  name        = "my-function-s3-read"    # string, required
  description = "optional description"   # string, optional
  path        = "/"                      # string, optional
  policy      = data.aws_iam_policy_document.example.json  # JSON string, required
}
```

### Additional Lambda Layers

| Variable | Type | Default | Description |
|---|---|---|---|
| `additional_layer_arns` | `list(string)` | `[]` | Extra layer ARNs appended after the auto-built dependency layer. Max 5 total layers. |

### Dead-Letter Queue

| Variable | Type | Default | Description |
|---|---|---|---|
| `dead_letter_target_arn` | `string` | `null` | SQS queue or SNS topic ARN for failed invocation events. Remember to grant `sqs:SendMessage` or `sns:Publish` on the execution role. |

### Observability

| Variable | Type | Default | Description |
|---|---|---|---|
| `tracing_mode` | `string` | `"PassThrough"` | X-Ray tracing. `"PassThrough"` or `"Active"` (always sample — adds X-Ray permissions). |
| `log_retention_in_days` | `number` | `14` | CloudWatch Logs retention. Common values: 7, 14, 30, 90, 365. `0` = indefinite (not recommended). |
| `log_kms_key_id` | `string` | `null` | KMS key ARN for encrypting the log group. Null = default CloudWatch encryption. |

### Invoke Permissions (Trigger Sources)

All six trigger types share the same schema. Leave lists empty if the trigger type is not needed.

| Variable | Trigger Type | Default |
|---|---|---|
| `s3_invoke_permissions` | S3 bucket notifications | `[]` |
| `api_gateway_invoke_permissions` | API Gateway | `[]` |
| `sns_invoke_permissions` | SNS topic (push) | `[]` |
| `sqs_invoke_permissions` | SQS (resource-based only) | `[]` |
| `eventbridge_invoke_permissions` | EventBridge / CloudWatch Events | `[]` |
| `alb_invoke_permissions` | Application Load Balancer | `[]` |

**Invoke permission entry schema:**

```hcl
{
  statement_id   = "UniqueStatementID"             # string, required
  source_arn     = "arn:aws:s3:::my-bucket"        # string, required
  source_account = "123456789012"                  # string, optional — prevents confused deputy
  qualifier      = null                            # string, optional — alias or version
}
```

### Tags

| Variable | Type | Default | Description |
|---|---|---|---|
| `tags` | `map(string)` | `{}` | Tags applied to all resources. Merged with `local.common_tags` and `Function` tag in the caller. |

---

## Module Outputs Reference

These outputs are available from `module.lambda_functions[<key>]` and are also surfaced at the root level via [outputs.tf](../outputs.tf).

### Root-Level Outputs

| Output | Description |
|---|---|
| `lambda_artifacts_bucket_name` | S3 bucket name for layer artifacts |
| `lambda_artifacts_bucket_arn` | S3 bucket ARN |
| `lambda_function_names` | Map of function key → AWS function name |
| `lambda_function_arns` | Map of function key → function ARN |
| `lambda_layer_arns` | Map of function key → layer ARN (empty string if no layer) |
| `lambda_log_groups` | Map of function key → CloudWatch log group name |
| `lambda_role_arns` | Map of function key → IAM execution role ARN |

### Per-Module Outputs (from `modules/lambda`)

| Output | Description |
|---|---|
| `function_arn` | Unqualified function ARN |
| `function_name` | Function name |
| `function_invoke_arn` | Invoke ARN for API Gateway integration |
| `function_qualified_arn` | Versioned ARN (only meaningful when `publish = true`) |
| `function_version` | Published version number |
| `source_code_hash` | Base64 SHA-256 of the deployment zip |
| `function_zip_path` | Local path to the generated zip file |
| `role_arn` | IAM execution role ARN |
| `role_name` | IAM execution role name |
| `role_id` | IAM execution role ID |
| `log_group_name` | CloudWatch log group name |
| `log_group_arn` | CloudWatch log group ARN |
| `has_layer` | `true` if a dependency layer was built |
| `layer_arn` | Layer ARN including version |
| `layer_version_number` | Layer version number |
| `layer_s3_key` | S3 key of the layer zip |
| `security_group_id` | ID of the module-created SG (empty if not created) |
| `security_group_arn` | ARN of the module-created SG |
| `effective_security_group_ids` | All SG IDs attached to the function |

---

## Common Patterns

### Function with Aurora PostgreSQL Access

If your function needs to connect to the Aurora cluster, request the relevant DB secret ARN from the infrastructure team and pass it as an environment variable:

```hcl
"my-db-function" = {
  source_path = "functions/my-db-function"
  description = "Reads from Aurora PostgreSQL"

  environment_variables = {
    DB_SECRET_ARN = "arn:aws:secretsmanager:us-east-1:123456789012:secret:uat-sales-automation-vbr-service-xxxx"
    DB_NAME       = "sales_automation"
  }

  tags = {
    Service   = "my-db-function"
    Owner     = "your-email@tegna.com"
    Developer = "your-email@tegna.com"
  }
}
```

The function already runs inside the private Lambda subnets with access to the Aurora security group (VPC routing is pre-configured in [functions.tf](../functions.tf)).

### Function with Additional IAM Permissions

For extra AWS permissions (e.g., reading from an S3 bucket), request the update to `locals.tf` / `functions.tf` from the infrastructure team. The `local.lambda_extra_policies` map is where per-function policies are added.

---

## Notes and Constraints

- **Function name uniqueness:** The map key must be unique within the environment. The final name is `<env>-<key>` (e.g., `uat-my-new-function`).
- **Reserved IAM policy key:** Do not use `lambda_baseline` as a key in `extra_customer_managed_policies` — it is reserved by the module.
- **Layer limit:** Lambda supports a maximum of 5 layers per function. The auto-built dependency layer counts as one.
- **Non-Python runtimes:** The automatic layer build from `requirements.txt` only supports Python. For Node.js or Java, supply pre-built layer ARNs via `additional_layer_arns`.
- **SQS Event Source Mapping:** For the typical SQS → Lambda pattern (ESM), invoke permissions are **not** needed — access is controlled by the execution role's SQS receive/delete permissions. Only add `sqs_invoke_permissions` for direct resource-based invocations.
- **Sensitive environment variables:** Never commit secrets as plain text. Always reference Secrets Manager ARNs or SSM parameter names, and retrieve them in the function code at runtime.
- **Deployment package:** Function code is deployed via a local zip (`filename`) — it is **not** uploaded to S3. Only the dependency layer zip goes to S3.
