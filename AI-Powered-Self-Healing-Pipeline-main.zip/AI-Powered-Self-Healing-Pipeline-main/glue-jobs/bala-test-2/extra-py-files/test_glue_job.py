import boto3
import time
import logging
from botocore.exceptions import ClientError

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize Glue client
glue_client = boto3.client('glue')

folder = 'activities'
folder_table_map = {
    "activities": "matrix_activities",
    "billing": "billing_tagged_flat_files",
    "leads": "matrix_leads",
    "pending": "matrix_pending"
}

# Validate folder
if folder not in folder_table_map:
    raise ValueError(f"Folder '{folder}' not found in folder_table_map")

# Define job parameters
job_parameters = {
    '--database_name': folder_table_map[folder]
}

# Start Glue job
try:
    response = glue_client.start_job_run(
        JobName='sales-automation-insert-required-matrix-aurora-db-glue',
        Arguments=job_parameters
    )
    job_run_id = response['JobRunId']
    print(f"Started job run with ID: {job_run_id}")
except ClientError as e:
    print(f"Failed to start Glue job: {e}")
    raise  Exception(f"Error fetching job status: {e}")

# try:
#     job_status = glue_client.get_job_run(
#         JobName='sales-automation-insert-matrix-aurora-db-glue',
#         RunId=job_run_id
#     )['JobRun']['JobRunState']

#     print(f"Current status: {job_status}")

#     # if job_status in ['SUCCEEDED', 'FAILED', 'STOPPED']:
#     #     print(f"Job finished with status: {job_status}")

#     # time.sleep(30)  # Wait before next poll
# except ClientError as e:
#     print(f"Error fetching job status: {e}")
#     rasie Exception(f"Error fetching job status: {e}")
