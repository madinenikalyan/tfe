import sys
from awsglue.utils import getResolvedOptions

args = getResolvedOptions(sys.argv, ['JOB_NAME'])
print(f"Hello from Glue! Job '{args['JOB_NAME']}' is running successfully.")