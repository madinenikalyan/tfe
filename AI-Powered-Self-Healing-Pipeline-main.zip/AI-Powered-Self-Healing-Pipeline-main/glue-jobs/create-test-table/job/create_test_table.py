import sys
import json
import boto3
from awsglue.utils import getResolvedOptions
from awsglue.context import GlueContext
from pyspark.context import SparkContext

args = getResolvedOptions(sys.argv, ["JOB_NAME", "SECRET_ARN"])

sc = SparkContext()
glueContext = GlueContext(sc)
logger = glueContext.get_logger()

logger.info(f"Starting job: {args['JOB_NAME']}")

# Fetch credentials from Secrets Manager
secrets_client = boto3.client("secretsmanager")
secret_resp = secrets_client.get_secret_value(SecretId=args["SECRET_ARN"])
creds = json.loads(secret_resp["SecretString"])

host = creds["host"]
port = creds.get("port")
database = creds["database"]
username = creds["username"]
password = creds["password"]

jdbc_url = f"jdbc:postgresql://{host}:{port}/{database}"

# Create a test table
create_table_sql = """
CREATE TABLE IF NOT EXISTS test_glue_table (
    id          SERIAL PRIMARY KEY,
    name        VARCHAR(255) NOT NULL,
    description TEXT,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
"""

# Use Spark JDBC to execute DDL
from py4j.java_gateway import java_import

java_import(sc._jvm, "java.sql.DriverManager")
java_import(sc._jvm, "java.sql.Statement")

conn = sc._jvm.java.sql.DriverManager.getConnection(jdbc_url, username, password)
stmt = conn.createStatement()
stmt.execute(create_table_sql)
logger.info("Created table: test_glue_table")

# Insert sample rows
insert_sql = """
INSERT INTO test_glue_table (name, description)
VALUES
    ('sample-1', 'First test record from Glue job'),
    ('sample-2', 'Second test record from Glue job'),
    ('sample-3', 'Third test record from Glue job')
"""
stmt.execute(insert_sql)
logger.info("Inserted sample rows into test_glue_table")

# Verify by reading back
rs = stmt.executeQuery("SELECT COUNT(*) FROM test_glue_table")
if rs.next():
    count = rs.getInt(1)
    logger.info(f"Total rows in test_glue_table: {count}")

rs.close()
stmt.close()
conn.close()

logger.info(f"Job {args['JOB_NAME']} completed successfully")
