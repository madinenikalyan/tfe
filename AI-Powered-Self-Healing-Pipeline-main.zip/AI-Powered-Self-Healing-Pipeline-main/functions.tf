################################################################################
# LAMBDA FUNCTIONS
#
# All Lambda function module calls live here.
# Function source code lives under functions/<name>/.
# The module zips the source locally and deploys via filename (no S3 for code).
# Dependency layers (requirements.txt) are built and uploaded to the shared
# Lambda artifacts S3 bucket created below.
################################################################################

################################################################################
# Lambda Artifacts — S3 Bucket
#
# Stores dependency layer zips for all Lambda functions in this project.
# Versioning is enabled so every layer upload is preserved and auditable;
# older versions are retained and can be rolled back without rebuilding.
################################################################################

module "lambda_artifacts_bucket" {
  source = "./modules/s3"

  bucket_name        = "${local.name_prefix}-lambda-artifacts"
  versioning_enabled = true


  tags = merge(local.common_tags, {
    Name    = "${local.name_prefix}-lambda-artifacts"
    Purpose = "lambda-layer-artifacts"
  })
}


################################################################################
# Lambda Functions — for_each over var.lambda_functions
#
# All functions share a single S3 access policy scoped to the artifacts bucket.
# Add a new function by adding an entry to var.lambda_functions in your tfvars.
################################################################################

# Shared policy — all functions need read/write access to the artifacts bucket
# so they can upload and retrieve their dependency layer zips.
data "aws_iam_policy_document" "lambda_artifacts_s3_access" {
  statement {
    sid    = "LambdaArtifactsS3Access"
    effect = "Allow"
    actions = [
      "s3:ListBucket",
      "s3:ListBucketVersions",
      "s3:ListBucketMultipartUploads",
      "s3:GetBucketLocation",
      "s3:GetBucketVersioning",
      "s3:GetObject",
      "s3:GetObjectVersion",
      "s3:PutObject",
      "s3:DeleteObject",
      "s3:AbortMultipartUpload",
      "s3:ListMultipartUploadParts",
    ]
    resources = [
      module.lambda_artifacts_bucket.bucket_arn,
      "${module.lambda_artifacts_bucket.bucket_arn}/*",
    ]
  }
}

module "lambda_functions" {
  for_each = var.lambda_functions
  source   = "./modules/lambda"

  function_name        = "${var.environment}-${each.key}"
  description          = each.value.description
  function_source_path = each.value.source_path
  runtime              = "python3.13"
  handler              = "lambda_function.lambda_handler"
  timeout              = 60
  memory_size          = 256

  lambda_artifacts_bucket = module.lambda_artifacts_bucket.bucket_id

  environment_variables = merge(
    each.value.environment_variables,
    lookup(local.lambda_env_variables, each.key, {})
  )

  vpc_config = {
    subnet_ids         = aws_subnet.sales_automation_private_lambda_subnet[*].id
    security_group_ids = []
  }

  create_security_group = true
  vpc_id                = aws_vpc.sales_automation_vpc.id

  extra_customer_managed_policies = merge(
    {
      s3_artifacts_access = {
        name        = "${var.environment}-${each.key}-s3-access"
        description = "S3 access to lambda artifacts bucket for ${each.key}"
        policy      = data.aws_iam_policy_document.lambda_artifacts_s3_access.json
      }
    },
    lookup(local.lambda_extra_policies, each.key, {})
  )

  # ── Tags ─────────────────────────────────────────────────────────────────────
  tags = merge(local.common_tags, each.value.tags, {
    Function = each.key
  })
}

