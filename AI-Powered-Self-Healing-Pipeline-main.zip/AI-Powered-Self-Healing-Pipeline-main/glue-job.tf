################################################################################
# GLUE SCRIPTS BUCKET
#
# Dedicated S3 bucket for all Glue job artefacts.
# The module mirrors the local folder structure inside each job directory:
#
#   Local:  glue-jobs/<job>/
#               job/              ← main ETL script
#               packages/         ← pre-built packages (optional)
#               extra-py-files/   ← helper Python modules (optional)
#
#   S3:     s3://<bucket>/glue-jobs/<job>/
#               job/              ← uploaded script
#               packages/         ← uploaded if folder exists
#               extra-py-files/   ← uploaded if folder exists
#               temporary/        ← --TempDir (auto)
#               sparkHistoryLogs/ ← --spark-event-logs-path (auto)
################################################################################

module "glue_scripts_bucket" {
  source = "./modules/s3"

  bucket_name        = "${local.name_prefix}-glue-scripts"
  versioning_enabled = true

  tags = merge(local.common_tags, {
    Name    = "${local.name_prefix}-glue-scripts"
    Purpose = "glue-scripts-and-packages"
  })
}

################################################################################
# GLUE SECURITY GROUP
#
# Glue requires a security group with a self-referencing ingress rule that
# opens all TCP ports so workers can communicate with each other.
################################################################################

resource "aws_security_group" "glue" {
  name        = "${local.name_prefix}-glue-sg"
  description = "Security group for Glue jobs - self-referencing ingress for worker communication"
  vpc_id      = aws_vpc.sales_automation_vpc.id

  tags = merge(local.common_tags, {
    Name = "${local.name_prefix}-glue-sg"
  })
}

resource "aws_security_group_rule" "glue_self_ingress" {
  type                     = "ingress"
  from_port                = 0
  to_port                  = 65535
  protocol                 = "tcp"
  source_security_group_id = aws_security_group.glue.id
  security_group_id        = aws_security_group.glue.id
  description              = "Allow all TCP from self - required for Glue worker communication"
}

resource "aws_security_group_rule" "glue_all_egress" {
  type              = "egress"
  from_port         = 0
  to_port           = 0
  protocol          = "-1"
  cidr_blocks       = ["0.0.0.0/0"]
  security_group_id = aws_security_group.glue.id
  description       = "Allow all outbound traffic"
}

################################################################################
# GLUE CONNECTION — Aurora PostgreSQL (JDBC)
#
# Provides Glue jobs with network access to the Aurora cluster via the
# private Glue subnet. The connection uses the RDS-managed master-password
# secret so no plaintext credentials are stored in Terraform state.
################################################################################

resource "aws_glue_connection" "postgres_glue_connection" {
  name            = "${local.name_prefix}-aurora-postgres"
  connection_type = "JDBC"

  connection_properties = {
    JDBC_CONNECTION_URL = "jdbc:postgresql://${module.aurora_postgres.cluster_endpoint}:${module.aurora_postgres.cluster_port}/${var.aurora_database_name}"
    SECRET_ID           = module.db_user_secrets["glue-service"].secret_arn
  }

  physical_connection_requirements {
    availability_zone      = aws_subnet.sales_automation_private_glue_subnet.availability_zone
    subnet_id              = aws_subnet.sales_automation_private_glue_subnet.id
    security_group_id_list = [aws_security_group.glue.id]
  }

  tags = merge(local.common_tags, {
    Name = "${local.name_prefix}-aurora-postgres"
  })
}

################################################################################
# GLUE JOBS
#
# Job definitions live in tfvars/<env>.tfvars under the glue_jobs variable.
# Environments that don't need Glue jobs simply omit the variable (defaults to {}).
#
# Module defaults (no need to repeat in tfvars):
#   command_name        = "glueetl"
#   glue_version        = "5.0"
#   python_version      = "3"
#   worker_type         = "G.1X"
#   number_of_workers   = 2
#   execution_class     = "STANDARD"
#   timeout             = 2800
#   max_retries         = 0
#   max_concurrent_runs = 2
#   log_retention_in_days = 30
#   trigger_type        = "SCHEDULED"
#   trigger_enabled     = true
################################################################################

module "glue_jobs" {
  for_each = var.glue_jobs
  source   = "./modules/glue"

  job_name           = "${local.name_prefix}-${each.key}"
  description        = each.value.description
  job_source_dir     = each.value.job_source_dir
  script_filename    = each.value.script_filename
  script_bucket_name = module.glue_scripts_bucket.bucket_id

  default_arguments = merge(
    each.value.default_arguments,
    {
      "--SECRET_ARN" = module.db_user_secrets["glue-service"].secret_arn
    }
  )
  number_of_workers   = each.value.number_of_workers
  timeout             = each.value.timeout
  max_concurrent_runs = each.value.max_concurrent_runs

  log_retention_in_days = each.value.log_retention_in_days

  connections = [aws_glue_connection.postgres_glue_connection.name]

  extra_customer_managed_policies = merge(
    # Default: all jobs get glue-service DB secret access
    {
      glue_secrets_access = {
        name        = "${local.name_prefix}-${each.key}-secrets-access"
        description = "Allow Glue job to read glue-service DB secret"
        policy = jsonencode({
          Version = "2012-10-17"
          Statement = [
            {
              Sid    = "ReadGlueSecret"
              Effect = "Allow"
              Action = [
                "secretsmanager:GetSecretValue",
                "secretsmanager:DescribeSecret"
              ]
              Resource = [module.db_user_secrets["glue-service"].secret_arn]
            },
            {
              Sid    = "DecryptSecret"
              Effect = "Allow"
              Action = [
                "kms:Decrypt",
                "kms:DescribeKey",
                "kms:GenerateDataKey"
              ]
              Resource = [module.aurora_postgres.kms_key_arn]
            }
          ]
        })
      }
    },

    # Per-job: extra S3 bucket access (resolved from s3_buckets keys)
    length(each.value.extra_s3_bucket_keys) > 0 ? {
      glue_extra_s3_access = {
        name        = "${local.name_prefix}-${each.key}-extra-s3-access"
        description = "Allow Glue job to access additional S3 buckets"
        policy = jsonencode({
          Version = "2012-10-17"
          Statement = [
            {
              Sid    = "S3BucketList"
              Effect = "Allow"
              Action = ["s3:GetBucketLocation", "s3:ListBucket"]
              Resource = [for k in each.value.extra_s3_bucket_keys : module.s3_buckets[k].bucket_arn]
            },
            {
              Sid    = "S3ObjectAccess"
              Effect = "Allow"
              Action = [
                "s3:GetObject",
                "s3:PutObject",
                "s3:DeleteObject"
              ]
              Resource = [for k in each.value.extra_s3_bucket_keys : "${module.s3_buckets[k].bucket_arn}/*"]
            }
          ]
        })
      }
    } : {},

    # Per-job: extra Secrets Manager access (resolved from db_users keys)
    length(each.value.extra_secret_keys) > 0 ? {
      glue_extra_secrets_access = {
        name        = "${local.name_prefix}-${each.key}-extra-secrets-access"
        description = "Allow Glue job to read additional secrets"
        policy = jsonencode({
          Version = "2012-10-17"
          Statement = [
            {
              Sid    = "ReadExtraSecrets"
              Effect = "Allow"
              Action = [
                "secretsmanager:GetSecretValue",
                "secretsmanager:DescribeSecret"
              ]
              Resource = [for k in each.value.extra_secret_keys : module.db_user_secrets[k].secret_arn]
            }
          ]
        })
      }
    } : {}
  )

  create_trigger      = each.value.create_trigger
  trigger_schedule    = each.value.trigger_schedule
  trigger_description = each.value.trigger_description

  # Crawler
  create_crawler        = each.value.create_crawler
  crawler_description   = each.value.crawler_description
  crawler_database_name = each.value.crawler_database_name
  crawler_table_prefix  = each.value.crawler_table_prefix
  crawler_schedule      = each.value.crawler_schedule
  crawler_s3_targets    = each.value.crawler_s3_targets
  crawler_jdbc_targets  = each.value.crawler_jdbc_targets

  tags = merge(local.common_tags, {
    Name      = "${local.name_prefix}-${each.key}"
    Component = "glue-etl"
  })
}
