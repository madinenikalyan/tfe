<#
.SYNOPSIS
    Deploy Glue job script without touching Terraform

.DESCRIPTION
    This script allows developers to update Glue job scripts and configuration
    without needing Terraform knowledge. It uploads the script to S3 and
    updates job configuration based on job-config.json.

.PARAMETER JobName
    The Glue job name (must match folder name in code/glue/)

.PARAMETER Environment
    Target environment (dev, uat, or prod)

.PARAMETER Region
    AWS Region (default: us-east-1)

.EXAMPLE
    .\deploy-glue.ps1 -JobName "sales-automation-insert-matrix-aurora-db-glue" -Environment "dev"

.EXAMPLE
    .\deploy-glue.ps1 -JobName "sales-automation-lead-scoring-aurora" -Environment "uat"
#>

param(
    [Parameter(Mandatory=$true)]
    [string]$JobName,
    
    [Parameter(Mandatory=$true)]
    [ValidateSet("dev", "uat", "prod")]
    [string]$Environment,
    
    [Parameter(Mandatory=$false)]
    [string]$Region = "us-east-1"
)

$ErrorActionPreference = "Stop"

# Paths
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$RootDir = Split-Path -Parent $ScriptDir
$CodePath = Join-Path $RootDir "code\glue\$JobName"
$S3Bucket = "sales-automation-aws-glue-assets"
$S3Key = "scripts/$JobName.py"

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Glue Job Deployment Script" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Job Name: $JobName" -ForegroundColor White
Write-Host "Environment: $Environment" -ForegroundColor White
Write-Host "Region: $Region" -ForegroundColor White
Write-Host ""

# Validate code path exists
if (-not (Test-Path $CodePath)) {
    Write-Host "ERROR: Code path not found: $CodePath" -ForegroundColor Red
    Write-Host "Please ensure your Glue script is in: code/glue/$JobName/" -ForegroundColor Yellow
    exit 1
}

# Validate script.py exists
$ScriptFile = Join-Path $CodePath "script.py"
if (-not (Test-Path $ScriptFile)) {
    Write-Host "ERROR: script.py not found in $CodePath" -ForegroundColor Red
    exit 1
}

# Upload script to S3
Write-Host "[1/2] Uploading Glue script to S3..." -ForegroundColor Yellow
Write-Host "    Bucket: s3://$S3Bucket/$S3Key" -ForegroundColor Gray

$UploadResult = aws s3 cp $ScriptFile "s3://$S3Bucket/$S3Key" --region $Region 2>&1

if ($LASTEXITCODE -ne 0) {
    Write-Host "ERROR: Failed to upload script to S3" -ForegroundColor Red
    Write-Host $UploadResult -ForegroundColor Red
    exit 1
}

Write-Host "    Script uploaded successfully!" -ForegroundColor Green

# Update job configuration if job-config.json exists
if (Test-Path "$CodePath\job-config.json") {
    Write-Host "[2/2] Updating Glue job configuration..." -ForegroundColor Yellow
    
    $Config = Get-Content "$CodePath\job-config.json" | ConvertFrom-Json
    
    # Build default arguments
    $DefaultArgs = @{}
    if ($Config.default_arguments) {
        $Config.default_arguments.PSObject.Properties | ForEach-Object {
            $DefaultArgs[$_.Name] = $_.Value
        }
    }
    $DefaultArgsJson = $DefaultArgs | ConvertTo-Json -Compress -Depth 10
    
    # Build job update JSON
    $JobUpdate = @{
        MaxRetries = $Config.max_retries
        Timeout = $Config.timeout
        NumberOfWorkers = $Config.number_of_workers
        WorkerType = $Config.worker_type
        GlueVersion = $Config.glue_version
        DefaultArguments = $DefaultArgs
    } | ConvertTo-Json -Depth 10
    
    $ConfigResult = aws glue update-job `
        --job-name $JobName `
        --job-update $JobUpdate `
        --region $Region `
        --output json 2>&1
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host "    Configuration updated successfully!" -ForegroundColor Green
    } else {
        Write-Host "    WARNING: Configuration update failed (script still uploaded)" -ForegroundColor Yellow
        Write-Host $ConfigResult -ForegroundColor Gray
    }
} else {
    Write-Host "[2/2] No job-config.json found, skipping configuration update" -ForegroundColor Gray
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "  Deployment Complete!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host "Job: $JobName" -ForegroundColor White
Write-Host "Status: Deployed successfully" -ForegroundColor Green
Write-Host ""
Write-Host "To run your Glue job:" -ForegroundColor Cyan
Write-Host "  aws glue start-job-run --job-name $JobName --region $Region" -ForegroundColor Gray
Write-Host ""
