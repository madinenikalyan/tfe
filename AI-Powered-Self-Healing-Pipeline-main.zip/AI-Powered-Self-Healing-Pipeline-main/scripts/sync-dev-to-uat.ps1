<#
.SYNOPSIS
    Copy all Lambda and Glue code from DEV to UAT

.DESCRIPTION
    This script copies the entire code structure from DEV to UAT environment
    and updates configuration files to reflect UAT settings.

.EXAMPLE
    .\sync-dev-to-uat.ps1
#>

$ErrorActionPreference = "Stop"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$RootDir = Split-Path -Parent $ScriptDir
$DevCodePath = Join-Path $RootDir "code"
$UatCodePath = Join-Path $RootDir "code-uat"

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  DEV to UAT Code Sync" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Validate DEV code exists
if (-not (Test-Path $DevCodePath)) {
    Write-Host "ERROR: DEV code path not found: $DevCodePath" -ForegroundColor Red
    exit 1
}

# Create UAT code directory
if (-not (Test-Path $UatCodePath)) {
    New-Item -ItemType Directory -Path $UatCodePath -Force | Out-Null
}

# Copy Lambda code
Write-Host "[1/3] Copying Lambda functions..." -ForegroundColor Yellow
$LambdaSource = Join-Path $DevCodePath "lambda"
$LambdaTarget = Join-Path $UatCodePath "lambda"

if (Test-Path $LambdaSource) {
    Copy-Item -Path $LambdaSource -Destination $UatCodePath -Recurse -Force
    $LambdaCount = (Get-ChildItem -Path $LambdaSource -Directory).Count
    Write-Host "    Copied $LambdaCount Lambda functions" -ForegroundColor Green
} else {
    Write-Host "    No Lambda code found" -ForegroundColor Gray
}

# Copy Glue code
Write-Host "[2/3] Copying Glue jobs..." -ForegroundColor Yellow
$GlueSource = Join-Path $DevCodePath "glue"
$GlueTarget = Join-Path $UatCodePath "glue"

if (Test-Path $GlueSource) {
    Copy-Item -Path $GlueSource -Destination $UatCodePath -Recurse -Force
    $GlueCount = (Get-ChildItem -Path $GlueSource -Directory).Count
    Write-Host "    Copied $GlueCount Glue jobs" -ForegroundColor Green
} else {
    Write-Host "    No Glue code found" -ForegroundColor Gray
}

# Update Lambda configs for UAT
Write-Host "[3/3] Updating configurations for UAT environment..." -ForegroundColor Yellow
$UpdatedConfigs = 0

Get-ChildItem -Path "$UatCodePath\lambda" -Recurse -Filter "config.json" -ErrorAction SilentlyContinue | ForEach-Object {
    $ConfigFile = $_.FullName
    $Config = Get-Content $ConfigFile | ConvertFrom-Json
    
    # Update environment variable
    if ($Config.environment) {
        if ($Config.environment.ENVIRONMENT) {
            $Config.environment.ENVIRONMENT = "uat"
        } else {
            $Config.environment | Add-Member -MemberType NoteProperty -Name "ENVIRONMENT" -Value "uat" -Force
        }
    }
    
    $Config | ConvertTo-Json -Depth 10 | Set-Content $ConfigFile
    $UpdatedConfigs++
}

Write-Host "    Updated $UpdatedConfigs Lambda configuration files" -ForegroundColor Green

Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "  Sync Complete!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""
Write-Host "Next steps:" -ForegroundColor Cyan
Write-Host "  1. Review code in: $UatCodePath" -ForegroundColor White
Write-Host "  2. Update any UAT-specific configurations" -ForegroundColor White
Write-Host "  3. Deploy to UAT using deploy scripts with -Environment uat" -ForegroundColor White
Write-Host ""
