#!/bin/bash
# Build Lambda deployment packages from source code
# This script runs in GitHub Actions (Ubuntu runner)
# Usage: ./build-lambdas.sh <env>
# Example: ./build-lambdas.sh uat
#          ./build-lambdas.sh dev

set -e

# Require environment parameter
ENV="${1:?Usage: $0 <env> (e.g., dev, uat)}"

SOURCE_DIR="env/${ENV}/code/lambda"
OUTPUT_DIR="env/${ENV}/lambda-deployment-packages"

echo "========================================"
echo "  Building Lambda Deployment Packages   "
echo "========================================"

# Create output directory if it doesn't exist
mkdir -p "$OUTPUT_DIR"

# Get all lambda function folders
for lambda_dir in "$SOURCE_DIR"/*/; do
    if [ -d "$lambda_dir" ]; then
        lambda_name=$(basename "$lambda_dir")
        zip_name="${lambda_name}.zip"
        zip_path="${OUTPUT_DIR}/${zip_name}"
        
        echo "Building: $lambda_name"
        
        # Create temporary directory
        temp_dir=$(mktemp -d)
        
        # Copy lambda source to temp directory
        cp -r "${lambda_dir}"* "$temp_dir/"
        
        # Install dependencies if requirements.txt exists
        if [ -f "${temp_dir}/requirements.txt" ]; then
            echo "  Installing dependencies..."
            pip install -r "${temp_dir}/requirements.txt" -t "$temp_dir" --quiet --upgrade
        fi
        
        # Remove unnecessary files to reduce package size
        find "$temp_dir" -type d -name "__pycache__" -exec rm -rf {} + 2>/dev/null || true
        find "$temp_dir" -type d -name "*.dist-info" -exec rm -rf {} + 2>/dev/null || true
        find "$temp_dir" -type d -name "*.egg-info" -exec rm -rf {} + 2>/dev/null || true
        find "$temp_dir" -type f -name "*.pyc" -delete 2>/dev/null || true
        
        # Create zip file
        cd "$temp_dir"
        zip -r -q "$OLDPWD/$zip_path" .
        cd "$OLDPWD"
        
        # Cleanup temp directory
        rm -rf "$temp_dir"
        
        # Show zip size
        size=$(du -h "$zip_path" | cut -f1)
        echo "  Created: $zip_name ($size)"
    fi
done

echo ""
echo "========================================"
echo "  Build Complete!                       "
echo "========================================"
echo "Total packages: $(ls -1 "$OUTPUT_DIR"/*.zip 2>/dev/null | wc -l)"
