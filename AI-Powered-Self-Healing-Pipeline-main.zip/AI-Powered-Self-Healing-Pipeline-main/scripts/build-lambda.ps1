<#
.SYNOPSIS
    Build Lambda deployment packages from source code.

.DESCRIPTION
    This script builds ZIP deployment packages for AWS Lambda functions
    from the source code in code/lambda/ folder.

.PARAMETER FunctionName
    Name of the Lambda function to build. If not specified, builds all.

.PARAMETER Environment
    Target environment (dev, uat, prod). Determines output location.

.PARAMETER All
    Build all Lambda functions.

.EXAMPLE
    # Build single Lambda for UAT
    .\build-lambda.ps1 -FunctionName "sales-automation-leads-service" -Environment "uat"

    # Build all Lambdas for UAT
    .\build-lambda.ps1 -All -Environment "uat"

    # Build all Lambdas for DEV
    .\build-lambda.ps1 -All -Environment "dev"
#>

param(
    [string]$FunctionName,
    [ValidateSet("dev", "uat", "prod")]
    [string]$Environment = "uat",
    [switch]$All
)

$ErrorActionPreference = "Stop"

# Paths
$RootDir = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$SourceDir = Join-Path $RootDir "code\lambda"
$OutputDir = Join-Path $RootDir "env\$Environment\lambda-deployment-packages"

Write-Host "=" * 60 -ForegroundColor Cyan
Write-Host "Lambda Build Script" -ForegroundColor Cyan
Write-Host "=" * 60 -ForegroundColor Cyan
Write-Host "Source: $SourceDir"
Write-Host "Output: $OutputDir"
Write-Host "Environment: $Environment"
Write-Host ""

# Ensure output directory exists
if (-not (Test-Path $OutputDir)) {
    New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null
}

function Build-LambdaPackage {
    param(
        [string]$LambdaName,
        [string]$SourcePath,
        [string]$OutputPath
    )
    
    Write-Host "`n Building: $LambdaName" -ForegroundColor Yellow
    
    $TempDir = Join-Path $env:TEMP "lambda-build-$LambdaName"
    $ZipFile = Join-Path $OutputPath "$LambdaName.zip"
    
    # Cleanup previous build
    if (Test-Path $TempDir) {
        Remove-Item -Recurse -Force $TempDir
    }
    New-Item -ItemType Directory -Path $TempDir | Out-Null
    
    # Copy Lambda source files
    Write-Host "   Copying source files..."
    Get-ChildItem -Path $SourcePath -File | ForEach-Object {
        if ($_.Extension -in @(".py", ".json", ".txt", ".yaml", ".yml")) {
            Copy-Item $_.FullName -Destination $TempDir
        }
    }
    
    # Check for requirements.txt and install dependencies
    $RequirementsFile = Join-Path $SourcePath "requirements.txt"
    if (Test-Path $RequirementsFile) {
        Write-Host "   Installing dependencies from requirements.txt..."
        
        # Filter out dependencies that come from Lambda layers
        $LayerDeps = @("psycopg2", "psycopg2-binary", "boto3", "botocore", "pandas", "numpy")
        $TempReqs = Join-Path $TempDir "requirements_filtered.txt"
        
        Get-Content $RequirementsFile | Where-Object {
            $line = $_.Trim()
            if ([string]::IsNullOrWhiteSpace($line) -or $line.StartsWith("#")) {
                return $false
            }
            $isLayerDep = $false
            foreach ($dep in $LayerDeps) {
                if ($line -match "^$dep") {
                    $isLayerDep = $true
                    Write-Host "      Skipping $dep (from Lambda Layer)" -ForegroundColor DarkGray
                    break
                }
            }
            return -not $isLayerDep
        } | Set-Content $TempReqs
        
        if ((Get-Content $TempReqs | Measure-Object -Line).Lines -gt 0) {
            pip install -r $TempReqs -t $TempDir --quiet --disable-pip-version-check 2>$null
        }
        Remove-Item $TempReqs -ErrorAction SilentlyContinue
    }
    
    # Remove unnecessary files to reduce package size
    Write-Host "   Cleaning up..."
    Get-ChildItem -Path $TempDir -Include @("*.pyc", "__pycache__", "*.dist-info", "*.egg-info", "tests", "test") -Recurse | 
        Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
    
    # Create ZIP
    Write-Host "   Creating ZIP package..."
    if (Test-Path $ZipFile) {
        Remove-Item $ZipFile -Force
    }
    
    Compress-Archive -Path (Join-Path $TempDir "*") -DestinationPath $ZipFile -Force
    
    # Cleanup
    Remove-Item -Recurse -Force $TempDir
    
    # Report
    $Size = [math]::Round((Get-Item $ZipFile).Length / 1KB, 2)
    Write-Host "    Created: $ZipFile ($Size KB)" -ForegroundColor Green
    
    return $ZipFile
}

# Get list of Lambda functions to build
$LambdasToBuild = @()

if ($All) {
    # Build all Lambdas that have source code
    $LambdasToBuild = Get-ChildItem -Path $SourceDir -Directory | 
        Where-Object { Test-Path (Join-Path $_.FullName "lambda_function.py") } |
        Select-Object -ExpandProperty Name
    Write-Host "Found $($LambdasToBuild.Count) Lambda functions to build"
}
elseif ($FunctionName) {
    $LambdasToBuild = @($FunctionName)
}
else {
    Write-Host "Please specify -FunctionName or -All" -ForegroundColor Red
    Write-Host ""
    Write-Host "Examples:"
    Write-Host "  .\build-lambda.ps1 -FunctionName 'sales-automation-leads-service' -Environment 'uat'"
    Write-Host "  .\build-lambda.ps1 -All -Environment 'uat'"
    exit 1
}

# Build each Lambda
$BuiltCount = 0
$FailedCount = 0
$Results = @()

foreach ($lambda in $LambdasToBuild) {
    $LambdaSourcePath = Join-Path $SourceDir $lambda
    
    if (-not (Test-Path $LambdaSourcePath)) {
        Write-Host " Source not found: $LambdaSourcePath" -ForegroundColor Red
        $FailedCount++
        continue
    }
    
    if (-not (Test-Path (Join-Path $LambdaSourcePath "lambda_function.py"))) {
        Write-Host " Skipping $lambda (no lambda_function.py)" -ForegroundColor Yellow
        continue
    }
    
    try {
        $ZipFile = Build-LambdaPackage -LambdaName $lambda -SourcePath $LambdaSourcePath -OutputPath $OutputDir
        $BuiltCount++
        $Results += @{Name=$lambda; Status="Success"; Path=$ZipFile}
    }
    catch {
        Write-Host " Failed to build $lambda : $_" -ForegroundColor Red
        $FailedCount++
        $Results += @{Name=$lambda; Status="Failed"; Error=$_.ToString()}
    }
}

# Summary
Write-Host ""
Write-Host "=" * 60 -ForegroundColor Cyan
Write-Host "Build Summary" -ForegroundColor Cyan
Write-Host "=" * 60 -ForegroundColor Cyan
Write-Host " Built: $BuiltCount"
Write-Host " Failed: $FailedCount"
Write-Host "📁 Output: $OutputDir"
Write-Host ""

if ($BuiltCount -gt 0) {
    Write-Host "Next steps:" -ForegroundColor Yellow
    Write-Host "1. Review the built packages in: $OutputDir"
    Write-Host "2. Run terraform plan to see changes:"
    Write-Host "   cd env\$Environment"
    Write-Host "   terraform plan"
    Write-Host "3. Apply changes:"
    Write-Host "   terraform apply"
}
