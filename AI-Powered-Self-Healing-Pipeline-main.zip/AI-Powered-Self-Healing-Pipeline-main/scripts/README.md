# Deployment Scripts

PowerShell scripts for deploying Lambda and Glue code without Terraform knowledge.

## Available Scripts

### 1. download-code-from-aws.ps1
Downloads all Lambda and Glue code from AWS to local `code/` directory.

**Usage:**
```powershell
.\download-code-from-aws.ps1 -Environment "dev"
```

**When to use:**
- First time setup
- Sync local code with AWS
- Backup current AWS code

---

### 2. deploy-lambda.ps1
Deploy Lambda function code and configuration to AWS.

**Usage:**
```powershell
.\deploy-lambda.ps1 -FunctionName "sales-automation-leads-service" -Environment "dev"
```

**Parameters:**
- `-FunctionName`: Lambda function name (matches folder in code/lambda/)
- `-Environment`: Target environment (dev, uat, prod)
- `-Region`: AWS region (default: us-east-1)

**What it does:**
1. Packages Python code with dependencies
2. Creates deployment ZIP
3. Uploads to AWS Lambda
4. Updates function configuration from config.json

**Example:**
```powershell
# Deploy to DEV
.\deploy-lambda.ps1 -FunctionName "sales-automation-mdm-api" -Environment "dev"

# Deploy to UAT
.\deploy-lambda.ps1 -FunctionName "sales-automation-mdm-api" -Environment "uat"
```

---

### 3. deploy-glue.ps1
Deploy Glue job script and configuration to AWS.

**Usage:**
```powershell
.\deploy-glue.ps1 -JobName "sales-automation-insert-matrix-aurora-db-glue" -Environment "dev"
```

**Parameters:**
- `-JobName`: Glue job name (matches folder in code/glue/)
- `-Environment`: Target environment (dev, uat, prod)
- `-Region`: AWS region (default: us-east-1)

**What it does:**
1. Uploads script.py to S3 (sales-automation-aws-glue-assets bucket)
2. Updates Glue job configuration from job-config.json

**Example:**
```powershell
# Deploy to DEV
.\deploy-glue.ps1 -JobName "sales-automation-lead-scoring-aurora" -Environment "dev"

# Deploy to UAT
.\deploy-glue.ps1 -JobName "sales-automation-lead-scoring-aurora" -Environment "uat"
```

---

### 4. sync-dev-to-uat.ps1
Copy all DEV code to UAT and update configurations.

**Usage:**
```powershell
.\sync-dev-to-uat.ps1
```

**What it does:**
1. Copies all Lambda functions from code/ to code-uat/
2. Copies all Glue jobs from code/ to code-uat/
3. Updates config.json files to set ENVIRONMENT=uat

**When to use:**
- Creating UAT environment from DEV
- Promoting tested DEV code to UAT

---

## Prerequisites

### AWS CLI Configuration
```powershell
aws configure
```

Required:
- AWS Access Key ID
- AWS Secret Access Key
- Default region: us-east-1

### Python Installation
Required for Lambda deployments:
```powershell
python --version  # Should be 3.9+
pip --version
```

### Permissions Required
Your AWS user/role needs:
- `lambda:UpdateFunctionCode`
- `lambda:UpdateFunctionConfiguration`
- `lambda:GetFunction`
- `glue:UpdateJob`
- `glue:GetJob`
- `s3:PutObject` (for Glue scripts)
- `s3:GetObject`

## Workflow Examples

### Update Lambda Code Only
```powershell
# 1. Edit code
code\lambda\sales-automation-leads-service\lambda_function.py

# 2. Deploy
cd scripts
.\deploy-lambda.ps1 -FunctionName "sales-automation-leads-service" -Environment "dev"
```

### Update Lambda Configuration Only
```powershell
# 1. Edit config
code\lambda\sales-automation-leads-service\config.json

# 2. Deploy (even without code changes)
cd scripts
.\deploy-lambda.ps1 -FunctionName "sales-automation-leads-service" -Environment "dev"
```

### Deploy Everything from DEV to UAT
```powershell
# 1. Sync code
cd scripts
.\sync-dev-to-uat.ps1

# 2. Deploy each Lambda to UAT
.\deploy-lambda.ps1 -FunctionName "sales-automation-leads-service" -Environment "uat"
.\deploy-lambda.ps1 -FunctionName "sales-automation-mdm-api" -Environment "uat"
# ... etc

# 3. Deploy each Glue job to UAT
.\deploy-glue.ps1 -JobName "sales-automation-insert-matrix-aurora-db-glue" -Environment "uat"
# ... etc
```

### Backup Current AWS Code
```powershell
cd scripts
.\download-code-from-aws.ps1 -Environment "dev"

# Commit to git
cd ..
git add code/
git commit -m "Backup: DEV code as of $(Get-Date -Format 'yyyy-MM-dd')"
git push
```

## Troubleshooting

### Error: Function not found
- Check function name spelling (case-sensitive)
- Verify function exists in AWS console
- Ensure correct region

### Error: Access denied
- Check AWS credentials: `aws sts get-caller-identity`
- Verify IAM permissions
- Try `aws configure` again

### Error: Python dependencies failed
- Check `requirements.txt` syntax
- Ensure pip is installed: `pip --version`
- Try installing locally first: `pip install -r requirements.txt`

### Error: ZIP file too large
Lambda has 50MB zipped / 250MB unzipped limit:
- Remove unnecessary dependencies
- Use Lambda Layers for large libraries
- Optimize package size

### Error: S3 upload failed (Glue)
- Check S3 bucket exists: `sales-automation-aws-glue-assets`
- Verify S3 write permissions
- Check bucket region matches

## Tips

- **Test locally first** before deploying
- **Commit to git** before deploying
- **Deploy to DEV** before UAT/PROD
- **Review config.json** before deployment
- **Check AWS console** after deployment

## Need Help?

Contact DevOps team or check:
- Main README: `../README.md`
- Code README: `../code/README.md`
- AWS Lambda docs: https://docs.aws.amazon.com/lambda/
- AWS Glue docs: https://docs.aws.amazon.com/glue/
