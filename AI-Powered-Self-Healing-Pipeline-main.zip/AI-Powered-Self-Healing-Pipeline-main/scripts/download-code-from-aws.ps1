<#
.SYNOPSIS
    Download all Lambda and Glue code from AWS to local code/ directory

.DESCRIPTION
    This script downloads all Lambda function code and Glue job scripts from AWS
    and organizes them in the code/ directory structure for version control.

.PARAMETER Environment
    Source environment (dev, uat, or prod)

.PARAMETER Region
    AWS Region (default: us-east-1)

.EXAMPLE
    .\download-code-from-aws.ps1 -Environment "dev"
#>

param(
    [Parameter(Mandatory=$true)]
    [ValidateSet("dev", "uat", "prod")]
    [string]$Environment,
    
    [Parameter(Mandatory=$false)]
    [string]$Region = "us-east-1"
)

$ErrorActionPreference = "Stop"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$RootDir = Split-Path -Parent $ScriptDir
$CodePath = Join-Path $RootDir "code"
$TempDir = Join-Path $env:TEMP "aws-code-download-$(Get-Date -Format 'yyyyMMddHHmmss')"

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  AWS Code Download Script" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Environment: $Environment" -ForegroundColor White
Write-Host "Region: $Region" -ForegroundColor White
Write-Host ""

New-Item -ItemType Directory -Path $TempDir -Force | Out-Null

# Download Lambda functions
Write-Host "[1/2] Downloading Lambda functions..." -ForegroundColor Yellow
$LambdaDir = Join-Path $CodePath "lambda"
New-Item -ItemType Directory -Path $LambdaDir -Force | Out-Null

$LambdaFunctions = aws lambda list-functions --region $Region --output json | ConvertFrom-Json
$LambdaCount = 0

foreach ($Function in $LambdaFunctions.Functions) {
    $FunctionName = $Function.FunctionName
    
    # Skip if not matching environment prefix
    if ($FunctionName -notlike "sales-automation-*" -and $FunctionName -notlike "Get*" -and $FunctionName -notlike "fetch*" -and $FunctionName -notlike "conversion*") {
        continue
    }
    
    Write-Host "    Downloading: $FunctionName" -ForegroundColor Gray
    
    $FunctionDir = Join-Path $LambdaDir $FunctionName
    New-Item -ItemType Directory -Path $FunctionDir -Force | Out-Null
    
    # Get function code URL
    $CodeUrl = aws lambda get-function --function-name $FunctionName --region $Region --query 'Code.Location' --output text
    
    # Download ZIP
    $ZipFile = Join-Path $TempDir "$FunctionName.zip"
    Invoke-WebRequest -Uri $CodeUrl -OutFile $ZipFile
    
    # Extract to function directory
    Expand-Archive -Path $ZipFile -DestinationPath $FunctionDir -Force
    
    # Create config.json from function configuration
    $FunctionConfig = aws lambda get-function-configuration --function-name $FunctionName --region $Region --output json | ConvertFrom-Json
    
    $Config = @{
        timeout = $FunctionConfig.Timeout
        memory = $FunctionConfig.MemorySize
        runtime = $FunctionConfig.Runtime
        environment = @{}
        description = $FunctionConfig.Description
    }
    
    if ($FunctionConfig.Environment.Variables) {
        $FunctionConfig.Environment.Variables.PSObject.Properties | ForEach-Object {
            $Config.environment[$_.Name] = $_.Value
        }
    }
    
    $Config | ConvertTo-Json -Depth 10 | Set-Content (Join-Path $FunctionDir "config.json")
    
    $LambdaCount++
}

Write-Host "    Downloaded $LambdaCount Lambda functions" -ForegroundColor Green

# Download Glue jobs
Write-Host "[2/2] Downloading Glue job scripts..." -ForegroundColor Yellow
$GlueDir = Join-Path $CodePath "glue"
New-Item -ItemType Directory -Path $GlueDir -Force | Out-Null

$GlueJobs = aws glue get-jobs --region $Region --output json | ConvertFrom-Json
$GlueCount = 0

foreach ($Job in $GlueJobs.Jobs) {
    $JobName = $Job.Name
    
    # Skip if not matching sales-automation pattern
    if ($JobName -notlike "sales-automation-*" -and $JobName -notlike "sales_automation*" -and $JobName -notlike "*seamless*" -and $JobName -notlike "test*") {
        continue
    }
    
    Write-Host "    Downloading: $JobName" -ForegroundColor Gray
    
    $JobDir = Join-Path $GlueDir $JobName
    New-Item -ItemType Directory -Path $JobDir -Force | Out-Null
    
    # Download script from S3
    $ScriptLocation = $Job.Command.ScriptLocation
    if ($ScriptLocation) {
        aws s3 cp $ScriptLocation (Join-Path $JobDir "script.py") --region $Region --quiet
        
        # Create job-config.json
        $JobConfig = @{
            max_retries = $Job.MaxRetries
            timeout = $Job.Timeout
            number_of_workers = $Job.NumberOfWorkers
            worker_type = $Job.WorkerType
            glue_version = $Job.GlueVersion
            default_arguments = @{}
        }
        
        if ($Job.DefaultArguments) {
            $Job.DefaultArguments.PSObject.Properties | ForEach-Object {
                $JobConfig.default_arguments[$_.Name] = $_.Value
            }
        }
        
        $JobConfig | ConvertTo-Json -Depth 10 | Set-Content (Join-Path $JobDir "job-config.json")
        
        $GlueCount++
    }
}

Write-Host "    Downloaded $GlueCount Glue job scripts" -ForegroundColor Green

# Cleanup
Remove-Item $TempDir -Recurse -Force

Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "  Download Complete!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host "Lambda functions: $LambdaCount" -ForegroundColor White
Write-Host "Glue jobs: $GlueCount" -ForegroundColor White
Write-Host ""
Write-Host "Code location: $CodePath" -ForegroundColor Cyan
Write-Host ""
Write-Host "Next steps:" -ForegroundColor Cyan
Write-Host "  1. Review downloaded code in code/ directory" -ForegroundColor White
Write-Host "  2. Commit to git for version control" -ForegroundColor White
Write-Host "  3. Use deploy scripts to push changes back to AWS" -ForegroundColor White
Write-Host ""
