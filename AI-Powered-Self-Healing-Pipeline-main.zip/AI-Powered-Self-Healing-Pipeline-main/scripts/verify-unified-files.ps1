# Verify Unified Files Between develop (dev) and QA (uat) Branches
# =================================================================
# Compares git blob hashes to ensure unified terraform files are identical
# across branches. Run from repo root.
#
# Usage: .\scripts\verify-unified-files.ps1

param(
    [string]$DevBranch = "develop",
    [string]$QABranch = "QA",
    [string]$DevEnvPath = "env/dev",
    [string]$QAEnvPath = "env/uat"
)

$unifiedFiles = @("main.tf", "variables.tf", "outputs.tf", "provider.tf")
$envSpecificFiles = @("backend.tf", "terraform.tfvars")

$allPassed = $true

Write-Host "`n=== Unified files (must be IDENTICAL) ===" -ForegroundColor White
foreach ($f in $unifiedFiles) {
    $devHash = git rev-parse "${DevBranch}:${DevEnvPath}/$f" 2>$null
    $qaHash  = git rev-parse "${QABranch}:${QAEnvPath}/$f" 2>$null

    if (-not $devHash) {
        Write-Host "  $f : MISSING in $DevBranch" -ForegroundColor Red
        $allPassed = $false
    } elseif (-not $qaHash) {
        Write-Host "  $f : MISSING in $QABranch" -ForegroundColor Red
        $allPassed = $false
    } elseif ($devHash -eq $qaHash) {
        Write-Host "  $f : IDENTICAL" -ForegroundColor Green
    } else {
        Write-Host "  $f : DIFFERENT" -ForegroundColor Red
        $allPassed = $false
    }
}

Write-Host "`n=== Env-specific files (expected to differ) ===" -ForegroundColor White
foreach ($f in $envSpecificFiles) {
    $devHash = git rev-parse "${DevBranch}:${DevEnvPath}/$f" 2>$null
    $qaHash  = git rev-parse "${QABranch}:${QAEnvPath}/$f" 2>$null

    if (-not $devHash) {
        Write-Host "  $f : MISSING in $DevBranch" -ForegroundColor Red
    } elseif (-not $qaHash) {
        Write-Host "  $f : MISSING in $QABranch" -ForegroundColor Red
    } elseif ($devHash -eq $qaHash) {
        Write-Host "  $f : IDENTICAL (unexpected - should differ)" -ForegroundColor Yellow
    } else {
        Write-Host "  $f : ENV-SPECIFIC (OK)" -ForegroundColor Yellow
    }
}

Write-Host ""
if ($allPassed) {
    Write-Host "RESULT: All unified files are consistent." -ForegroundColor Green
} else {
    Write-Host "RESULT: Unified files have differences - review needed!" -ForegroundColor Red
}
Write-Host ""
