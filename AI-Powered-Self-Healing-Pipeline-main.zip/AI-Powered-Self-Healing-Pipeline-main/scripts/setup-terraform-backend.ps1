# Setup S3 Buckets and DynamoDB for Terraform State
# Run this script ONCE to create the required infrastructure for CI/CD pipeline

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Terraform State Backend Setup Script  " -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan

# ============================================
# DEV Account Setup (591098698873)
# ============================================
Write-Host "`n[DEV Account] Creating S3 bucket and DynamoDB table..." -ForegroundColor Yellow

# Create S3 bucket for DEV
aws s3api create-bucket `
    --bucket tegna-sales-automation-tfstate-dev `
    --region us-east-1 `
    --profile default 2>$null

# Enable versioning on DEV bucket
aws s3api put-bucket-versioning `
    --bucket tegna-sales-automation-tfstate-dev `
    --versioning-configuration Status=Enabled `
    --profile default

# Enable encryption on DEV bucket
aws s3api put-bucket-encryption `
    --bucket tegna-sales-automation-tfstate-dev `
    --server-side-encryption-configuration '{
        "Rules": [{
            "ApplyServerSideEncryptionByDefault": {
                "SSEAlgorithm": "AES256"
            }
        }]
    }' `
    --profile default

# Block public access on DEV bucket
aws s3api put-public-access-block `
    --bucket tegna-sales-automation-tfstate-dev `
    --public-access-block-configuration '{
        "BlockPublicAcls": true,
        "IgnorePublicAcls": true,
        "BlockPublicPolicy": true,
        "RestrictPublicBuckets": true
    }' `
    --profile default

# Create DynamoDB table for state locking (DEV)
aws dynamodb create-table `
    --table-name terraform-state-lock `
    --attribute-definitions AttributeName=LockID,AttributeType=S `
    --key-schema AttributeName=LockID,KeyType=HASH `
    --billing-mode PAY_PER_REQUEST `
    --region us-east-1 `
    --profile default 2>$null

Write-Host "[DEV] S3 bucket and DynamoDB created!" -ForegroundColor Green

# ============================================
# UAT Account Setup (104350167801)
# ============================================
Write-Host "`n[UAT Account] Creating S3 bucket and DynamoDB table..." -ForegroundColor Yellow

# Create S3 bucket for UAT
aws s3api create-bucket `
    --bucket tegna-sales-automation-tfstate-uat `
    --region us-east-1 `
    --profile uat 2>$null

# Enable versioning on UAT bucket
aws s3api put-bucket-versioning `
    --bucket tegna-sales-automation-tfstate-uat `
    --versioning-configuration Status=Enabled `
    --profile uat

# Enable encryption on UAT bucket
aws s3api put-bucket-encryption `
    --bucket tegna-sales-automation-tfstate-uat `
    --server-side-encryption-configuration '{
        "Rules": [{
            "ApplyServerSideEncryptionByDefault": {
                "SSEAlgorithm": "AES256"
            }
        }]
    }' `
    --profile uat

# Block public access on UAT bucket
aws s3api put-public-access-block `
    --bucket tegna-sales-automation-tfstate-uat `
    --public-access-block-configuration '{
        "BlockPublicAcls": true,
        "IgnorePublicAcls": true,
        "BlockPublicPolicy": true,
        "RestrictPublicBuckets": true
    }' `
    --profile uat

# Create DynamoDB table for state locking (UAT)
aws dynamodb create-table `
    --table-name terraform-state-lock `
    --attribute-definitions AttributeName=LockID,AttributeType=S `
    --key-schema AttributeName=LockID,KeyType=HASH `
    --billing-mode PAY_PER_REQUEST `
    --region us-east-1 `
    --profile uat 2>$null

Write-Host "[UAT] S3 bucket and DynamoDB created!" -ForegroundColor Green

# ============================================
# Summary
# ============================================
Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "  Setup Complete!                       " -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host @"

Created Resources:
------------------
DEV Account (591098698873):
  - S3 Bucket: tegna-sales-automation-tfstate-dev
  - DynamoDB:  terraform-state-lock

UAT Account (104350167801):
  - S3 Bucket: tegna-sales-automation-tfstate-uat
  - DynamoDB:  terraform-state-lock

Next Steps:
-----------
1. Add GitHub Secrets:
   - AWS_ACCESS_KEY_ID_DEV
   - AWS_SECRET_ACCESS_KEY_DEV
   - AWS_ACCESS_KEY_ID_UAT
   - AWS_SECRET_ACCESS_KEY_UAT

2. Create GitHub Environments:
   - 'dev' (with required reviewers)
   - 'uat' (with required reviewers)

3. Initialize Terraform locally:
   cd env/dev
   terraform init -reconfigure -backend-config=backend.local.hcl

"@ -ForegroundColor White
