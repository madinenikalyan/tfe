<#
.SYNOPSIS
    Deploy Lambda function code without touching Terraform

.DESCRIPTION
    This script allows developers to update Lambda function code and configuration
    without needing Terraform knowledge. It packages the code, uploads to AWS,
    and updates configuration based on config.json.

.PARAMETER FunctionName
    The Lambda function name (must match folder name in code/lambda/)

.PARAMETER Environment
    Target environment (dev, uat, or prod)

.PARAMETER Region
    AWS Region (default: us-east-1)

.EXAMPLE
    .\deploy-lambda.ps1 -FunctionName "sales-automation-leads-service" -Environment "dev"

.EXAMPLE
    .\deploy-lambda.ps1 -FunctionName "sales-automation-seamlessai-monthly-api" -Environment "uat"
#>

param(
    [Parameter(Mandatory=$true)]
    [string]$FunctionName,
    
    [Parameter(Mandatory=$true)]
    [ValidateSet("dev", "uat", "prod")]
    [string]$Environment,
    
    [Parameter(Mandatory=$false)]
    [string]$Region = "us-east-1"
)

$ErrorActionPreference = "Stop"

# Paths
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$RootDir = Split-Path -Parent $ScriptDir
$CodePath = Join-Path $RootDir "code\lambda\$FunctionName"
$TempDir = Join-Path $env:TEMP "lambda-deploy-$(Get-Date -Format 'yyyyMMddHHmmss')"
$ZipFile = Join-Path $env:TEMP "$FunctionName-$(Get-Date -Format 'yyyyMMdd-HHmmss').zip"

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Lambda Deployment Script" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Function: $FunctionName" -ForegroundColor White
Write-Host "Environment: $Environment" -ForegroundColor White
Write-Host "Region: $Region" -ForegroundColor White
Write-Host ""

# Validate code path exists
if (-not (Test-Path $CodePath)) {
    Write-Host "ERROR: Code path not found: $CodePath" -ForegroundColor Red
    Write-Host "Please ensure your Lambda code is in: code/lambda/$FunctionName/" -ForegroundColor Yellow
    exit 1
}

# Create temp directory
New-Item -ItemType Directory -Path $TempDir -Force | Out-Null
Write-Host "[1/5] Created temporary directory" -ForegroundColor Green

# Copy code to temp directory
Write-Host "[2/5] Copying source code..." -ForegroundColor Yellow
Copy-Item -Path "$CodePath\*" -Destination $TempDir -Recurse -Force -Exclude @("config.json", "*.zip", "package")

# Install dependencies if requirements.txt exists
if (Test-Path "$CodePath\requirements.txt") {
    Write-Host "[3/5] Installing Python dependencies..." -ForegroundColor Yellow
    $PackageDir = Join-Path $TempDir "package"
    
    python -m pip install -r "$CodePath\requirements.txt" -t $PackageDir --quiet
    
    if ($LASTEXITCODE -ne 0) {
        Write-Host "ERROR: Failed to install dependencies" -ForegroundColor Red
        Remove-Item $TempDir -Recurse -Force
        exit 1
    }
    
    # Move dependencies to root of package
    Get-ChildItem $PackageDir | Move-Item -Destination $TempDir -Force
    Remove-Item $PackageDir -Force
} else {
    Write-Host "[3/5] No requirements.txt found, skipping dependencies" -ForegroundColor Gray
}

# Create ZIP package
Write-Host "[4/5] Creating deployment package..." -ForegroundColor Yellow
Compress-Archive -Path "$TempDir\*" -DestinationPath $ZipFile -Force

$ZipSizeMB = [math]::Round((Get-Item $ZipFile).Length / 1MB, 2)
Write-Host "    Package size: $ZipSizeMB MB" -ForegroundColor Gray

# Deploy to AWS Lambda
Write-Host "[5/5] Deploying to AWS Lambda..." -ForegroundColor Yellow
$DeployResult = aws lambda update-function-code `
    --function-name $FunctionName `
    --zip-file "fileb://$ZipFile" `
    --region $Region `
    --output json 2>&1

if ($LASTEXITCODE -ne 0) {
    Write-Host "ERROR: Failed to deploy Lambda function" -ForegroundColor Red
    Write-Host $DeployResult -ForegroundColor Red
    Remove-Item $TempDir -Recurse -Force
    Remove-Item $ZipFile -Force
    exit 1
}

Write-Host "    Code deployment successful!" -ForegroundColor Green

# Update configuration if config.json exists
if (Test-Path "$CodePath\config.json") {
    Write-Host ""
    Write-Host "Updating Lambda configuration..." -ForegroundColor Yellow
    
    $Config = Get-Content "$CodePath\config.json" | ConvertFrom-Json
    
    # Build environment variables
    $EnvVars = @{}
    if ($Config.environment) {
        $Config.environment.PSObject.Properties | ForEach-Object {
            $EnvVars[$_.Name] = $_.Value
        }
    }
    $EnvVarsJson = $EnvVars | ConvertTo-Json -Compress -Depth 10
    
    $ConfigResult = aws lambda update-function-configuration `
        --function-name $FunctionName `
        --runtime $($Config.runtime) `
        --timeout $($Config.timeout) `
        --memory-size $($Config.memory) `
        --environment "Variables=$EnvVarsJson" `
        --region $Region `
        --output json 2>&1
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host "    Configuration updated successfully!" -ForegroundColor Green
    } else {
        Write-Host "    WARNING: Configuration update failed (code still deployed)" -ForegroundColor Yellow
        Write-Host $ConfigResult -ForegroundColor Gray
    }
}

# Cleanup
Remove-Item $TempDir -Recurse -Force
Remove-Item $ZipFile -Force

Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "  Deployment Complete!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host "Function: $FunctionName" -ForegroundColor White
Write-Host "Status: Deployed successfully" -ForegroundColor Green
Write-Host ""
Write-Host "To test your function:" -ForegroundColor Cyan
Write-Host "  aws lambda invoke --function-name $FunctionName --region $Region response.json" -ForegroundColor Gray
Write-Host ""
