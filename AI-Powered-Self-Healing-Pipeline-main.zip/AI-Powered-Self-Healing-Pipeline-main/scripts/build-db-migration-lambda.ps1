<#
.SYNOPSIS
    Build Lambda deployment package for database migration function.

.DESCRIPTION
    Creates a ZIP file containing the Lambda function code and dependencies
    for the sales-automation-db-migration Lambda.

.PARAMETER OutputPath
    Path to output the ZIP file. Defaults to lambda-deployment-packages folder.

.EXAMPLE
    .\build-db-migration-lambda.ps1
#>

param(
    [string]$OutputPath = "..\..\lambda-deployment-packages"
)

$ErrorActionPreference = "Stop"

# Get script directory
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$LambdaDir = Join-Path $ScriptDir "..\code\lambda\db-migration"
$TempDir = Join-Path $env:TEMP "db-migration-lambda-build"
$OutputFile = Join-Path $OutputPath "sales-automation-db-migration.zip"

Write-Host "=" * 60 -ForegroundColor Cyan
Write-Host "Building Database Migration Lambda Package" -ForegroundColor Cyan
Write-Host "=" * 60 -ForegroundColor Cyan

# Cleanup previous build
if (Test-Path $TempDir) {
    Remove-Item -Recurse -Force $TempDir
}
New-Item -ItemType Directory -Path $TempDir | Out-Null

Write-Host "`n📁 Source: $LambdaDir"
Write-Host " Output: $OutputFile"

# Check if source exists
if (-not (Test-Path (Join-Path $LambdaDir "lambda_function.py"))) {
    Write-Host " Error: Lambda source not found at $LambdaDir" -ForegroundColor Red
    exit 1
}

# Copy Lambda code
Write-Host "`n Copying Lambda code..."
Copy-Item -Path (Join-Path $LambdaDir "lambda_function.py") -Destination $TempDir

# Check for requirements.txt and install dependencies
$RequirementsFile = Join-Path $LambdaDir "requirements.txt"
if (Test-Path $RequirementsFile) {
    Write-Host " Installing Python dependencies..."
    
    # Create a virtual environment or install directly to package dir
    # Note: psycopg2-binary won't work on Lambda - need to use Lambda Layer
    # We'll skip dependencies that are in the layer
    
    $LayerDeps = @("psycopg2", "psycopg2-binary", "boto3", "botocore")
    $Requirements = Get-Content $RequirementsFile | Where-Object { 
        $line = $_
        -not ($LayerDeps | Where-Object { $line -match "^$_" })
    }
    
    if ($Requirements.Count -gt 0) {
        $FilteredReqs = Join-Path $TempDir "requirements_filtered.txt"
        $Requirements | Set-Content $FilteredReqs
        
        # Install to package directory
        pip install -r $FilteredReqs -t $TempDir --quiet 2>$null
        Remove-Item $FilteredReqs -ErrorAction SilentlyContinue
    }
    
    Write-Host "   ℹ️  Note: psycopg2 comes from Lambda Layer (sales-automation-leads-service-layer)"
}

# Remove unnecessary files
Write-Host "🧹 Cleaning up unnecessary files..."
Get-ChildItem -Path $TempDir -Include "*.pyc", "__pycache__", "*.dist-info", "*.egg-info" -Recurse | 
    Remove-Item -Recurse -Force -ErrorAction SilentlyContinue

# Create output directory if needed
$OutputDir = Split-Path -Parent $OutputFile
if (-not (Test-Path $OutputDir)) {
    New-Item -ItemType Directory -Path $OutputDir | Out-Null
}

# Create ZIP file
Write-Host " Creating ZIP package..."
if (Test-Path $OutputFile) {
    Remove-Item $OutputFile
}

# Use Compress-Archive or 7-Zip
Compress-Archive -Path (Join-Path $TempDir "*") -DestinationPath $OutputFile -Force

# Verify
if (Test-Path $OutputFile) {
    $Size = (Get-Item $OutputFile).Length / 1KB
    Write-Host "`n Lambda package created successfully!" -ForegroundColor Green
    Write-Host "    File: $OutputFile"
    Write-Host "    Size: $([math]::Round($Size, 2)) KB"
} else {
    Write-Host " Error: Failed to create ZIP package" -ForegroundColor Red
    exit 1
}

# Cleanup
Remove-Item -Recurse -Force $TempDir

Write-Host "`n" + "=" * 60 -ForegroundColor Cyan
Write-Host "Build Complete!" -ForegroundColor Cyan
Write-Host "=" * 60 -ForegroundColor Cyan

Write-Host "`nNext steps:"
Write-Host "1. Deploy Lambda to AWS (via Terraform or manual upload)"
Write-Host "2. Ensure Lambda has the sales-automation-leads-service-layer attached"
Write-Host "3. Test with: aws lambda invoke --function-name sales-automation-db-migration --payload '{\"sql\":\"SELECT 1\",\"dry_run\":true}' response.json"
