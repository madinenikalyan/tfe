################################################################################
# KEYPAIR SECRETS
#
# Generates RSA keypairs via the tls provider and stores both the private
# key and public key as a single JSON secret in Secrets Manager.
#
# Driven by var.keypairs — add a new map entry to generate another keypair.
#
# Secret naming: <env>-<project>/<key>-keypair
# Secret value:  { "private_key": "...", "public_key": "..." }
################################################################################

resource "tls_private_key" "keypair" {
  for_each = var.keypairs

  algorithm = each.value.algorithm
  rsa_bits  = each.value.rsa_bits
}

module "keypair_secret" {
  for_each = var.keypairs
  source   = "./modules/secrets-manager"

  account_id = data.aws_caller_identity.current.account_id
  aws_region = var.aws_region

  name        = "${local.name_prefix}/${each.key}-keypair"
  description = "RSA keypair (${each.key}) for ${var.project_name}"

  secret_string = jsonencode({
    private_key = tls_private_key.keypair[each.key].private_key_pem
    public_key  = tls_private_key.keypair[each.key].public_key_pem
  })

  recovery_window_in_days = 30
  tags                    = merge(local.common_tags, { Keypair = each.key })
}
