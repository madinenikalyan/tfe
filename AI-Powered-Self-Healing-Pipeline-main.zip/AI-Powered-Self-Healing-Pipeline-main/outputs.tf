################################################################################
# VPC
################################################################################

output "vpc_id" {
  description = "The ID of the VPC"
  value       = aws_vpc.sales_automation_vpc.id
}

output "vpc_cidr_block" {
  description = "The CIDR block of the VPC"
  value       = aws_vpc.sales_automation_vpc.cidr_block
}

################################################################################
# Subnets
################################################################################

output "public_subnet_ids" {
  description = "List of public subnet IDs"
  value       = aws_subnet.sales_automation_public_subnet[*].id
}

output "public_subnet_cidrs" {
  description = "List of public subnet CIDR blocks"
  value       = aws_subnet.sales_automation_public_subnet[*].cidr_block
}

output "private_lambda_subnet_ids" {
  description = "List of private Lambda subnet IDs"
  value       = aws_subnet.sales_automation_private_lambda_subnet[*].id
}

output "private_lambda_subnet_cidrs" {
  description = "List of private Lambda subnet CIDR blocks"
  value       = aws_subnet.sales_automation_private_lambda_subnet[*].cidr_block
}

output "private_db_subnet_ids" {
  description = "List of private database subnet IDs"
  value       = aws_subnet.sales_automation_private_db_subnet[*].id
}

output "private_db_subnet_cidrs" {
  description = "List of private database subnet CIDR blocks"
  value       = aws_subnet.sales_automation_private_db_subnet[*].cidr_block
}

output "private_glue_subnet_id" {
  description = "The ID of the private Glue subnet"
  value       = aws_subnet.sales_automation_private_glue_subnet.id
}

output "private_glue_subnet_cidr" {
  description = "The CIDR block of the private Glue subnet"
  value       = aws_subnet.sales_automation_private_glue_subnet.cidr_block
}

################################################################################
# Internet Gateway
################################################################################

output "internet_gateway_id" {
  description = "The ID of the Internet Gateway"
  value       = aws_internet_gateway.sales_automation_igw.id
}

################################################################################
# NAT Gateway
################################################################################

output "nat_gateway_id" {
  description = "The ID of the NAT Gateway"
  value       = var.enable_nat_gateway ? aws_nat_gateway.sales_automation_nat_gateway[0].id : null
}

output "nat_gateway_public_ip" {
  description = "The public IP of the NAT Gateway"
  value       = var.enable_nat_gateway ? aws_eip.sales_automation_nat_eip[0].public_ip : null
}


################################################################################
# Route Tables
################################################################################

output "public_route_table_id" {
  description = "The ID of the public route table"
  value       = aws_route_table.sales_automation_public.id
}

output "private_route_table_ids" {
  description = "List of private route table IDs (one per AZ)"
  value       = aws_route_table.sales_automation_private[*].id
}

################################################################################
# VPC Flow Logs
################################################################################

output "flow_log_bucket_arn" {
  description = "The ARN of the VPC flow logs S3 bucket"
  value       = var.enable_flow_log ? module.flow_log_bucket[0].bucket_arn : null
}

output "flow_log_bucket_id" {
  description = "The name of the VPC flow logs S3 bucket"
  value       = var.enable_flow_log ? module.flow_log_bucket[0].bucket_id : null
}

output "flow_log_id" {
  description = "The ID of the VPC flow log"
  value       = var.enable_flow_log ? aws_flow_log.vpc_flow_log[0].id : null
}

# ################################################################################
# # Lambda Artifacts S3 Bucket
# ################################################################################

output "lambda_artifacts_bucket_name" {
  description = "Name of the S3 bucket storing Lambda dependency layer zips."
  value       = module.lambda_artifacts_bucket.bucket_id
}

output "lambda_artifacts_bucket_arn" {
  description = "ARN of the Lambda artifacts S3 bucket."
  value       = module.lambda_artifacts_bucket.bucket_arn
}

################################################################################
# Lambda Functions
################################################################################

output "lambda_function_names" {
  description = "Map of deployed Lambda function names, keyed by the lambda_functions map key."
  value       = { for k, fn in module.lambda_functions : k => fn.function_name }
}

output "lambda_function_arns" {
  description = "Map of deployed Lambda function ARNs, keyed by the lambda_functions map key."
  value       = { for k, fn in module.lambda_functions : k => fn.function_arn }
}

output "lambda_layer_arns" {
  description = "Map of dependency layer ARNs, keyed by function key. Null for functions without requirements.txt."
  value       = { for k, fn in module.lambda_functions : k => fn.layer_arn }
}

output "lambda_log_groups" {
  description = "Map of CloudWatch log group names, keyed by the lambda_functions map key."
  value       = { for k, fn in module.lambda_functions : k => fn.log_group_name }
}

output "lambda_role_arns" {
  description = "Map of IAM execution role ARNs, keyed by the lambda_functions map key."
  value       = { for k, fn in module.lambda_functions : k => fn.role_arn }
}


################################################################################
# S3 Buckets
################################################################################

output "s3_bucket_ids" {
  description = "Map of S3 bucket names keyed by the bucket key defined in var.s3_buckets."
  value = {
    for key, bucket in module.s3_buckets : key => bucket.bucket_id
  }
}

output "s3_bucket_arns" {
  description = "Map of S3 bucket ARNs keyed by the bucket key defined in var.s3_buckets."
  value = {
    for key, bucket in module.s3_buckets : key => bucket.bucket_arn
  }
}

# ################################################################################
# # OUTPUTS
# # Expose role ARNs so other .tf files (Lambda, Glue, Step Functions resources)
# # can reference them without duplicating ARN strings.
# ################################################################################

# output "lambda_execution_role_arn" {
#   description = "ARN of the Lambda execution role."
#   value       = module.lambda_execution_role.role_arn
# }

# output "glue_job_role_arn" {
#   description = "ARN of the Glue ETL job execution role."
#   value       = module.glue_job_role.role_arn
# }

# output "sfn_execution_role_arn" {
#   description = "ARN of the Step Functions state machine execution role."
#   value       = module.sfn_execution_role.role_arn
# }

################################################################################
# Caller Identity
################################################################################

output "caller_account_id" {
  description = "AWS account ID of the identity running Terraform."
  value       = data.aws_caller_identity.current.account_id
}

################################################################################
# API Gateway
################################################################################

output "api_gateway_invoke_urls" {
  description = "Map of API Gateway invoke URLs keyed by API name."
  value       = { for k, api in module.api_gateways : k => api.invoke_url }
}

output "api_gateway_rest_api_ids" {
  description = "Map of REST API IDs keyed by API name."
  value       = { for k, api in module.api_gateways : k => api.rest_api_id }
}

# ################################################################################
# # VPC Endpoints
# ################################################################################

# output "vpc_endpoint_ids" {
#   description = "Map of VPC endpoint IDs keyed by logical name."
#   value       = { for k, ep in module.vpc_endpoints : k => ep.id }
# }

# output "vpc_endpoint_states" {
#   description = "Map of VPC endpoint states keyed by logical name."
#   value       = { for k, ep in module.vpc_endpoints : k => ep.state }
# }

# output "vpc_endpoint_dns_entries" {
#   description = "Map of VPC endpoint DNS entries keyed by logical name."
#   value       = { for k, ep in module.vpc_endpoints : k => ep.dns_entry }
# }

################################################################################
# Keypair Secrets
################################################################################

output "keypair_secret_arns" {
  description = "Map of keypair secret ARNs keyed by keypair name."
  value       = { for k, v in module.keypair_secret : k => v.secret_arn }
}

