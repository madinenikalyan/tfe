################################################################################
# VPC
################################################################################

resource "aws_vpc" "sales_automation_vpc" {
  cidr_block           = var.vpc_cidr
  enable_dns_support   = var.enable_dns_support
  enable_dns_hostnames = var.enable_dns_hostnames

  tags = merge(local.common_tags, {
    Name = "${local.name_prefix}-vpc"
  })
}

################################################################################
# Internet Gateway
################################################################################

resource "aws_internet_gateway" "sales_automation_igw" {
  vpc_id = aws_vpc.sales_automation_vpc.id

  tags = merge(local.common_tags, {
    Name = "${local.name_prefix}-igw"
  })
}

################################################################################
# Public Subnets (2 - one per AZ)
################################################################################

resource "aws_subnet" "sales_automation_public_subnet" {
  count = length(var.public_subnet_cidrs)

  vpc_id                  = aws_vpc.sales_automation_vpc.id
  cidr_block              = var.public_subnet_cidrs[count.index]
  availability_zone       = var.availability_zones[count.index]
  map_public_ip_on_launch = true

  tags = merge(local.common_tags, {
    Name = "${local.name_prefix}-subnet-public-${local.az_suffixes[count.index]}"
    Tier = "public"
  })
}

################################################################################
# Private Lambda Subnets (2 - one per AZ)
################################################################################

resource "aws_subnet" "sales_automation_private_lambda_subnet" {
  count = length(var.private_lambda_subnet_cidrs)

  vpc_id            = aws_vpc.sales_automation_vpc.id
  cidr_block        = var.private_lambda_subnet_cidrs[count.index]
  availability_zone = var.availability_zones[count.index]

  tags = merge(local.common_tags, {
    Name = "${local.name_prefix}-subnet-private-lambda-${local.az_suffixes[count.index]}"
    Tier = "private"
  })
}

################################################################################
# Private Database Subnets (2 - one per AZ)
################################################################################

resource "aws_subnet" "sales_automation_private_db_subnet" {
  count = length(var.private_db_subnet_cidrs)

  vpc_id            = aws_vpc.sales_automation_vpc.id
  cidr_block        = var.private_db_subnet_cidrs[count.index]
  availability_zone = var.availability_zones[count.index]

  tags = merge(local.common_tags, {
    Name = "${local.name_prefix}-subnet-private-db-${local.az_suffixes[count.index]}"
    Tier = "private"
  })
}

################################################################################
# Private Glue Subnet (1 - us-east-1b only)
################################################################################

resource "aws_subnet" "sales_automation_private_glue_subnet" {
  vpc_id            = aws_vpc.sales_automation_vpc.id
  cidr_block        = var.private_glue_subnet_cidr
  availability_zone = var.availability_zones[1]

  tags = merge(local.common_tags, {
    Name    = "${local.name_prefix}-subnet-private-glue-${local.az_suffixes[1]}"
    Tier    = "private"
    Purpose = "glue"
  })
}

################################################################################
# Elastic IP for NAT Gateway
################################################################################

resource "aws_eip" "sales_automation_nat_eip" {
  count  = var.enable_nat_gateway ? 1 : 0
  domain = "vpc"

  tags = merge(local.common_tags, {
    Name = "${local.name_prefix}-eip-nat-${local.az_suffixes[0]}"
  })

  depends_on = [aws_internet_gateway.sales_automation_igw]
}

################################################################################
# NAT Gateway (single, in first public subnet - us-east-1a)
################################################################################

resource "aws_nat_gateway" "sales_automation_nat_gateway" {
  count = var.enable_nat_gateway ? 1 : 0

  allocation_id = aws_eip.sales_automation_nat_eip[0].id
  subnet_id     = aws_subnet.sales_automation_public_subnet[0].id

  tags = merge(local.common_tags, {
    Name = "${local.name_prefix}-nat-public-${local.az_suffixes[0]}"
  })

  depends_on = [aws_internet_gateway.sales_automation_igw]
}

################################################################################
# Public Route Table (1 - shared by both public subnets)
################################################################################

resource "aws_route_table" "sales_automation_public" {
  vpc_id = aws_vpc.sales_automation_vpc.id

  tags = merge(local.common_tags, {
    Name = "${local.name_prefix}-rtb-public"
    Tier = "public"
  })
}

resource "aws_route" "sales_automation_public_internet" {
  route_table_id         = aws_route_table.sales_automation_public.id
  destination_cidr_block = "0.0.0.0/0"
  gateway_id             = aws_internet_gateway.sales_automation_igw.id
}

resource "aws_route_table_association" "sales_automation_public" {
  count = length(var.public_subnet_cidrs)

  subnet_id      = aws_subnet.sales_automation_public_subnet[count.index].id
  route_table_id = aws_route_table.sales_automation_public.id
}

################################################################################
# Private Route Tables (per AZ - each with NAT gateway route)
################################################################################

resource "aws_route_table" "sales_automation_private" {
  count  = length(var.availability_zones)
  vpc_id = aws_vpc.sales_automation_vpc.id

  tags = merge(local.common_tags, {
    Name = "${local.name_prefix}-rtb-private-${local.az_suffixes[count.index]}"
    Tier = "private"
  })
}

resource "aws_route" "sales_automation_private_nat" {
  count = var.enable_nat_gateway ? length(var.availability_zones) : 0

  route_table_id         = aws_route_table.sales_automation_private[count.index].id
  destination_cidr_block = "0.0.0.0/0"
  nat_gateway_id         = aws_nat_gateway.sales_automation_nat_gateway[0].id
}


resource "aws_route_table_association" "sales_automation_private_lambda" { # Associate private lambda subnets with their respective AZ route table
  count = length(var.private_lambda_subnet_cidrs)

  subnet_id      = aws_subnet.sales_automation_private_lambda_subnet[count.index].id
  route_table_id = aws_route_table.sales_automation_private[count.index].id
}


resource "aws_route_table_association" "sales_automation_private_db" { # Associate private database subnets with their respective AZ route table
  count = length(var.private_db_subnet_cidrs)

  subnet_id      = aws_subnet.sales_automation_private_db_subnet[count.index].id
  route_table_id = aws_route_table.sales_automation_private[count.index].id
}


resource "aws_route_table_association" "sales_automation_private_glue" { # Associate private glue subnet with us-east-1b route table
  subnet_id      = aws_subnet.sales_automation_private_glue_subnet.id
  route_table_id = aws_route_table.sales_automation_private[1].id
}

################################################################################
# VPC Flow Logs - S3 Bucket
################################################################################

module "flow_log_bucket" {
  source = "./modules/s3"
  count  = var.enable_flow_log ? 1 : 0

  bucket_name = "${local.name_prefix}-vpc-flow-logs"

  enable_lifecycle_rules = true
  lifecycle_rules = [
    {
      id      = "transition-to-glacier"
      enabled = true
      transitions = [
        {
          days          = 180
          storage_class = "GLACIER"
        }
      ]
      abort_incomplete_multipart_upload_days = 7
    }
  ]

  tags = merge(local.common_tags, {
    Name    = "${local.name_prefix}-vpc-flow-logs"
    Purpose = "vpc-flow-logs"
  })
}

################################################################################
# VPC Flow Log
################################################################################

resource "aws_flow_log" "vpc_flow_log" {
  count = var.enable_flow_log ? 1 : 0

  vpc_id                   = aws_vpc.sales_automation_vpc.id
  traffic_type             = var.flow_log_traffic_type
  log_destination_type     = "s3"
  log_destination          = module.flow_log_bucket[0].bucket_arn
  max_aggregation_interval = var.flow_log_max_aggregation_interval

  tags = merge(local.common_tags, {
    Name = "${local.name_prefix}-vpc-flow-log"
  })
}

################################################################################
# VPC Endpoints
#
# Gateway endpoints (S3, DynamoDB) attach to ALL private route tables.
# Interface endpoints (Secrets Manager, etc.) deploy into the private
# Lambda subnets so Lambdas and Glue jobs can reach AWS services without
# traversing the NAT Gateway — saving cost and improving latency.
################################################################################

# module "vpc_endpoints" {
#   source   = "./modules/vpc-endpoint"
#   for_each = var.vpc_endpoints

#   name          = "${local.name_prefix}-vpce-${each.key}"
#   vpc_id        = aws_vpc.sales_automation_vpc.id
#   service_name  = "com.amazonaws.${var.aws_region}.${each.value.service}"
#   endpoint_type = each.value.endpoint_type

#   # Gateway endpoints → all private route tables
#   route_table_ids = each.value.endpoint_type == "Gateway" ? aws_route_table.sales_automation_private[*].id : []

#   # Interface endpoints → private Lambda subnets
#   subnet_ids          = each.value.endpoint_type != "Gateway" ? aws_subnet.sales_automation_private_lambda_subnet[*].id : []
#   private_dns_enabled = each.value.private_dns_enabled

#   # Optional IAM policy
#   policy = each.value.policy

#   tags = merge(local.common_tags, {
#     Name    = "${local.name_prefix}-vpce-${each.key}"
#     Service = each.value.service
#   })
# }
